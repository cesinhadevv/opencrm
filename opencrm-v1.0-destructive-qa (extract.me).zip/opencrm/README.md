# OpenCRM

Assistente comercial proativo para vendedores solo de tecnologia para varejo.
Diferente de um CRM passivo, o OpenCRM responde **"o que fazer agora"**: prioriza
contatos, follow-ups e oportunidades por um Score determinístico e explicável.

Stack: Next.js 15 (App Router) · React 19 · TypeScript strict · Tailwind ·
Supabase (PostgreSQL + Auth + RLS) · TanStack Query · Zod · Vitest.

## Arquitetura

Clean Architecture + DDD, com a **Lei de Dependência** fiscalizada por ESLint
(`eslint-plugin-boundaries`):

```
Presentation → Application → Domain
Infrastructure implementa contratos do Domain
```

Regras invioláveis (lint falha se quebradas):

- UI nunca acessa Infraestrutura ou banco diretamente.
- Domínio não importa React, Next ou Supabase.
- Supabase só é importado em `infrastructure/` e `lib/supabase/`.
- Módulo anterior nunca importa módulo posterior.

Serviços fundacionais únicos em `src/core`: TimeService (Clock), IdService,
ConfigService, AuthGateway, ResultContract. Ver `docs/ARCHITECTURE.md`.

## Pré-requisitos

- Node.js 20+
- Conta no Supabase
- Supabase CLI: `npm i -g supabase`

## Instalação

```bash
npm install
cp .env.example .env.local   # preencha as credenciais
```

## Configuração do Supabase

1. Crie um projeto em supabase.com.
2. Settings > API: copie Project URL, anon public e service_role para `.env.local`.
3. Authentication > Providers: habilite Email e (opcional) Google OAuth com
   redirect `<SITE_URL>/auth/callback`.
4. Aplique as migrations.

## Migrations

```bash
supabase link --project-ref SEU_PROJECT_REF
supabase db push
```

Ordem: 0001_foundation → 0002_rls → 0003_accounts → 0004_activities_tasks →
0005_deals → 0006_proposals → 0007_aftersale → 0008_hardening.
Detalhes em `docs/MIGRATIONS.md`.

## Variáveis de ambiente

| Variável                        | Exposição                  |
| ------------------------------- | -------------------------- |
| `NEXT_PUBLIC_SUPABASE_URL`      | pública                    |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | pública (limitada por RLS) |
| `SUPABASE_SERVICE_ROLE_KEY`     | **secreta** (só servidor)  |
| `NEXT_PUBLIC_SITE_URL`          | pública                    |

## Execução

```bash
npm run dev
npm run build && npm run start
```

## Testes e qualidade

```bash
npm test                # Vitest
npm run test:coverage   # cobertura (threshold 90% na lógica de negócio)
npm run typecheck       # tsc strict
npm run lint            # ESLint + fronteiras
npm run format          # Prettier
```

## Deploy

Ver `docs/DEPLOY.md`. Resumo (Vercel): conectar repo, configurar as 4 variáveis,
aplicar migrations no Supabase de produção, configurar redirects de OAuth, deploy.

## Estrutura

```
src/core/              fundacionais (domain/application/infrastructure)
src/modules/<dominio>/ accounts, activities, pipeline, score, cockpit,
                       proposals, aftersale, reports
  domain/              regras puras (sem I/O)
  application/         casos de uso, server actions, schemas
  infrastructure/      repositórios Supabase
  presentation/        componentes React
src/app/               rotas Next
supabase/migrations/   migrations versionadas
tests/unit/            testes determinísticos
docs/                  arquitetura, deploy, migrations
```

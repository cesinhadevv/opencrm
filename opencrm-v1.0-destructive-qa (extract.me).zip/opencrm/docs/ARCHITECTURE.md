# Arquitetura — OpenCRM

## Princípios

Clean Architecture + DDD. Dependências apontam para dentro. O Domínio é puro
(sem I/O, determinístico, testável). A Aplicação orquestra casos de uso. A
Infraestrutura implementa contratos declarados pelo Domínio. A Apresentação
apenas renderiza e chama Server Actions.

## Camadas

- **Domain** (`*/domain`): entidades, value objects e regras puras. Nenhum import
  de React/Next/Supabase. Ex.: `ScoreService`, `RangeNormalizer`,
  `deriveConversationState`, `resolveProbabilityOnStageMove`, métricas.
- **Application** (`*/application`): Server Actions, schemas Zod, orquestração.
  Retorna sempre o `ResultContract` (`{ ok: true, data } | { ok: false, code, message }`).
- **Infrastructure** (`*/infrastructure`): repositórios Supabase, gateways. Único
  lugar (com `lib/supabase`) autorizado a importar o SDK.
- **Presentation** (`*/presentation`, `app/`): componentes React e rotas.

## Serviços fundacionais (`src/core`)

- **TimeService (Clock)**: única fonte de tempo. Todo cálculo de "agora", "dia" e
  intervalo passa por aqui (UTC no armazenamento, fuso IANA do usuário no cálculo).
- **IdService**: UUIDv7 (não-enumerável, gerável no cliente).
- **ConfigService (ConfigStore)**: mecanismo único de configuração do owner.
  Guarda parâmetros, nunca entidades.
- **AuthGateway**: identidade sobre Supabase Auth. Usa `getUser()` (valida JWT no
  servidor), não `getSession()` (cookie).
- **ResultContract**: formato canônico de retorno de toda Server Action.

## Score (determinístico)

Pesos congelados: Probabilidade 35%, Valor 30%, Urgência 20%, Proximidade 10%,
Proposta a vencer 5%. Nunca depende de IA. Calculado sob demanda, nunca persistido.
Normalização por faixas (`RangeNormalizer`) com fronteira mín-inclusiva/máx-exclusiva,
validada na carga (fail fast). A UI consome via `ScoreService`, sem conhecer a fórmula.

## Multi-tenant e segurança

- **RLS** em todas as tabelas: `owner_id = auth.uid()` em USING e WITH CHECK.
- **Soft delete** universal: leitura filtra `deleted_at IS NULL`; unicidade via
  índice parcial sobre ativos.
- **Posse cross-entity**: Server Actions validam que IDs referenciados pertencem
  ao owner antes de escrever (defesa em profundidade junto à RLS).
- **Verificação de e-mail** (DR-A6): parcialmente bloqueante — não impede
  login/onboarding/leitura, mas bloqueia criação de entidades até confirmação.

## Atomicidade

Operações compostas (account+canais, fechar deal Won + task de pós-venda) usam
RPCs Postgres (`supabase/migrations/0008_hardening.sql`), executadas na transação
implícita da função, evitando estado parcial.

## Fronteiras (lint)

`eslint-plugin-boundaries` fiscaliza as regras de dependência. Violação = erro de
lint = build falha.

# CHECKLIST_GO_LIVE — OpenCRM V1.0

Marcar cada item ANTES do primeiro usuário real. Executar contra o Supabase de
produção (ou staging idêntico). Nada aqui altera código — é validação.

## 0. Pré-requisitos
- [ ] Repositório no GitHub; build da Vercel verde
- [ ] Projeto Supabase de produção criado (região correta)
- [ ] `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY` configuradas na Vercel
- [ ] `NEXT_PUBLIC_SITE_URL` = domínio final, **URL absoluta** (senão o reset de senha quebra)
- [ ] `SUPABASE_SERVICE_ROLE_KEY` marcada como secreta (não usada hoje, reservada)

## 1. Migrations (rodar tests/sql/04)
- [ ] `supabase db push` aplicou 0001–0008 sem erro
- [ ] 12 tabelas existem
- [ ] RLS habilitada nas 12
- [ ] 14 policies presentes
- [ ] 2 RPCs com EXECUTE para `authenticated` (create_account_with_channels, close_deal_won_with_task)
- [ ] Índices `%unique_active` presentes
- [ ] FKs activities_deal_fk e tasks_deal_fk presentes
- [ ] contact_channels SEM índice único global (lookup não-único)

## 2. Auth
- [ ] "Confirm email" habilitado
- [ ] Site URL e Redirect URLs incluem o domínio + `/auth/callback`
- [ ] (Opcional) Google OAuth com redirect correto

## 3. Testes SQL (tests/sql) em staging
- [ ] 01_rls_isolation: userB não lê nem altera dados de userA
- [ ] 02_constraints: os 6 INSERTs inválidos FALHAM
- [ ] 03_triggers_rpcs: profile provisionado; updated_at muda; ambas RPCs OK; won idempotente
- [ ] 04_migrations_grants: todas as contagens batem

## 4. Smoke test (docs/SMOKE_TEST + tests/e2e)
- [ ] Smoke test manual < 20 min concluído sem erro
- [ ] `npm run test:e2e` verde contra staging (ou execução manual dos 14 fluxos)

## 5. Fluxos críticos (TEST_PLAN F1–F14)
- [ ] F1 cadastro + verificação
- [ ] F2 login/logout
- [ ] F3 recuperação + redefinição de senha (ciclo completo)
- [ ] F4 onboarding (sem duplicar funil em retry)
- [ ] F5 criar empresa (RPC)
- [ ] F6 contato
- [ ] F7 criar/mover oportunidade
- [ ] F8 interação + follow-up + badge conversacional
- [ ] F9 proposta enviar/aceitar (RN-05: sugere, não executa)
- [ ] F10 ganhar deal (1 task, fechar fechado é rejeitado)
- [ ] F11 marcos pós-venda idempotentes
- [ ] F12 cockpit (faixas + score com entradas reais)
- [ ] F13 relatórios (vencidas ≠ sempre 0)
- [ ] F14 isolamento cross-tenant (2 contas)

## 6. Observabilidade
- [ ] Logs de função visíveis na Vercel
- [ ] Erros de `ensure()`/RPC aparecem nos logs do Supabase
- [ ] (Recomendado) Sentry ou equivalente conectado

## 7. Backups / Recuperação
- [ ] PITR ou backup diário habilitado no Supabase
- [ ] Restauração testada em staging ao menos uma vez
- [ ] ROLLBACK.md revisado pela pessoa responsável pelo deploy

## Critério de GO
Todos os itens de 1 a 5 marcados. Se qualquer teste SQL/E2E de F5, F10 ou F14
falhar → NO-GO até correção (são RPC, atomicidade e isolamento).

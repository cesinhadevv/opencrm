# MATRIZ DE COBERTURA — Destructive QA V1.0

## Fluxos existentes vs cobertura de teste

| # | Fluxo | Casos catalogados | Cobertos E2E | Cobertos SQL | Cobertos Unit | Não-automatizável (manual) |
|---|---|---|---|---|---|---|
| 1 | Autenticação | A-01..A-08 | A-01,02,03,06 | — | — | A-05 (sessão exp), A-07 (multi-aba), A-08 (rede) |
| 2 | Reset senha | R-01..R-05 | R-03,R-05 | — | — | R-01,R-02,R-04 (e-mail/token real) |
| 3 | Onboarding | O-01..O-05 | O-01,O-05 | O-03(seed idem) | — | O-02 (refresh), O-04 (falha seed) |
| 4 | Criar empresa | E-01..E-08 | E-01,04,05,06 | E-02,E-03 | — | E-07 (e-mail não verif.) |
| 5 | Pipeline | D-01..D-06 | D-01,D-02 | D-04(RLS) | — | D-05,D-06 (race/no-op) |
| 6 | Fechar deal | W-01..W-05 | W-01,02,03 | W-05(rollback) | — | — |
| 7 | Atividades | T-01..T-04 | T-01 | — | T-02 (nota interna) | T-04 (badge) |
| 8 | Propostas | P-01..P-04 | P-01,P-03 | — | P-04 (isExpired) | P-02 (duplo aceite) |
| 9 | Pós-venda | PV-01..PV-03 | PV-01,PV-02 | PV-03(config) | — | — |
| 10 | Cockpit/Score | C-01..C-03 | C-01 | — | C-03 (proposalDueSoon) | C-02 (fuso meia-noite) |
| 11 | Relatórios | RP-01..RP-03 | RP-01,02,03 | — | RP-02 (vencidas) | — |
| 12 | Cross-tenant | X-01..X-03 | X-01,X-01b | X-02 | — | X-03 (parcial) |

## Resumo quantitativo

- **Casos catalogados:** ~60 (12 fluxos × positivos + negativos + 15 categorias)
- **Automatizados Playwright:** 23 casos em 15 specs (10 funcionais + 5 destrutivos)
- **Automatizados SQL:** 8 casos (rollback, idempotência, RLS, config, grants)
- **Cobertos por unit existente:** 4 (nota interna RN-17, isExpired, proposalDueSoon, vencidas)
- **Manuais (não-automatizáveis no ambiente):** ~12

## Categorias destrutivas × cobertura

| Categoria | Coberta? | Onde |
|---|---|---|
| Casos felizes | Sim | E2E 01–10 |
| Inválidos | Sim | E2E 20,21,22,24 |
| Borda | Parcial | E2E (E-04), unit (limites) |
| Concorrência | SQL | 05 (idempotência won) |
| Timeout | Não | manual (cortar rede) |
| Perda conexão | Não | manual |
| Sessão expirada | Parcial | manual (A-05) |
| Múltiplas abas | Não | manual (A-07) |
| Refresh | Não | manual (O-02) |
| Dados duplicados | Sim | E2E (W-02), SQL (won idem, config) |
| Autorização RLS | Sim | E2E (X-01), SQL (X-02, isolation) |
| Rollback | SQL | 05 (atomicidade RPC) |
| Falha RPC | SQL | 05, 03 |
| Falha rede | Não | manual |
| Race condition | SQL | 05 (won, config) |

## Lacunas conscientes (não-automatizáveis neste ambiente)

1. **Resiliência de rede/timeout/perda de conexão** — exigem proxy de falha
   (ex.: Playwright `route.abort()` parcial); marcados manuais. Recomenda-se
   adicionar com `context.setOffline(true)` num ambiente com banco real.
2. **Sessão expirada e multi-aba** — exigem manipular cookies/relógio; viáveis
   em E2E com banco real, fora do escopo sem Supabase.
3. **Fuso meia-noite (C-02)** — determinístico, melhor como teste unitário do
   Clock; a lógica já é coberta indiretamente pelos testes de classificação.
4. **E-mail/token reais (reset)** — dependem de provedor de e-mail; manuais.

## Conclusão de cobertura

Os caminhos **P0 de integridade e segurança** (criar empresa via RPC, fechar deal
atômico/idempotente, isolamento cross-tenant, validação de entrada, XSS) estão
cobertos por E2E + SQL. As lacunas restantes são de **resiliência operacional**
(rede, abas, timeout) — importantes, porém não-bloqueantes para um piloto, e
documentadas para execução manual ou para uma fase com banco real provisionado.

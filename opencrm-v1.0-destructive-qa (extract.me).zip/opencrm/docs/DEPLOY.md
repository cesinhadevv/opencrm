# Deploy — OpenCRM

## Alvo recomendado: Vercel + Supabase

### 1. Banco (Supabase)

- Crie o projeto de produção.
- Aplique as migrations: `supabase link --project-ref <REF> && supabase db push`.
- Confirme RLS ativa em todas as tabelas (as migrations 0002+ já habilitam).

### 2. Auth

- Authentication > URL Configuration: defina Site URL para o domínio de produção.
- Adicione `<DOMÍNIO>/auth/callback` em Redirect URLs.
- Para Google OAuth: configure client ID/secret e o mesmo redirect.
- (Recomendado) Habilite "Confirm email" para ativar a verificação (DR-A6).

### 3. App (Vercel)

- Importe o repositório.
- Configure as variáveis: `NEXT_PUBLIC_SUPABASE_URL`,
  `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`,
  `NEXT_PUBLIC_SITE_URL`.
- Build command: `npm run build`. Output: padrão Next.

### 4. Custom claim de onboarding (otimização opcional — M2)

Para o middleware não consultar o banco a cada request, configure um Auth Hook
(Custom Access Token) que injete `app_metadata.onboarded`. Sem o hook, o
middleware faz fallback à query (funciona, com custo de uma query por navegação).

### 5. Pós-deploy

- Smoke test: cadastro → verificação de e-mail → onboarding → criar empresa →
  criar oportunidade → registrar interação → relatório.
- Monitorar logs do Supabase para erros de RLS/constraint.

## Variáveis sensíveis

`SUPABASE_SERVICE_ROLE_KEY` nunca deve ter prefixo `NEXT_PUBLIC_` nem aparecer no
client. É lida apenas no servidor.

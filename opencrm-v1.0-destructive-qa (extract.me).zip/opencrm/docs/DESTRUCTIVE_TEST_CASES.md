# DESTRUCTIVE TEST CASES — OpenCRM V1.0

Casos adversariais por fluxo. Objetivo: provar que a V1.0 quebra. Cada caso lista
o resultado esperado (comportamento correto) e o resultado que indicaria BUG.
Prioridade: P0 (bloqueia go-live) · P1 (corrigir cedo) · P2 (aceitável p/ piloto).

Legenda de categorias: [H]appy [INV]álido [B]orda [C]oncorrência [T]imeout
[CONN]perda-conexão [SESS]sessão-expirada [TAB]multi-aba [REF]refresh
[DUP]duplicado [RLS]autorização [RB]rollback [RPC]falha-rpc [NET]rede [RACE]

---

## FLUXO 1 — Autenticação

### A-01 [H] Login válido — P0 — Automatizável: Sim
- Objetivo: sessão criada com credenciais corretas.
- Pré: conta confirmada.
- Passos: /login → e-mail+senha → Entrar.
- Esperado: sai de /login, entra no app.
- Indica BUG: permanece em /login sem erro, ou erro com credenciais corretas.

### A-02 [INV] Senha incorreta — P0 — Sim
- Esperado: mensagem neutra "E-mail ou senha incorretos"; não revela qual.
- Indica BUG: mensagem distingue "e-mail não existe" de "senha errada" (enumeração de usuários).

### A-03 [INV] E-mail malformado — P1 — Sim
- Passos: e-mail "abc", senha qualquer.
- Esperado: validação client/server barra; sem chamada de auth.
- Indica BUG: requisição de auth disparada com e-mail inválido.

### A-04 [B] Senha no limite mínimo exato — P2 — Sim
- Passos: senha com exatamente PASSWORD_MIN caracteres.
- Esperado: aceita.
- Indica BUG: rejeita o tamanho-limite (erro off-by-one).

### A-05 [SESS] Sessão expirada durante uso — P0 — Parcial
- Pré: logado; expirar/limpar cookie de sessão.
- Passos: tentar uma Server Action (criar empresa).
- Esperado: action retorna unauthenticated; UI redireciona a /login.
- Indica BUG: erro 500 cru, ou operação prossegue sem sessão.

### A-06 [RLS] Rota protegida sem sessão — P0 — Sim
- Passos: acessar /empresas sem login.
- Esperado: middleware redireciona a /login.
- Indica BUG: página protegida renderiza conteúdo.

### A-07 [TAB] Logout em uma aba, ação em outra — P1 — Parcial
- Pré: app aberto em 2 abas logadas.
- Passos: logout na aba 1; tentar criar empresa na aba 2.
- Esperado: aba 2 falha com unauthenticated ao agir.
- Indica BUG: aba 2 cria registro com sessão morta.

### A-08 [NET] Falha de rede no submit de login — P1 — Não
- Passos: cortar rede; clicar Entrar.
- Esperado: erro tratado, botão reabilita, sem travar em "Entrando…".
- Indica BUG: spinner infinito; estado preso.

---

## FLUXO 2 — Recuperação/Redefinição de senha

### R-01 [H] Ciclo completo — P0 — Não (depende de e-mail)
- Esperado: link → /redefinir-senha → nova senha → login OK.
- Indica BUG: link cai em rota inexistente; senha não muda.

### R-02 [INV] SITE_URL ausente — P0 — Não
- Pré: NEXT_PUBLIC_SITE_URL vazia.
- Esperado (correto): documentado como pré-requisito; idealmente erro claro.
- Indica BUG: redirectTo relativo aceito e link quebrado sem aviso.

### R-03 [INV] Senhas não coincidem — P1 — Sim
- Passos: /redefinir-senha com password ≠ confirm.
- Esperado: erro de validação no campo confirm.
- Indica BUG: aceita e define senha mesmo divergente.

### R-04 [SESS] Token de recovery expirado — P1 — Não
- Esperado: Supabase rejeita; UI mostra erro.
- Indica BUG: permite redefinir com token expirado.

### R-05 [INV] Enumeração via recuperação — P0 — Sim
- Passos: pedir reset para e-mail inexistente.
- Esperado: resposta neutra idêntica à de e-mail existente.
- Indica BUG: resposta/tempo difere e revela existência.

---

## FLUXO 3 — Onboarding

### O-01 [H] Onboarding completo — P0 — Sim
- Esperado: funil+canais criados, onboarded=true, vai ao cockpit.

### O-02 [REF] Refresh no meio do onboarding — P1 — Parcial
- Passos: completar passo 1, dar refresh.
- Esperado: reinicia onboarding sem estado corrompido; ao concluir, não duplica.
- Indica BUG: funil duplicado, ou onboarded=true sem funil.

### O-03 [DUP] Concluir onboarding duas vezes (duplo submit) — P0 — Sim
- Passos: clicar Concluir 2x rápido.
- Esperado: seed idempotente — um único funil (verifica stages existentes).
- Indica BUG: estágios/canais duplicados.

### O-04 [RB] Seed falha após marcar onboarded — P0 — Não
- Pré: simular erro no seed.
- Esperado: onboarded permanece false (seed roda ANTES do update); usuário reentra.
- Indica BUG: onboarded=true sem funil → cockpit quebrado.

### O-05 [INV] Zero canais selecionados — P1 — Sim
- Esperado: validação exige ≥1 canal (schema .min(1)).
- Indica BUG: conclui sem canal.

---

## FLUXO 4 — Criar empresa (RPC create_account_with_channels)

### E-01 [H] Empresa com canais — P0 — Sim
- Esperado: account + canais atômicos.

### E-02 [RPC] RPC sem grant execute — P0 — Não (SQL)
- Pré: grant ausente.
- Esperado (correto): grant presente → sucesso.
- Indica BUG: permission denied → criar empresa falha (regressão do F1-2).

### E-03 [RB] Canal inválido no meio do array — P0 — Não (SQL)
- Passos: RPC com 1 canal válido + 1 com type inválido.
- Esperado: transação inteira aborta (atomicidade) — nenhum canal nem account.
- Indica BUG: account criada sem os canais (parcial), ou canal órfão.

### E-04 [B] Nome com 160 chars (limite) — P2 — Sim
- Esperado: aceita exatamente 160; rejeita 161.

### E-05 [INV] Nome vazio/whitespace — P1 — Sim
- Passos: nome "   ".
- Esperado: trim + min(1) rejeita.
- Indica BUG: empresa sem nome criada.

### E-06 [INV] XSS no nome — P0 — Sim
- Passos: nome `<img src=x onerror=alert(1)>`.
- Esperado: React escapa; renderiza como texto literal.
- Indica BUG: script executa.

### E-07 [RLS] Email não verificado — P0 — Parcial
- Pré: conta não confirmada.
- Esperado: createAccount bloqueado (DR-A6).
- Indica BUG: cria empresa sem verificação.

### E-08 [C] Duas empresas mesmo nome simultâneas — P2 — Sim
- Esperado: ambas criadas (nome não é único) — sem erro.
- Indica BUG: constraint inesperada barra a 2ª.

---

## FLUXO 5 — Pipeline (criar/mover deal)

### D-01 [H] Criar oportunidade — P0 — Sim
### D-02 [INV] Valor negativo — P0 — Sim
- Esperado: schema min(0) rejeita.
- Indica BUG: deal com valor negativo.
### D-03 [B] Valor no teto (100bi centavos) — P1 — Sim
- Esperado: aceita ≤ teto; rejeita acima (perda de precisão).
- Indica BUG: aceita valor que estoura 2^53.
### D-04 [RLS] Criar deal em account de OUTRO owner — P0 — Sim
- Passos: forjar accountId de userB ao criar deal como userA.
- Esperado: validação de posse rejeita (not_found).
- Indica BUG: deal criado cruzando tenants.
### D-05 [DUP] Mover deal já fechado — P1 — Não
- Esperado: repo filtra status=open; no-op silencioso.
- Indica BUG: deal won muda de estágio.
### D-06 [RACE] Dois moves simultâneos do mesmo deal — P2 — Não
- Esperado: last-write-wins consistente.
- Indica BUG: probabilidade inconsistente entre stage e valor.

---

## FLUXO 6 — Fechar deal (RPC close_deal_won_with_task)

### W-01 [H] Ganhar deal — P0 — Sim
- Esperado: status=won, 1 task de pós-venda.
### W-02 [DUP] Fechar deal já fechado — P0 — Sim
- Esperado: rejeitado (status != open) na action; RPC só fecha open.
- Indica BUG: 2ª task de pós-venda criada; histórico sobrescrito.
### W-03 [RACE] Duplo clique em Ganhar — P0 — Parcial
- Esperado: a RPC só fecha se status=open (get diagnostics) → 1 task.
- Indica BUG: duas tasks de pós-venda.
### W-04 [INV] Lost sem motivo — P0 — Sim
- Esperado: RN-07 / constraint exige motivo.
- Indica BUG: lost sem reason aceito.
### W-05 [RPC] RPC falha no meio (task falha após update) — P0 — Não (SQL)
- Esperado: transação da função reverte o update do deal.
- Indica BUG: deal won sem task (estado parcial).

---

## FLUXO 7 — Atividades / Follow-up

### T-01 [H] Registrar interação — P0 — Sim
### T-02 [B] Nota interna não conta como interação — P1 — Sim (unit)
- Esperado: estado conversacional ignora internal_note (RN-17).
### T-03 [INV] Conteúdo > 4000 chars — P1 — Sim
- Esperado: schema max(4000) rejeita.
### T-04 [B] Follow-up vencido gera badge followup_overdue — P1 — Parcial
- Esperado: badge aparece no perfil.
- Indica BUG: estado conversacional não exibido (regressão DR-B4).

---

## FLUXO 8 — Propostas

### P-01 [H] Criar/enviar/aceitar — P0 — Sim
### P-02 [DUP] Aceitar proposta duas vezes — P1 — Não
- Esperado: 2º aceite é no-op ou rejeitado; não duplica sugestão de Won.
### P-03 [B] Aceitar SUGERE Won, não executa (RN-05) — P0 — Sim
- Indica BUG: deal vira won automaticamente ao aceitar.
### P-04 [INV] valid_until no passado ao enviar — P2 — Sim
- Esperado: proposta conta como vencida imediatamente nos relatórios.

---

## FLUXO 9 — Pós-venda

### PV-01 [H] Gerar marcos — P0 — Sim
### PV-02 [DUP/RACE] Gerar marcos 2x (duplo clique) — P0 — Parcial
- Esperado: flag de config impede duplicação.
- Indica BUG: marcos duplicados (check-then-act perdeu corrida).
### PV-03 [RPC] config.set falha (índice parcial) — P0 — Não (SQL)
- Esperado: upsert manual funciona (sem ON CONFLICT em índice parcial).
- Indica BUG: erro "no unique constraint matching ON CONFLICT".

---

## FLUXO 10 — Cockpit / Score

### C-01 [H] Faixas temporais corretas — P0 — Sim
### C-02 [B] Tarefa exatamente à meia-noite do fuso — P1 — Não
- Esperado: classificada por Clock/fuso IANA, não UTC.
- Indica BUG: tarefa "hoje" cai em "atrasada" por erro de fuso.
### C-03 [B] Score com proposta a vencer — P1 — Não
- Esperado: componente de 5% dispara via isProposalDueSoon real.
- Indica BUG: proposalDueSoon sempre falso.

---

## FLUXO 11 — Relatórios

### RP-01 [H] Métricas carregam — P0 — Sim
### RP-02 [B] Propostas vencidas ≠ sempre 0 — P0 — Sim
- Esperado: derivado de sent + valid_until passado.
### RP-03 [INV] Período inválido na URL (?period=hack) — P1 — Sim
- Esperado: default seguro (all_time), sem erro.
- Indica BUG: crash ou dados errados.

---

## FLUXO 12 — Cross-tenant (segurança)

### X-01 [RLS] userB lê empresa de userA via URL — P0 — Sim
- Esperado: notFound/vazio.
- Indica BUG: dados de A visíveis a B. NO-GO.
### X-02 [RLS] userB executa RPC com deal de userA — P0 — Não (SQL)
- Esperado: auth.uid() de B; update não afeta linhas de A.
- Indica BUG: B fecha deal de A.
### X-03 [RLS] userB lista propostas de deal de A — P0 — Sim
- Esperado: vazio.

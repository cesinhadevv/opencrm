# Plano de Deploy & Checklist de Go-Live — OpenCRM V1.0

## Parte A — Plano de Deploy

### A.1 Supabase (banco + auth)

1. Criar projeto de produção (região mais próxima dos usuários — ex.: São Paulo).
2. **Migrations**: `supabase link --project-ref <REF>` → `supabase db push`.
   Aplica 0001→0008 em ordem. Confirmar no SQL Editor:
   - 12 tabelas criadas; RLS habilitada em todas (`select relname, relrowsecurity from pg_class where relnamespace = 'public'::regnamespace`).
   - 2 RPCs presentes com `GRANT EXECUTE` para `authenticated`.
   - Trigger `handle_new_user` ativo em `auth.users`.
3. **Auth > Providers**: habilitar Email. Ativar "Confirm email" (DR-A6).
4. **Auth > URL Configuration**: Site URL = domínio de produção;
   Redirect URLs inclui `<DOMÍNIO>/auth/callback`.

### A.2 Google OAuth (opcional)

1. Google Cloud Console → OAuth consent screen + credenciais OAuth 2.0.
2. Authorized redirect URI: `https://<PROJECT_REF>.supabase.co/auth/v1/callback`.
3. Colar Client ID/Secret em Supabase > Auth > Providers > Google.

### A.3 Vercel (app)

1. Importar repositório. Framework: Next.js (detecção automática).
2. Variáveis de ambiente (Production):
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY` (marcar como sensível)
   - `NEXT_PUBLIC_SITE_URL` (domínio final)
3. Build: `npm run build`. Deploy.

### A.4 Domínio

- Apontar DNS para a Vercel; configurar domínio custom; aguardar SSL.
- Atualizar `NEXT_PUBLIC_SITE_URL` e os redirects do Supabase para o domínio final.

### A.5 Backups

- Supabase: habilitar Point-in-Time Recovery (planos pagos) ou daily backups.
- Testar restauração num projeto de staging antes do go-live.

### A.6 Storage

- Não utilizado na V1.0 (sem upload de arquivos). Nenhuma configuração necessária.

### A.7 Cron jobs

- A V1.0 deriva "proposta vencida" em tempo de leitura (não exige cron).
- **Futuro** (não bloqueante): job diário para materializar `expired` e disparar
  notificações de follow-up. Documentar quando o Módulo de notificações existir.

### A.8 Monitoramento & Logs

- Vercel: Analytics + logs de função (Server Actions) habilitados.
- Supabase: Logs Explorer para erros de RLS/constraint/RPC.
- **Recomendado**: integrar Sentry (client + server) para capturar exceções —
  especialmente as que o `ensure()` agora lança em falha de banco.

---

## Parte B — Checklist de Go-Live

### B.1 Banco & Migrations

- [ ] 0001–0008 aplicadas sem erro
- [ ] 12 tabelas com RLS habilitada
- [ ] Policies retornam apenas dados do próprio owner (teste cross-tenant manual)
- [ ] 2 RPCs com GRANT EXECUTE para authenticated
- [ ] `handle_new_user` cria profile no signup
- [ ] Índices parciais presentes (verificar `pg_indexes`)
- [ ] Constraint `deals_status_consistency` rejeita estados inválidos

### B.2 Autenticação

- [ ] Cadastro cria usuário + profile + dispara e-mail de confirmação
- [ ] Login com credenciais corretas/incorretas (mensagem neutra)
- [ ] Recuperação de senha envia link e permite redefinir
- [ ] Google OAuth completa o fluxo e cria profile
- [ ] E-mail não verificado: navega mas NÃO cria empresa (DR-A6)
- [ ] Logout limpa sessão e redireciona para /login

### B.3 Onboarding

- [ ] 3 passos concluem em < 90s
- [ ] Funil default e canais são criados
- [ ] Falha no meio NÃO deixa usuário travado (reentra no onboarding)
- [ ] Retry de onboarding não duplica funil (idempotência)

### B.4 Fluxo principal (smoke test ponta a ponta)

- [ ] Criar empresa (com e sem canais)
- [ ] Adicionar contato
- [ ] Registrar interação (outbound/inbound/nota)
- [ ] Criar follow-up; concluir no Cockpit
- [ ] Criar oportunidade; mover no Kanban (probabilidade atualiza por stage)
- [ ] Marcar Won → gera tarefa de pós-venda (1 só, não duplicada)
- [ ] Marcar Lost exige motivo
- [ ] Fechar oportunidade já fechada é rejeitado
- [ ] Criar proposta; enviar (agenda lembrete); aceitar (sugere Won, não executa)
- [ ] Gerar marcos de pós-venda (idempotente — 2 cliques não duplicam)
- [ ] Relatório: conversão, ticket, tempo médio, funil, propostas, vencidas ≠ sempre 0

### B.5 Segurança

- [ ] Usuário A não vê dados de usuário B (RLS, teste real com 2 contas)
- [ ] RPC chamada com deal de outro owner não afeta nada (auth.uid)
- [ ] service_role NÃO aparece no bundle do client (grep no build)
- [ ] Busca com `%`/`_` é literal (não retorna tudo)
- [ ] Valor de oportunidade rejeita acima do teto

### B.6 Performance

- [ ] Perfil de empresa com vários deals: 1 query de propostas (não N+1)
- [ ] Detalhe de pós-venda não carrega lista inteira
- [ ] Middleware: sem query de profile a cada request (se claim configurado)
- [ ] Listagens grandes respeitam teto (não travam a página)

### B.7 UX

- [ ] Loading/skeleton aparece em cada rota
- [ ] error.tsx captura falha de Server Component (não tela crua)
- [ ] 404 estilizado
- [ ] Empty states em listas vazias
- [ ] Dark mode sem flash (FOUC) no primeiro paint
- [ ] Responsivo: sidebar↔tab bar na fronteira md
- [ ] Navegação por teclado em formulários; foco visível

### B.8 Observabilidade

- [ ] Logs de erro chegam ao monitoramento (Sentry/Vercel)
- [ ] Erros de banco (ensure) aparecem como failure tratado, não 500 cru

# Migrations — OpenCRM

Migrations versionadas e idempotentes (usam `if not exists`/`create or replace`),
aplicadas em ordem numérica via Supabase CLI (`supabase db push`).

## Convenções

- snake_case, tabelas no plural.
- Colunas-padrão: `id uuid pk`, `owner_id`, `created_at`, `updated_at`, `deleted_at`.
- Soft delete: `deleted_at timestamptz null`; leitura filtra `deleted_at is null`.
- Unicidade ativa: índice parcial `where deleted_at is null`.
- RLS: habilitada por tabela; política `owner_id = auth.uid()` em using/with check.
- `updated_at`: trigger `set_updated_at` (definido em 0001).

## Lista

| #   | Arquivo                   | Conteúdo                                                                  |
| --- | ------------------------- | ------------------------------------------------------------------------- |
| 1   | 0001_foundation.sql       | profiles, owner_configs, pipeline_stages, channels; função set_updated_at |
| 2   | 0002_rls.sql              | RLS base + trigger handle_new_user (provisiona profile no signup)         |
| 3   | 0003_accounts.sql         | accounts, contacts, contact_channels (canônico/exibição)                  |
| 4   | 0004_activities_tasks.sql | activities (direction/source), tasks                                      |
| 5   | 0005_deals.sql            | deals (status×stage, RN-07 via constraint); FKs deal_id                   |
| 6   | 0006_proposals.sql        | proposals (status, validade)                                              |
| 7   | 0007_aftersale.sql        | aftersale_records                                                         |
| 8   | 0008_hardening.sql        | RPCs transacionais; unicidade de canais relaxada                          |

## Notas

- A migration 8 troca o índice ÚNICO de canais por índice de busca não-único:
  o mesmo telefone/e-mail pode existir em contatos distintos do mesmo owner.
- As RPCs `create_account_with_channels` e `close_deal_won_with_task` garantem
  atomicidade de operações compostas.
- Score não tem tabela: é derivado, nunca persistido.
- Relatórios não têm tabela: são consultas agregadas sobre as fontes existentes.

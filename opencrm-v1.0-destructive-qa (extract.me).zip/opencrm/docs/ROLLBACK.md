# ROLLBACK — OpenCRM V1.0

Procedimentos para reverter um deploy problemático. Ordenados do menos ao mais
drástico. Decidir com base no tipo de falha.

## Matriz de decisão

| Sintoma | Ação | Seção |
|---|---|---|
| Bug de UI/lógica, banco íntegro | Reverter app na Vercel | A |
| Migration aplicada com defeito, sem dados ainda | Reverter migration | B |
| Dados corrompidos após go-live | Restaurar backup PITR | C |
| RPC/policy com falha de segurança | Desabilitar acesso + corrigir | D |

## A. Rollback do app (Vercel) — segundos
1. Vercel → Deployments → localizar o último deploy estável.
2. "Promote to Production" no deploy anterior.
3. O banco NÃO é tocado. Útil quando o problema é só de código.

## B. Rollback de migration — minutos
As migrations não têm "down" automático (Supabase aplica forward-only). Para reverter:
1. Identificar a migration problemática (ex.: 0008).
2. Escrever e aplicar uma migration compensatória (ex.: `0009_revert_xxxx.sql`) que
   desfaça o que a anterior fez (drop da função/índice/coluna recém-criada).
3. NUNCA editar uma migration já aplicada — sempre uma nova forward.
4. Exemplo (reverter as RPCs do 0008):
   ```sql
   drop function if exists public.create_account_with_channels(uuid,text,text,text,jsonb);
   drop function if exists public.close_deal_won_with_task(uuid,uuid,uuid,timestamptz,text,timestamptz);
   ```
   **Atenção:** o app depende dessas RPCs para criar empresa e ganhar deal —
   revertê-las quebra esses fluxos. Reverter app (A) junto.

## C. Restauração de dados (PITR) — a mais drástica
1. Supabase → Database → Backups / Point-in-Time Recovery.
2. Escolher o timestamp anterior à corrupção.
3. Restaurar para um projeto novo, validar, então cortar o tráfego.
4. **Perda de dados** entre o ponto de restauração e agora — comunicar usuários.
5. Pré-requisito: PITR/backup habilitado ANTES do incidente (ver CHECKLIST 7).

## D. Contenção de falha de segurança (RLS/RPC) — imediata
1. Se uma policy vazar dados cross-tenant: no SQL Editor, tornar a tabela
   inacessível temporariamente revogando o acesso do role:
   ```sql
   revoke all on public.<tabela> from authenticated;
   ```
   (Derruba o recurso, mas estanca o vazamento.)
2. Corrigir a policy via migration forward.
3. Reconceder: `grant ... on public.<tabela> to authenticated;` conforme o padrão original.
4. Auditar logs do período de exposição.

## Pós-rollback
- Registrar o incidente: causa, ação, impacto, dados afetados.
- Reproduzir em staging antes de retentar o deploy.
- Atualizar o CHECKLIST_GO_LIVE com o novo caso de teste.

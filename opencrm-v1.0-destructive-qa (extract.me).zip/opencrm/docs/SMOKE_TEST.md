# SMOKE_TEST — OpenCRM V1.0 (< 20 minutos)

Roteiro manual mínimo para confirmar que o sistema funciona em produção/staging.
Qualquer pessoa consegue executar. Cronometre: se passar de 20 min, algo travou.
Faça na ordem. Pare e registre no primeiro passo que falhar.

## Antes de começar (2 min)
- [ ] App abre no domínio (HTTPS válido, sem erro de console)
- [ ] `NEXT_PUBLIC_SITE_URL` configurada (necessária para reset de senha)

## 1. Cadastro e acesso (4 min)
- [ ] Acessar /cadastro, criar conta com um e-mail real
- [ ] Receber e clicar no link de confirmação
- [ ] Fazer login → cai no onboarding
- [ ] Concluir onboarding (nome, canais, funil) → cai no Cockpit (Hoje)

## 2. Núcleo comercial (8 min)
- [ ] Criar empresa com um canal (WhatsApp) → empresa aparece
      (valida RPC create_account_with_channels + grant)
- [ ] Abrir o perfil da empresa → adicionar um contato
- [ ] Criar uma oportunidade (valor R$ 5.000) → aparece no perfil e no /pipeline
- [ ] Registrar uma interação (outbound) → aparece na timeline
- [ ] Criar um follow-up → aparece como tarefa
- [ ] Criar uma proposta no deal → enviar → aceitar
      (valida RN-05: aceitar SUGERE ganhar, não fecha sozinho)
- [ ] Marcar a oportunidade como Ganha
      (valida RPC close_deal_won_with_task → cria tarefa de pós-venda)
- [ ] Tentar fechar a MESMA oportunidade de novo → deve ser rejeitada

## 3. Visões derivadas (3 min)
- [ ] Cockpit (Hoje): a tarefa de follow-up aparece na faixa correta
- [ ] Cockpit: resumo mostra total de pipeline > 0
- [ ] /pos-venda: o cliente ganho aparece; gerar marcos; gerar de novo NÃO duplica
- [ ] /relatorios: conversão e funil carregam; "propostas vencidas" não trava em 0

## 4. Segurança mínima (3 min)
- [ ] Copiar a URL do perfil de uma empresa (/empresas/<id>)
- [ ] Logout; criar/usar uma SEGUNDA conta
- [ ] Colar a URL da empresa da primeira conta → NÃO deve mostrar os dados
      (valida isolamento RLS cross-tenant — o teste mais importante)
- [ ] Recuperar senha: solicitar link, clicar, definir nova senha, logar com ela

## Resultado
- [ ] Todos os passos verdes → smoke test PASSOU
- Falhou em F5/F10 (RPC) → verificar grants das funções (tests/sql/04)
- Falhou no passo 4 cross-tenant → NO-GO imediato (vazamento entre clientes)
- Falhou no reset → verificar NEXT_PUBLIC_SITE_URL absoluta

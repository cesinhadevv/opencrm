# TEST_PLAN — OpenCRM V1.0

Plano de validação de integração contra um Supabase real. Cobre os fluxos
críticos, os testes E2E (Playwright), os testes SQL (RLS/constraints/triggers/RPCs)
e o smoke test de produção. Arquitetura V1.0 congelada — este plano apenas valida.

## Ambiente de teste

- Projeto Supabase dedicado de **staging** (NUNCA produção).
- Migrations 0001–0008 aplicadas via `supabase db push`.
- `.env.local` apontando para o projeto de staging.
- Duas contas de teste para validar isolamento cross-tenant: `userA` e `userB`.

---

## Fluxos críticos

### F1 — Cadastro + verificação de e-mail
- **Pré-condições:** e-mail não cadastrado; "Confirm email" habilitado no Supabase.
- **Passos:** acessar /cadastro → preencher nome/e-mail/senha → enviar → confirmar e-mail.
- **Resultado esperado:** usuário criado em `auth.users`; profile provisionado; redireciona a /onboarding.
- **Dados no banco:** 1 linha em `auth.users`, 1 em `public.profiles` (onboarded=false).
- **Tabelas afetadas:** `auth.users`, `profiles`.
- **RPCs envolvidas:** trigger `handle_new_user`.
- **RLS exercitada:** `profiles_insert_own` (via trigger security definer).
- **Possíveis falhas:** trigger não dispara (profile ausente); e-mail duplicado; confirmação não exigida.

### F2 — Login / Logout
- **Pré-condições:** conta confirmada existente.
- **Passos:** /login → credenciais → entrar; depois Sair no header.
- **Resultado esperado:** sessão criada e destruída; redireciona /login após logout.
- **Tabelas afetadas:** nenhuma (sessão em cookie).
- **RLS exercitada:** todas (sessão define `auth.uid()`).
- **Possíveis falhas:** credenciais incorretas com mensagem não-neutra; sessão não persiste.

### F3 — Recuperação + redefinição de senha
- **Pré-condições:** conta existente; `NEXT_PUBLIC_SITE_URL` configurada (URL absoluta).
- **Passos:** /recuperar-senha → e-mail → link recebido → /auth/callback?type=recovery → /redefinir-senha → nova senha → /login.
- **Resultado esperado:** senha alterada; login com a nova senha funciona.
- **Tabelas afetadas:** `auth.users` (encrypted_password).
- **Possíveis falhas:** `redirectTo` relativo (SITE_URL vazia) → link inválido; callback não roteia recovery.

### F4 — Onboarding
- **Pré-condições:** logado, onboarded=false.
- **Passos:** 3 passos (nome, canais, funil) → concluir.
- **Resultado esperado:** profile com onboarded=true, fuso IANA salvo; funil e canais criados.
- **Dados no banco:** `pipeline_stages` (4 default), `channels` (selecionados), `profiles.onboarded=true`.
- **Tabelas afetadas:** `profiles`, `pipeline_stages`, `channels`.
- **Possíveis falhas:** seed roda mas onboarded não marca (ordem); retry duplica funil (idempotência — seed verifica stages existentes).

### F5 — Criar empresa (com canais)
- **Pré-condições:** onboarding completo; e-mail verificado (DR-A6 gate).
- **Passos:** /empresas → Nova empresa → nome + canais → criar.
- **Resultado esperado:** empresa criada atomicamente com canais.
- **Dados no banco:** 1 `accounts`, N `contact_channels` (account_id setado).
- **Tabelas afetadas:** `accounts`, `contact_channels`.
- **RPCs envolvidas:** `create_account_with_channels` (transacional, owner via auth.uid).
- **RLS exercitada:** `accounts_all_own`, `contact_channels_all_own`.
- **Possíveis falhas:** RPC sem grant execute (permission denied); e-mail não verificado bloqueia; canais órfãos se não-atômico.

### F6 — Adicionar contato
- **Pré-condições:** empresa existente.
- **Passos:** perfil da empresa → Adicionar contato → nome/cargo/canais.
- **Resultado esperado:** contato vinculado à account.
- **Tabelas afetadas:** `contacts`, `contact_channels` (contact_id setado).
- **Possíveis falhas:** contact_channels com account_id e contact_id ambos nulos (constraint num_nonnulls=1).

### F7 — Criar e mover oportunidade (pipeline)
- **Pré-condições:** empresa existente; funil com estágios.
- **Passos:** perfil → nova oportunidade (título/valor/estágio) → no kanban, arrastar entre estágios.
- **Resultado esperado:** deal criado (status=open, probabilidade=default do estágio); ao mover, probabilidade segue default do novo estágio (sem override).
- **Dados no banco:** 1 `deals` (status open, stage_id, value em centavos).
- **Tabelas afetadas:** `deals`.
- **RLS exercitada:** `deals_all_own`.
- **Possíveis falhas:** account de outro owner aceita (validação de posse); probabilidade não atualiza ao mover.

### F8 — Registrar atividade + follow-up + estado conversacional
- **Pré-condições:** empresa existente.
- **Passos:** registrar interação (outbound/inbound/nota); criar follow-up; concluir no cockpit.
- **Resultado esperado:** timeline ordenada; nota interna não conta como interação real; badge de estado conversacional aparece quando aplicável (followup_overdue/no_reply/cooling).
- **Dados no banco:** `activities` (direction/source), `tasks` (status open→done).
- **Tabelas afetadas:** `activities`, `tasks`.
- **Possíveis falhas:** estado conversacional não exibido; nota interna reinicia contador.

### F9 — Proposta: criar, enviar, aceitar
- **Pré-condições:** deal aberto.
- **Passos:** criar proposta (valor/validade) → enviar (agenda lembrete) → aceitar.
- **Resultado esperado:** status draft→sent→accepted; envio agenda Task de lembrete; aceitar SUGERE Won (não executa — RN-05).
- **Dados no banco:** `proposals`, `tasks` (lembrete, priority=1).
- **Tabelas afetadas:** `proposals`, `tasks`.
- **RPCs envolvidas:** nenhuma (sem transação composta no aceite).
- **Possíveis falhas:** aceitar executa Won automaticamente (violaria RN-05); lembrete não agendado.

### F10 — Ganhar deal + pós-venda
- **Pré-condições:** deal aberto.
- **Passos:** marcar Won → confirmar.
- **Resultado esperado:** deal won_at setado; Task de pós-venda criada atomicamente; fechar deal já fechado é rejeitado.
- **Dados no banco:** `deals` (status=won, won_at), `tasks` (pós-venda).
- **RPCs envolvidas:** `close_deal_won_with_task` (transacional).
- **Constraint exercitada:** `deals_status_consistency`.
- **Possíveis falhas:** task duplicada em duplo clique; won→won recria task; RPC sem grant.

### F11 — Pós-venda: marcos + registros
- **Pré-condições:** deal won.
- **Passos:** /pos-venda → cliente → gerar marcos → registrar acompanhamento/satisfação/upsell/indicação.
- **Resultado esperado:** marcos geram tasks (7/30/90d); idempotente (2ª geração não duplica); registros gravados.
- **Dados no banco:** `tasks` (marcos), `aftersale_records`, `owner_configs` (flag generated:<dealId>).
- **Tabelas afetadas:** `tasks`, `aftersale_records`, `owner_configs`.
- **Possíveis falhas:** config.set falha (índice parcial); marcos duplicados.

### F12 — Cockpit (Hoje) + Score
- **Pré-condições:** tasks e deals abertos existentes.
- **Passos:** abrir / (Hoje).
- **Resultado esperado:** tarefas em faixas (Atrasadas/Hoje/Semana/Próximas); resumo (total pipeline, atrasadas); top deal por Score com entradas reais (interação, fechamento, proposta a vencer).
- **Tabelas afetadas:** leitura de `tasks`, `deals`, `activities`, `proposals`, `profiles`.
- **Possíveis falhas:** Score com urgência fixa; proposalDueSoon sempre falso; faixas incorretas por fuso.

### F13 — Relatórios
- **Pré-condições:** dados de deals/proposals/activities/aftersale.
- **Passos:** /relatorios → alternar período (mês/30d/ano/tudo).
- **Resultado esperado:** conversão, ticket médio, tempo médio de fechamento, funil, propostas (enviadas/aceitas/recusadas/vencidas≠sempre0), pós-venda.
- **Tabelas afetadas:** leitura agregada de todas.
- **Possíveis falhas:** vencidas sempre 0; filtro de período não aplica.

### F14 — Isolamento cross-tenant (CRÍTICO de segurança)
- **Pré-condições:** userA e userB, cada um com dados.
- **Passos:** logado como userB, tentar ler/editar dados de userA (via URL direta de /empresas/[id de A]).
- **Resultado esperado:** userB NÃO vê nem altera nada de userA (RLS).
- **RLS exercitada:** todas as 14 policies.
- **Possíveis falhas:** vazamento de dados entre tenants; RPC de A executável por B.

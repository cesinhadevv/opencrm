import js from '@eslint/js';
import tseslint from '@typescript-eslint/eslint-plugin';
import tsparser from '@typescript-eslint/parser';
import boundaries from 'eslint-plugin-boundaries';

/**
 * Fronteiras de arquitetura — fiscalização da Lei de Dependência.
 *
 * Camadas (anéis concêntricos do Dependency Map):
 *   domain         → não depende de nada
 *   application    → depende de domain
 *   infrastructure → depende de domain (implementa contratos; inversão de dependência)
 *   presentation   → depende de application e domain (apenas tipos), nunca de infrastructure
 *
 * Estas regras tornam executáveis as proibições da Seção 7 do Dependency Map.
 * Violação = erro de lint, merge bloqueado (ADR-009).
 */
export default [
  {
    ignores: [
      '.next/**',
      'node_modules/**',
      'coverage/**',
      'out/**',
      'next-env.d.ts',
      '*.config.mjs',
      '*.config.ts',
    ],
  },
  js.configs.recommended,
  {
    files: ['**/*.{ts,tsx}'],
    languageOptions: {
      parser: tsparser,
      parserOptions: { project: './tsconfig.json' },
      globals: {
        window: 'readonly',
        document: 'readonly',
        localStorage: 'readonly',
        navigator: 'readonly',
        console: 'readonly',
        setTimeout: 'readonly',
        process: 'readonly',
        React: 'readonly',
        Intl: 'readonly',
        Math: 'readonly',
        URL: 'readonly',
      },
    },
    plugins: {
      '@typescript-eslint': tseslint,
      boundaries,
    },
    settings: {
      'boundaries/elements': [
        { type: 'domain', pattern: 'src/core/domain/**' },
        { type: 'application', pattern: 'src/core/application/**' },
        { type: 'infrastructure', pattern: 'src/core/infrastructure/**' },
        { type: 'module-domain', pattern: 'src/modules/*/domain/**' },
        { type: 'module-application', pattern: 'src/modules/*/application/**' },
        { type: 'module-infrastructure', pattern: 'src/modules/*/infrastructure/**' },
        { type: 'module-presentation', pattern: 'src/modules/*/presentation/**' },
        { type: 'presentation', pattern: 'src/{app,components,layouts,providers,hooks}/**' },
        { type: 'lib', pattern: 'src/lib/**' },
      ],
    },
    rules: {
      // TypeScript já cobre símbolos não definidos; no-undef gera falso-positivo com tipos.
      'no-undef': 'off',
      // Params nomeados em assinaturas de interface não são "uso"; desligar a versão base.
      'no-unused-vars': 'off',
      'boundaries/element-types': [
        'error',
        {
          default: 'disallow',
          rules: [
            // Domínio: não depende de nada além de si mesmo.
            { from: ['domain', 'module-domain'], allow: ['domain', 'module-domain'] },
            // Aplicação: depende de domínio.
            {
              from: ['application', 'module-application'],
              allow: ['domain', 'module-domain', 'application', 'module-application', 'lib'],
            },
            // Infraestrutura: depende de domínio (implementa seus contratos).
            {
              from: ['infrastructure', 'module-infrastructure'],
              allow: ['domain', 'module-domain', 'infrastructure', 'module-infrastructure', 'lib'],
            },
            // Apresentação: depende de aplicação e domínio (tipos). NUNCA de infraestrutura.
            {
              from: ['presentation', 'module-presentation'],
              allow: [
                'application',
                'module-application',
                'domain',
                'module-domain',
                'presentation',
                'module-presentation',
                'lib',
              ],
            },
            // lib: utilitários puros, sem dependência de camadas de negócio.
            { from: ['lib'], allow: ['lib'] },
          ],
        },
      ],
      // Proíbe import direto do client Supabase fora da infraestrutura (Dependency Map §7.2).
      'no-restricted-imports': [
        'error',
        {
          patterns: [
            {
              group: ['@supabase/supabase-js', '@supabase/ssr'],
              message:
                'Acesso ao Supabase apenas na camada de infraestrutura (src/**/infrastructure). Use um repositório/gateway.',
            },
          ],
        },
      ],
    },
  },
  // Exceção: a própria infraestrutura pode importar o Supabase.
  {
    files: ['src/**/infrastructure/**/*.{ts,tsx}', 'src/lib/supabase/**/*.{ts,tsx}'],
    rules: { 'no-restricted-imports': 'off' },
  },
];

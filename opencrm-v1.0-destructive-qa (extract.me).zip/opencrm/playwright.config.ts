import { defineConfig, devices } from '@playwright/test';

/**
 * Configuração Playwright para os testes E2E da V1.0.
 * Requer um ambiente real rodando: `npm run dev` + Supabase com migrations aplicadas
 * e `.env.local` preenchido. Os testes NÃO mockam o banco — provam integração real.
 */
export default defineConfig({
  testDir: './tests/e2e',
  fullyParallel: false, // fluxos compartilham estado de conta; serial é mais previsível
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 1 : 0,
  workers: 1,
  reporter: [['list'], ['html', { open: 'never' }]],
  timeout: 30_000,
  expect: { timeout: 10_000 },
  use: {
    baseURL: process.env.E2E_BASE_URL ?? 'http://localhost:3000',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
  },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }],
  webServer: process.env.E2E_NO_SERVER
    ? undefined
    : {
        command: 'npm run dev',
        url: 'http://localhost:3000',
        reuseExistingServer: !process.env.CI,
        timeout: 120_000,
      },
});

'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { signUpAction, googleSignInAction } from '@/core/application/auth-actions';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Field } from '@/components/ui/field';
import { Card } from '@/components/ui/card';
import type { FieldErrors } from '@/core/domain/result';

export default function SignUpPage() {
  const router = useRouter();
  const [errors, setErrors] = useState<FieldErrors>({});
  const [globalError, setGlobalError] = useState('');
  const [pending, setPending] = useState(false);

  async function onSubmit(formData: FormData) {
    setPending(true);
    setErrors({});
    setGlobalError('');
    const result = await signUpAction({
      displayName: formData.get('displayName'),
      email: formData.get('email'),
      password: formData.get('password'),
    });
    setPending(false);
    if (result.ok) router.push(result.data.next);
    else if (result.fieldErrors) setErrors(result.fieldErrors);
    else setGlobalError(result.message);
  }

  return (
    <Card>
      <h1 className="mb-1 text-xl font-semibold text-ink">Criar conta</h1>
      <p className="mb-6 text-sm text-neutral-500">Comece a organizar suas vendas</p>
      {globalError ? <p className="mb-4 text-sm text-urgent">{globalError}</p> : null}
      <form action={onSubmit} className="flex flex-col gap-4">
        <Field label="Nome" htmlFor="displayName" error={errors.displayName}>
          <Input id="displayName" name="displayName" autoComplete="name" />
        </Field>
        <Field label="E-mail" htmlFor="email" error={errors.email}>
          <Input id="email" name="email" type="email" autoComplete="email" />
        </Field>
        <Field label="Senha" htmlFor="password" error={errors.password}>
          <Input id="password" name="password" type="password" autoComplete="new-password" />
        </Field>
        <Button type="submit" disabled={pending}>
          {pending ? 'Criando…' : 'Criar conta'}
        </Button>
      </form>
      <form
        action={async () => {
          const r = await googleSignInAction();
          if (r.ok) window.location.href = r.data.redirectUrl;
        }}
      >
        <Button type="submit" variant="secondary" className="mt-2 w-full">
          Continuar com Google
        </Button>
      </form>
      <div className="mt-4 text-sm text-neutral-500">
        Já tem conta?{' '}
        <Link href="/login" className="hover:text-brand">
          Entrar
        </Link>
      </div>
    </Card>
  );
}

/** Layout de autenticação: centralizado, sem shell (Tech Spec). */
export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <main className="flex min-h-screen items-center justify-center bg-canvas px-4">
      <div className="w-full max-w-sm">{children}</div>
    </main>
  );
}

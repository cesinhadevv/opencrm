'use client';

import { useState, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { signInAction, googleSignInAction } from '@/core/application/auth-actions';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Field } from '@/components/ui/field';
import { Card } from '@/components/ui/card';
import type { FieldErrors } from '@/core/domain/result';

function LoginForm() {
  const router = useRouter();
  const next = useSearchParams().get('next') ?? '/';
  const [errors, setErrors] = useState<FieldErrors>({});
  const [globalError, setGlobalError] = useState('');
  const [pending, setPending] = useState(false);

  async function onSubmit(formData: FormData) {
    setPending(true);
    setErrors({});
    setGlobalError('');
    const result = await signInAction({
      email: formData.get('email'),
      password: formData.get('password'),
    });
    setPending(false);
    if (result.ok) {
      router.push(next);
    } else if (result.fieldErrors) {
      setErrors(result.fieldErrors);
    } else {
      setGlobalError(result.message);
    }
  }

  return (
    <Card>
      <h1 className="mb-1 text-xl font-semibold text-ink">Entrar no OpenCRM</h1>
      <p className="mb-6 text-sm text-neutral-500">Seu assistente comercial</p>
      {globalError ? <p className="mb-4 text-sm text-urgent">{globalError}</p> : null}
      <form action={onSubmit} className="flex flex-col gap-4">
        <Field label="E-mail" htmlFor="email" error={errors.email}>
          <Input id="email" name="email" type="email" autoComplete="email" />
        </Field>
        <Field label="Senha" htmlFor="password" error={errors.password}>
          <Input id="password" name="password" type="password" autoComplete="current-password" />
        </Field>
        <Button type="submit" disabled={pending}>
          {pending ? 'Entrando…' : 'Entrar'}
        </Button>
      </form>
      <form
        action={async () => {
          const r = await googleSignInAction();
          if (r.ok) window.location.href = r.data.redirectUrl;
        }}
      >
        <Button type="submit" variant="secondary" className="mt-2 w-full">
          Continuar com Google
        </Button>
      </form>
      <div className="mt-4 flex justify-between text-sm text-neutral-500">
        <Link href="/recuperar-senha" className="hover:text-brand">
          Esqueci minha senha
        </Link>
        <Link href="/cadastro" className="hover:text-brand">
          Criar conta
        </Link>
      </div>
    </Card>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={null}>
      <LoginForm />
    </Suspense>
  );
}

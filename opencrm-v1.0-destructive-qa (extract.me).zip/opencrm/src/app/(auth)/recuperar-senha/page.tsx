'use client';

import { useState } from 'react';
import Link from 'next/link';
import { requestPasswordResetAction } from '@/core/application/auth-actions';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Field } from '@/components/ui/field';
import { Card } from '@/components/ui/card';

export default function RecoverPasswordPage() {
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');
  const [pending, setPending] = useState(false);

  async function onSubmit(formData: FormData) {
    setPending(true);
    setError('');
    const result = await requestPasswordResetAction({ email: formData.get('email') });
    setPending(false);
    if (result.ok) setSent(true);
    else setError(result.fieldErrors?.email ?? result.message);
  }

  if (sent) {
    return (
      <Card>
        <h1 className="mb-2 text-xl font-semibold text-ink">Verifique seu e-mail</h1>
        {/* Resposta neutra (Tech Spec A.5): não revela existência da conta. */}
        <p className="text-sm text-neutral-500">
          Se houver uma conta com esse e-mail, enviamos as instruções para redefinir a senha.
        </p>
        <Link href="/login" className="mt-4 inline-block text-sm text-brand">
          Voltar ao login
        </Link>
      </Card>
    );
  }

  return (
    <Card>
      <h1 className="mb-1 text-xl font-semibold text-ink">Recuperar senha</h1>
      <p className="mb-6 text-sm text-neutral-500">Enviaremos um link para você redefinir</p>
      {error ? <p className="mb-4 text-sm text-attention">{error}</p> : null}
      <form action={onSubmit} className="flex flex-col gap-4">
        <Field label="E-mail" htmlFor="email">
          <Input id="email" name="email" type="email" autoComplete="email" />
        </Field>
        <Button type="submit" disabled={pending}>
          {pending ? 'Enviando…' : 'Enviar instruções'}
        </Button>
      </form>
      <Link href="/login" className="mt-4 inline-block text-sm text-neutral-500">
        Voltar ao login
      </Link>
    </Card>
  );
}

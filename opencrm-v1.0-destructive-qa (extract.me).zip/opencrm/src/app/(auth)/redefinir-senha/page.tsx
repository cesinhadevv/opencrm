'use client';

import { useState, Suspense } from 'react';
import { useRouter } from 'next/navigation';
import { resetPasswordAction } from '@/core/application/auth-actions';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Field } from '@/components/ui/field';
import { Card } from '@/components/ui/card';
import type { FieldErrors } from '@/core/domain/result';

/**
 * Redefinição de senha (Tech Spec A.5/A.6). O usuário chega aqui pelo link de
 * recuperação (o callback troca o token de recovery por sessão e redireciona).
 * Chama resetPasswordAction, que valida e atualiza a senha.
 */
function ResetForm() {
  const router = useRouter();
  const [errors, setErrors] = useState<FieldErrors>({});
  const [globalError, setGlobalError] = useState('');
  const [done, setDone] = useState(false);
  const [pending, setPending] = useState(false);

  async function onSubmit(formData: FormData) {
    setPending(true);
    setErrors({});
    setGlobalError('');
    const result = await resetPasswordAction({
      password: formData.get('password'),
      confirm: formData.get('confirm'),
    });
    setPending(false);
    if (result.ok) {
      setDone(true);
      setTimeout(() => router.push('/login'), 1500);
    } else if (result.fieldErrors) {
      setErrors(result.fieldErrors);
    } else {
      setGlobalError(result.message);
    }
  }

  if (done) {
    return (
      <Card>
        <h1 className="mb-2 text-xl font-semibold text-ink">Senha redefinida</h1>
        <p className="text-sm text-neutral-500">Tudo certo. Redirecionando para o login…</p>
      </Card>
    );
  }

  return (
    <Card>
      <h1 className="mb-1 text-xl font-semibold text-ink">Definir nova senha</h1>
      <p className="mb-6 text-sm text-neutral-500">Escolha uma senha que você lembre.</p>
      {globalError ? <p className="mb-4 text-sm text-urgent">{globalError}</p> : null}
      <form action={onSubmit} className="flex flex-col gap-4">
        <Field label="Nova senha" htmlFor="password" error={errors.password}>
          <Input id="password" name="password" type="password" autoComplete="new-password" />
        </Field>
        <Field label="Confirmar senha" htmlFor="confirm" error={errors.confirm}>
          <Input id="confirm" name="confirm" type="password" autoComplete="new-password" />
        </Field>
        <Button type="submit" disabled={pending}>
          {pending ? 'Salvando…' : 'Redefinir senha'}
        </Button>
      </form>
    </Card>
  );
}

export default function ResetPasswordPage() {
  return (
    <Suspense fallback={null}>
      <ResetForm />
    </Suspense>
  );
}

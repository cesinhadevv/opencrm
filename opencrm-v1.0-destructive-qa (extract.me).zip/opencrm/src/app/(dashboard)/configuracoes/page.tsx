import { Card } from '@/components/ui/card';

/** Configurações — estrutura mínima no Módulo 0 (Tech Spec C.10). */
export default function SettingsPage() {
  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="mb-6 text-2xl font-semibold text-ink">Configurações</h1>
      <Card>
        <p className="text-sm text-neutral-500">
          Em breve: estágios do funil, canais, tema e preferências da conta.
        </p>
      </Card>
    </div>
  );
}

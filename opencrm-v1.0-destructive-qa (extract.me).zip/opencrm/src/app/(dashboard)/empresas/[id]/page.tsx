import { notFound } from 'next/navigation';
import { getAccountAction } from '@/modules/accounts/application/actions';
import { getAccountTimelineAction } from '@/modules/activities/application/actions';
import { getAccountDealsAction, getPipelineAction } from '@/modules/pipeline/application/actions';
import { listProposalsByDealsAction } from '@/modules/proposals/application/actions';
import { AccountProfile } from '@/modules/accounts/presentation/account-profile';

/** Perfil da Empresa (Módulos 1+2+3): dados, canais, contatos, timeline, follow-ups, deals. */
export default async function AccountProfilePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const result = await getAccountAction(id);
  if (!result.ok) notFound();

  const [timeline, dealsResult, pipeline] = await Promise.all([
    getAccountTimelineAction(id),
    getAccountDealsAction(id),
    getPipelineAction(),
  ]);

  const dealsData = dealsResult.ok ? dealsResult.data : [];
  const proposalsResult = await listProposalsByDealsAction(dealsData.map((d) => d.id));
  const proposalsByDeal = proposalsResult.ok ? proposalsResult.data : {};

  return (
    <AccountProfile
      account={result.data}
      activities={timeline.ok ? timeline.data.activities : []}
      tasks={timeline.ok ? timeline.data.tasks : []}
      conversationState={timeline.ok ? timeline.data.conversationState : 'ok'}
      deals={dealsData}
      stages={pipeline.ok ? pipeline.data.stages : []}
      proposalsByDeal={proposalsByDeal}
    />
  );
}

import { listAccountsAction } from '@/modules/accounts/application/actions';
import { AccountList } from '@/modules/accounts/presentation/account-list';
import { NewAccountButton } from '@/modules/accounts/presentation/new-account-button';

/** Lista de Empresas (Módulo 1). */
export default async function AccountsPage() {
  const result = await listAccountsAction();
  const accounts = result.ok ? result.data : [];
  return (
    <div className="mx-auto max-w-3xl">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-ink">Empresas</h1>
        <NewAccountButton />
      </div>
      <AccountList accounts={accounts} />
    </div>
  );
}

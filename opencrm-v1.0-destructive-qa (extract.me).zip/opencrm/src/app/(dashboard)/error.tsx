'use client';

import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

/** Error boundary do dashboard. Captura falhas de Server Components/Actions e
 *  oferece recuperação, em vez da tela de erro crua do Next. */
export default function DashboardError({ reset }: { error: Error; reset: () => void }) {
  return (
    <div className="mx-auto max-w-md py-12">
      <Card className="text-center">
        <p className="text-base font-medium text-ink">Algo não saiu como esperado</p>
        <p className="mt-2 text-sm text-neutral-500">
          Tivemos um problema ao carregar esta página. Tente novamente.
        </p>
        <div className="mt-4">
          <Button onClick={reset}>Tentar de novo</Button>
        </div>
      </Card>
    </div>
  );
}

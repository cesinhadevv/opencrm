import { redirect } from 'next/navigation';
import { Sidebar } from '@/layouts/sidebar';
import { Header } from '@/layouts/header';
import { authGateway, profileRepository } from '@/core/infrastructure/services';

/**
 * Layout do dashboard (Tech Spec B.1). Shell persistente: sidebar/tab bar + header.
 * Carrega o Profile para o header. Guardas de sessão/onboarding já no middleware.
 */
export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const session = await authGateway.getSession();
  if (!session) redirect('/login');
  const profile = await profileRepository.findById(session.userId);
  if (!profile) redirect('/login');

  return (
    <div className="flex min-h-screen bg-canvas">
      <Sidebar />
      <div className="flex flex-1 flex-col pb-16 md:pb-0">
        <Header displayName={profile.displayName} />
        <main className="flex-1 p-4 md:p-6">{children}</main>
      </div>
    </div>
  );
}

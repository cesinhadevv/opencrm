import { getCockpitAction } from '@/modules/cockpit/application/cockpit-service';
import { Cockpit } from '@/modules/cockpit/presentation/cockpit';
import { Card } from '@/components/ui/card';

/** Hoje (Daily Cockpit — Módulo 4). Faixas temporais + resumo + Score. */
export default async function TodayPage() {
  const result = await getCockpitAction();
  if (!result.ok) {
    return (
      <div className="mx-auto max-w-3xl">
        <h1 className="mb-6 text-2xl font-semibold text-ink">Hoje</h1>
        <Card>
          <p className="text-sm text-neutral-500">Não foi possível carregar o cockpit.</p>
        </Card>
      </div>
    );
  }
  return <Cockpit data={result.data} />;
}

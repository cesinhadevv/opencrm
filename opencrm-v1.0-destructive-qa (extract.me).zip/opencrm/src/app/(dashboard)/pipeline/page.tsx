import { getPipelineAction } from '@/modules/pipeline/application/actions';
import { Kanban } from '@/modules/pipeline/presentation/kanban';
import { Card } from '@/components/ui/card';

/** Pipeline (Módulo 3). Kanban de oportunidades abertas (status=open). */
export default async function PipelinePage() {
  const result = await getPipelineAction();
  if (!result.ok) {
    return (
      <div className="mx-auto max-w-3xl">
        <h1 className="mb-6 text-2xl font-semibold text-ink">Pipeline</h1>
        <Card>
          <p className="text-sm text-neutral-500">Não foi possível carregar o pipeline.</p>
        </Card>
      </div>
    );
  }
  const { stages, deals } = result.data;
  return (
    <div>
      <h1 className="mb-6 text-2xl font-semibold text-ink">Pipeline</h1>
      {stages.length === 0 ? (
        <Card>
          <p className="text-sm text-neutral-500">
            Configure os estágios do seu funil para começar.
          </p>
        </Card>
      ) : (
        <Kanban stages={stages} deals={deals} />
      )}
    </div>
  );
}

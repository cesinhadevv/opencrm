import { notFound } from 'next/navigation';
import {
  getAfterSaleCustomerAction,
  listAfterSaleRecordsAction,
} from '@/modules/aftersale/application/actions';
import { AfterSaleDetail } from '@/modules/aftersale/presentation/aftersale-detail';

/** Detalhe de pós-venda de um Deal won (id = dealId). Busca apenas o cliente alvo. */
export default async function AfterSaleDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const customer = await getAfterSaleCustomerAction(id);
  if (!customer.ok) notFound();

  const records = await listAfterSaleRecordsAction(id);
  return (
    <AfterSaleDetail
      dealId={id}
      accountId={customer.data.accountId}
      accountName={customer.data.accountName}
      records={records.ok ? records.data : []}
    />
  );
}

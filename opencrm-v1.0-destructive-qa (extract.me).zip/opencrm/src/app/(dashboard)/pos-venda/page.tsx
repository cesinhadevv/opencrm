import { listAfterSaleCustomersAction } from '@/modules/aftersale/application/actions';
import { CustomerList } from '@/modules/aftersale/presentation/customer-list';
import { Card } from '@/components/ui/card';

/** Pós-venda (Módulo 8). Clientes provenientes de Deals won. */
export default async function AfterSalePage() {
  const result = await listAfterSaleCustomersAction();
  if (!result.ok) {
    return (
      <div className="mx-auto max-w-3xl">
        <h1 className="mb-6 text-2xl font-semibold text-ink">Pós-venda</h1>
        <Card>
          <p className="text-sm text-neutral-500">Não foi possível carregar.</p>
        </Card>
      </div>
    );
  }
  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="mb-6 text-2xl font-semibold text-ink">Pós-venda</h1>
      <CustomerList customers={result.data} />
    </div>
  );
}

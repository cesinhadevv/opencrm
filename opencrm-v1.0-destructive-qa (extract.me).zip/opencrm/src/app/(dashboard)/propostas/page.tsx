import { listAllProposalsAction } from '@/modules/proposals/application/actions';
import { isExpired } from '@/modules/proposals/domain/entities';
import { ProposalList } from '@/modules/proposals/presentation/proposal-list';
import { clock } from '@/core/infrastructure/services';
import { Card } from '@/components/ui/card';

/** Propostas (Módulo 5). RN-04: vencidas sinalizadas (derivado via Clock no servidor). */
export default async function ProposalsPage() {
  const result = await listAllProposalsAction();
  if (!result.ok) {
    return (
      <div className="mx-auto max-w-3xl">
        <h1 className="mb-6 text-2xl font-semibold text-ink">Propostas</h1>
        <Card>
          <p className="text-sm text-neutral-500">Não foi possível carregar as propostas.</p>
        </Card>
      </div>
    );
  }
  const proposals = result.data;
  const expiredIds = proposals.filter((p) => isExpired(clock, p)).map((p) => p.id);
  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="mb-6 text-2xl font-semibold text-ink">Propostas</h1>
      <ProposalList proposals={proposals} expiredIds={expiredIds} />
    </div>
  );
}

import { getReportAction } from '@/modules/reports/application/actions';
import type { PeriodPreset } from '@/modules/reports/application/period';
import { ReportDashboard } from '@/modules/reports/presentation/report-dashboard';
import { Card } from '@/components/ui/card';

/** Relatórios (Módulo 9). Métricas derivadas das fontes oficiais; nada persistido. */
export default async function ReportsPage({
  searchParams,
}: {
  searchParams: Promise<{ period?: string }>;
}) {
  const { period } = await searchParams;
  const preset = (period as PeriodPreset) ?? 'this_month';
  const result = await getReportAction(preset);
  if (!result.ok) {
    return (
      <div className="mx-auto max-w-4xl">
        <h1 className="mb-6 text-2xl font-semibold text-ink">Relatórios</h1>
        <Card>
          <p className="text-sm text-neutral-500">Não foi possível gerar o relatório.</p>
        </Card>
      </div>
    );
  }
  return <ReportDashboard report={result.data} />;
}

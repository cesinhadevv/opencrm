import { type NextRequest, NextResponse } from 'next/server';
import { createSupabaseServerClient } from '@/lib/supabase/server';

/**
 * Callback de autenticação (Tech Spec A.5/A.7). Troca o código por sessão.
 * - OAuth: redireciona ao app (onboarding resolvido pelo middleware).
 * - Recovery (type=recovery): redireciona à página de redefinição de senha.
 */
export async function GET(request: NextRequest) {
  const code = request.nextUrl.searchParams.get('code');
  const type = request.nextUrl.searchParams.get('type');
  if (code) {
    const supabase = await createSupabaseServerClient();
    await supabase.auth.exchangeCodeForSession(code);
  }
  const destination = type === 'recovery' ? '/redefinir-senha' : '/';
  return NextResponse.redirect(new URL(destination, request.url));
}

'use client';

/** Boundary de erro de último recurso (captura falhas no layout raiz). */
export default function GlobalError({ reset }: { error: Error; reset: () => void }) {
  return (
    <html lang="pt-BR">
      <body
        style={{
          display: 'flex',
          minHeight: '100vh',
          alignItems: 'center',
          justifyContent: 'center',
          fontFamily: 'system-ui, sans-serif',
        }}
      >
        <div style={{ textAlign: 'center' }}>
          <p style={{ fontSize: 18, fontWeight: 600 }}>Erro inesperado</p>
          <p style={{ marginTop: 8, color: '#64748b' }}>Recarregue a página para continuar.</p>
          <button
            onClick={reset}
            style={{
              marginTop: 16,
              padding: '8px 16px',
              borderRadius: 6,
              background: '#4f46e5',
              color: '#fff',
              border: 'none',
            }}
          >
            Tentar de novo
          </button>
        </div>
      </body>
    </html>
  );
}

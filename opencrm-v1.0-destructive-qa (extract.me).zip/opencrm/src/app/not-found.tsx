import Link from 'next/link';

/** Página 404 global, estilizada. */
export default function NotFound() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-canvas px-4 text-center">
      <p className="text-2xl font-semibold text-ink">Página não encontrada</p>
      <p className="mt-2 text-sm text-neutral-500">O que você procura não existe ou foi movido.</p>
      <Link href="/" className="mt-6 text-sm text-brand hover:underline">
        Voltar ao início
      </Link>
    </main>
  );
}

'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { completeOnboardingAction } from '@/core/application/onboarding-actions';
import { DEFAULT_PIPELINE_STAGES, DEFAULT_CHANNELS } from '@/core/application/seed-config';
import { CHANNEL_TYPES } from '@/lib/validation/onboarding-schemas';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Field } from '@/components/ui/field';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils/cn';

const CHANNEL_LABELS: Record<(typeof CHANNEL_TYPES)[number], string> = {
  whatsapp: 'WhatsApp',
  instagram: 'Instagram',
  linkedin: 'LinkedIn',
  email: 'E-mail',
  phone: 'Telefone',
};

/** Onboarding em 3 passos (Tech Spec A.8). Defaults permitem concluir sem fricção (<=90s). */
export default function OnboardingPage() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [displayName, setDisplayName] = useState('');
  const [channels, setChannels] = useState<string[]>([...DEFAULT_CHANNELS]);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState('');

  const timeZone =
    typeof Intl !== 'undefined'
      ? Intl.DateTimeFormat().resolvedOptions().timeZone
      : 'America/Sao_Paulo';

  function toggleChannel(type: string) {
    setChannels((prev) => (prev.includes(type) ? prev.filter((c) => c !== type) : [...prev, type]));
  }

  async function finish() {
    setPending(true);
    setError('');
    const result = await completeOnboardingAction({
      displayName: displayName.trim() || 'Vendedor',
      timeZone,
      channels,
      stages: DEFAULT_PIPELINE_STAGES.map((s) => ({ ...s })),
    });
    setPending(false);
    if (result.ok) router.push(result.data.next);
    else setError(result.message);
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-canvas px-4">
      <Card className="w-full max-w-md">
        <p className="mb-4 text-xs text-neutral-400">Passo {step} de 3</p>

        {step === 1 && (
          <div className="flex flex-col gap-4">
            <h1 className="text-xl font-semibold text-ink">Como podemos te chamar?</h1>
            <Field label="Seu nome" htmlFor="name">
              <Input
                id="name"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
              />
            </Field>
            <Button onClick={() => setStep(2)}>Continuar</Button>
          </div>
        )}

        {step === 2 && (
          <div className="flex flex-col gap-4">
            <h1 className="text-xl font-semibold text-ink">Onde você prospecta?</h1>
            <div className="flex flex-wrap gap-2">
              {CHANNEL_TYPES.map((type) => (
                <button
                  key={type}
                  onClick={() => toggleChannel(type)}
                  className={cn(
                    'rounded-button border px-3 py-2 text-sm transition-colors duration-fast',
                    channels.includes(type)
                      ? 'border-brand bg-brand/10 text-brand'
                      : 'text-neutral-600 hover:bg-neutral-100',
                  )}
                >
                  {CHANNEL_LABELS[type]}
                </button>
              ))}
            </div>
            <div className="flex gap-2">
              <Button variant="secondary" onClick={() => setStep(1)}>
                Voltar
              </Button>
              <Button onClick={() => setStep(3)}>Continuar</Button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="flex flex-col gap-4">
            <h1 className="text-xl font-semibold text-ink">Seu funil de vendas</h1>
            <p className="text-sm text-neutral-500">
              Já preparamos estágios padrão. Você pode ajustá-los depois.
            </p>
            <ul className="flex flex-col gap-1.5">
              {DEFAULT_PIPELINE_STAGES.map((s) => (
                <li
                  key={s.name}
                  className="flex justify-between rounded-button border px-3 py-2 text-sm text-ink"
                >
                  <span>{s.name}</span>
                  <span className="text-neutral-400">{s.defaultProbability}%</span>
                </li>
              ))}
            </ul>
            {error ? <p className="text-sm text-attention">{error}</p> : null}
            <div className="flex gap-2">
              <Button variant="secondary" onClick={() => setStep(2)}>
                Voltar
              </Button>
              <Button onClick={finish} disabled={pending}>
                {pending ? 'Salvando…' : 'Concluir'}
              </Button>
            </div>
          </div>
        )}
      </Card>
    </main>
  );
}

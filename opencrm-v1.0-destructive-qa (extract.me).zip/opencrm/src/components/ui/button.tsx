import { forwardRef, type ButtonHTMLAttributes } from 'react';
import { cn } from '@/lib/utils/cn';

type Variant = 'primary' | 'secondary' | 'ghost';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
}

/** Botão primitivo (Design Bible). Hierarquia: primary (1/tela) > secondary > ghost. */
const variantClasses: Record<Variant, string> = {
  primary: 'bg-brand text-white hover:opacity-90',
  secondary: 'bg-neutral-100 text-ink hover:bg-neutral-200',
  ghost: 'text-ink hover:bg-neutral-100',
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = 'primary', className, ...props },
  ref,
) {
  return (
    <button
      ref={ref}
      className={cn(
        'inline-flex h-10 items-center justify-center rounded-button px-4 text-sm font-medium',
        'transition-[opacity,background-color,transform] duration-fast active:scale-[0.98]',
        'disabled:pointer-events-none disabled:opacity-50',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand',
        variantClasses[variant],
        className,
      )}
      {...props}
    />
  );
});

import type { HTMLAttributes } from 'react';
import { cn } from '@/lib/utils/cn';

/** Card primitivo (Design Bible): borda sutil, raio, sombra quase imperceptível. */
export function Card({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn('rounded-card border bg-surface p-5 shadow-card', className)} {...props} />
  );
}

import { forwardRef, type InputHTMLAttributes } from 'react';
import { cn } from '@/lib/utils/cn';

/** Input primitivo. Foco ganha cor de marca; erro é calmo (Design Bible). */
export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(
  function Input({ className, ...props }, ref) {
    return (
      <input
        ref={ref}
        className={cn(
          'h-10 w-full rounded-button border bg-surface px-3 text-sm text-ink',
          'placeholder:text-neutral-400',
          'focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/30',
          className,
        )}
        {...props}
      />
    );
  },
);

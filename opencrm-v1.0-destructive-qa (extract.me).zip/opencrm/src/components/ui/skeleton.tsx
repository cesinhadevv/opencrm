import { cn } from '@/lib/utils/cn';

/** Skeleton de carregamento (Tech Spec C.6). Placeholder calmo, sem flicker. */
export function Skeleton({ className }: { className?: string }) {
  return <div className={cn('animate-pulse rounded-button bg-neutral-200', className)} />;
}

/** Bloco de skeletons para listas. */
export function SkeletonList({ rows = 4 }: { rows?: number }) {
  return (
    <div className="flex flex-col gap-2" aria-busy="true" aria-live="polite">
      {Array.from({ length: rows }).map((_, i) => (
        <Skeleton key={i} className="h-16 w-full" />
      ))}
    </div>
  );
}

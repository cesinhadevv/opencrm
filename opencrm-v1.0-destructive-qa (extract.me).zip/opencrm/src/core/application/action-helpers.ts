import { z } from 'zod';
import { type FieldErrors, type ActionError, failure } from '@/core/domain/result';
import { authGateway } from '@/core/infrastructure/services';

/** Converte ZodError em FieldErrors (centralizado — M4, antes duplicado ×6). */
export function toFieldErrors(error: z.ZodError): FieldErrors {
  const out: FieldErrors = {};
  for (const issue of error.issues) {
    const path = issue.path.join('.') || 'form';
    if (!out[path]) out[path] = issue.message;
  }
  return out;
}

export interface OwnerSession {
  ownerId: string;
  emailVerified: boolean;
}

/**
 * Resolve o owner autenticado (centralizado — M4, antes duplicado ×5).
 * Retorna null se não houver sessão válida.
 */
export async function resolveOwner(): Promise<OwnerSession | null> {
  const session = await authGateway.getSession();
  if (!session) return null;
  return { ownerId: session.userId, emailVerified: session.emailVerified };
}

/**
 * DR-A6: verificação de e-mail PARCIALMENTE bloqueante.
 * "Parcialmente" = não bloqueia login/onboarding/leitura, mas bloqueia ações de
 * escrita que criam compromissos externos. Retorna failure pronto se não verificado.
 * Uso: const block = requireVerifiedEmail(owner); if (block) return block;
 */

export function requireVerifiedEmail(owner: OwnerSession): ActionError | null {
  if (!owner.emailVerified) {
    return failure(
      'unauthorized',
      'Confirme seu e-mail para concluir esta ação. Reenviamos o link para você.',
    );
  }
  return null;
}

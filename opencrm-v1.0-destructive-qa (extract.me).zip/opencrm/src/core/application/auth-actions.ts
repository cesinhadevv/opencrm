'use server';

import { z } from 'zod';
import { redirect } from 'next/navigation';
import {
  signUpSchema,
  signInSchema,
  requestResetSchema,
  resetPasswordSchema,
} from '@/lib/validation/auth-schemas';
import { type ActionResult, type FieldErrors, success, failure } from '@/core/domain/result';
import { authGateway } from '@/core/infrastructure/services';

/**
 * Server Actions de autenticação (Fatia 4).
 * Fronteira: valida (Zod) -> delega ao gateway -> retorna ResultContract (B5).
 * Nunca contém regra de negócio nem lança exceção para a UI.
 * Mensagens neutras de segurança (DR-A6 / Tech Spec A.3/A.5).
 */

function toFieldErrors(error: z.ZodError): FieldErrors {
  const out: FieldErrors = {};
  for (const issue of error.issues) {
    const path = issue.path.join('.') || 'form';
    if (!out[path]) out[path] = issue.message;
  }
  return out;
}

export async function signUpAction(input: unknown): Promise<ActionResult<{ next: string }>> {
  const parsed = signUpSchema.safeParse(input);
  if (!parsed.success) {
    return failure('validation', 'Verifique os campos destacados.', toFieldErrors(parsed.error));
  }
  try {
    await authGateway.signUp(parsed.data);
    // DR-A6: verificação não-bloqueante — segue direto ao onboarding.
    return success({ next: '/onboarding' });
  } catch (error) {
    console.error('[action error]', error);
    // Mensagem neutra: não revela se o e-mail já existe (segurança).
    return failure('conflict', 'Não foi possível concluir o cadastro. Tente novamente.');
  }
}

export async function signInAction(input: unknown): Promise<ActionResult<{ next: string }>> {
  const parsed = signInSchema.safeParse(input);
  if (!parsed.success) {
    return failure('validation', 'Verifique os campos destacados.', toFieldErrors(parsed.error));
  }
  try {
    await authGateway.signIn(parsed.data);
    return success({ next: '/' });
  } catch (error) {
    console.error('[action error]', error);
    return failure('unauthorized', 'E-mail ou senha incorretos.');
  }
}

export async function signOutAction(): Promise<void> {
  try {
    await authGateway.signOut();
  } catch {
    // Logout sempre limpa o estado local mesmo em falha remota (Tech Spec A.4).
  }
  redirect('/login');
}

export async function requestPasswordResetAction(
  input: unknown,
): Promise<ActionResult<{ neutral: true }>> {
  const parsed = requestResetSchema.safeParse(input);
  if (!parsed.success) {
    return failure('validation', 'Verifique o e-mail informado.', toFieldErrors(parsed.error));
  }
  try {
    await authGateway.requestPasswordReset(parsed.data.email);
  } catch {
    // Silencioso de propósito: resposta sempre neutra (Tech Spec A.5).
  }
  return success({ neutral: true });
}

export async function resetPasswordAction(input: unknown): Promise<ActionResult<{ next: string }>> {
  const parsed = resetPasswordSchema.safeParse(input);
  if (!parsed.success) {
    return failure('validation', 'Verifique os campos destacados.', toFieldErrors(parsed.error));
  }
  try {
    await authGateway.resetPassword(parsed.data.password);
    return success({ next: '/login' });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível redefinir a senha. Tente novamente.');
  }
}

export async function googleSignInAction(): Promise<ActionResult<{ redirectUrl: string }>> {
  try {
    const { redirectUrl } = await authGateway.signInWithGoogle();
    return success({ redirectUrl });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Login com Google não concluído. Tente novamente.');
  }
}

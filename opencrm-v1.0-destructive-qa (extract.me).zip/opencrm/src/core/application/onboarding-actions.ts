'use server';

import { onboardingSchema } from '@/lib/validation/onboarding-schemas';
import { type ActionResult, success, failure } from '@/core/domain/result';
import { authGateway, profileRepository } from '@/core/infrastructure/services';
import { SupabaseOnboardingRepository } from '@/core/infrastructure/onboarding-repository';

/**
 * Onboarding (Fatia 5 / Tech Spec A.8).
 * Persiste Profile (nome, fuso), cria estágios e canais, marca onboarded=true.
 * Usa o ConfigService/repositórios existentes — nenhum mecanismo paralelo.
 */
const onboardingRepository = new SupabaseOnboardingRepository();

export async function completeOnboardingAction(
  input: unknown,
): Promise<ActionResult<{ next: string }>> {
  const session = await authGateway.getSession();
  if (!session) {
    return failure('unauthenticated', 'Sua sessão expirou. Entre novamente.');
  }

  const parsed = onboardingSchema.safeParse(input);
  if (!parsed.success) {
    return failure('validation', 'Não conseguimos salvar. Verifique os campos.');
  }

  try {
    // Ordem importa (sem transação distribuída): cria o funil/canais PRIMEIRO e só
    // então marca onboarded=true. Se o seed falhar, onboarded continua false e o
    // usuário reentra no onboarding — evita estado travado (onboarded sem funil).
    await onboardingRepository.seed({
      ownerId: session.userId,
      stages: parsed.data.stages,
      channels: parsed.data.channels,
    });
    await profileRepository.update(session.userId, {
      displayName: parsed.data.displayName,
      timeZone: parsed.data.timeZone,
      onboarded: true,
    });
    return success({ next: '/' });
  } catch (error) {
    console.error('[action error]', error);
    return failure(
      'internal',
      'Não conseguimos salvar agora. Seu progresso está guardado — tente de novo.',
    );
  }
}

export async function updateThemeAction(
  theme: 'system' | 'light' | 'dark',
): Promise<ActionResult<{ theme: string }>> {
  const session = await authGateway.getSession();
  if (!session) return failure('unauthenticated', 'Sua sessão expirou.');
  try {
    await profileRepository.update(session.userId, { theme });
    return success({ theme });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível salvar a preferência.');
  }
}

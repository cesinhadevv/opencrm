/**
 * Seed de configuração default do owner (Ambiguidade 1: defaults pertencem à
 * seed, nunca ao código de domínio; arquitetura não depende dos valores).
 *
 * Apenas o necessário ao Módulo 0: estágios default de pipeline e canais.
 * Configurações de módulos futuros (Score, thresholds, faixas) usarão o MESMO
 * ConfigService quando seus módulos chegarem.
 *
 * Probabilidades default por estágio (DR-E4) — valores de partida calibráveis.
 */
export const DEFAULT_PIPELINE_STAGES = [
  { name: 'Prospecção', defaultProbability: 10 },
  { name: 'Qualificação', defaultProbability: 30 },
  { name: 'Proposta', defaultProbability: 60 },
  { name: 'Negociação', defaultProbability: 85 },
] as const;

export const DEFAULT_CHANNELS = ['whatsapp', 'instagram', 'linkedin', 'email', 'phone'] as const;

/**
 * Contratos fundacionais — interfaces que o Domínio declara e a Infraestrutura
 * implementa (inversão de dependência, Dependency Map §1 / ADR-003).
 *
 * O Domínio depende apenas destas abstrações, nunca de Supabase, Node ou React.
 */

/** Identidade do owner resolvida a partir da sessão (ADR-005). */
export interface OwnerContext {
  ownerId: string;
}

/**
 * Clock — fonte ÚNICA de tempo (DR-A3).
 * Nenhum cálculo de "agora", "dia" ou intervalo ocorre fora de uma implementação
 * deste contrato. Armazenamento em UTC; cálculos no fuso do usuário.
 */
export interface Clock {
  /** Instante atual em UTC. */
  now(): Date;
  /** Início do dia (00:00) do usuário, em UTC, dado o fuso IANA. */
  startOfUserDay(timeZone: string, reference?: Date): Date;
  /** Dias inteiros decorridos entre dois instantes, no fuso do usuário. */
  daysBetween(from: Date, to: Date, timeZone: string): number;
}

/**
 * IdGenerator — identificadores não-enumeráveis, geráveis no cliente
 * (DR-A2, UUIDv7 ou equivalente). ADR-012: id é a única identidade.
 */
export interface IdGenerator {
  generate(): string;
}

/**
 * ConfigStore — mecanismo ÚNICO de configuração do owner
 * (Ambiguidade 1 + M2). Guarda parâmetros (valores), nunca entidades.
 * Namespaced por (namespace, key).
 */
export interface ConfigStore {
  get<T>(owner: OwnerContext, namespace: string, key: string): Promise<T | null>;
  set<T>(owner: OwnerContext, namespace: string, key: string, value: T): Promise<void>;
  list(owner: OwnerContext, namespace: string): Promise<Record<string, unknown>>;
}

/**
 * AuthGateway — identidade sobre Supabase Auth (ADR-005, DR-A6).
 * A camada de aplicação fala com este contrato, nunca com o SDK diretamente.
 */
export interface AuthSession {
  userId: string;
  email: string;
  emailVerified: boolean;
}

export interface AuthGateway {
  getSession(): Promise<AuthSession | null>;
  signUp(input: { email: string; password: string; displayName: string }): Promise<void>;
  signIn(input: { email: string; password: string }): Promise<void>;
  signOut(): Promise<void>;
  requestPasswordReset(email: string): Promise<void>;
  resetPassword(newPassword: string): Promise<void>;
  signInWithGoogle(): Promise<{ redirectUrl: string }>;
}

/** Profile — owner do sistema (DR-A3: fuso IANA; tema; onboarding). */
export interface Profile {
  id: string;
  displayName: string;
  email: string;
  timeZone: string;
  theme: 'system' | 'light' | 'dark';
  onboarded: boolean;
}

export interface ProfileRepository {
  findById(id: string): Promise<Profile | null>;
  update(
    id: string,
    patch: Partial<Pick<Profile, 'displayName' | 'timeZone' | 'theme' | 'onboarded'>>,
  ): Promise<void>;
}

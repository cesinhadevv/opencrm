/**
 * Value Objects de identificadores externos (DR-C2 / ADR-012).
 *
 * Cada identificador tem valor CANÔNICO (busca/dedupe/unicidade/regras) e
 * valor de EXIBIÇÃO (apenas UI). O canônico é a fonte de verdade; o exibição
 * é regenerável e nunca toca regra de negócio.
 *
 * ADR-012: identificadores externos NUNCA definem identidade — são atributos.
 * Domínio puro: sem I/O, determinístico, testável.
 */

export interface CanonicalIdentifier {
  canonical: string;
  display: string;
}

/** E-mail: canônico = minúsculo, sem espaços. */
export function normalizeEmail(raw: string): CanonicalIdentifier {
  const display = raw.trim();
  return { canonical: display.toLowerCase(), display };
}

/**
 * Telefone: canônico = E.164 (apenas dígitos com prefixo +).
 * País default aplicado quando não há prefixo internacional.
 * CR-004 (default de país) será formalizado no Módulo 1; aqui o default é
 * parâmetro explícito, sem número mágico.
 */
export function normalizePhone(raw: string, defaultCountryCode: string): CanonicalIdentifier {
  const display = raw.trim();
  const digits = raw.replace(/[^\d+]/g, '');
  let canonical: string;
  if (digits.startsWith('+')) {
    canonical = '+' + digits.slice(1).replace(/\D/g, '');
  } else {
    canonical = '+' + defaultCountryCode + digits.replace(/\D/g, '');
  }
  return { canonical, display };
}

/** Handle social (Instagram/LinkedIn): canônico = sem @, minúsculo, sem URL. */
export function normalizeHandle(raw: string): CanonicalIdentifier {
  const display = raw.trim();
  let canonical = display.toLowerCase();
  // Remove prefixos de URL comuns e o @.
  canonical = canonical
    .replace(/^https?:\/\/(www\.)?(instagram|linkedin)\.com\/(in\/)?/i, '')
    .replace(/^@/, '')
    .replace(/\/+$/, '');
  return { canonical, display };
}

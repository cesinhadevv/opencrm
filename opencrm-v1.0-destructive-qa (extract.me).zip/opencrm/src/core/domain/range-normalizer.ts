/**
 * Normalização por faixas — mecanismo ÚNICO (ADR-011-A / nota de Playbook).
 * Consumido pelo Score (Módulo 4). Nasce agora porque agora há consumidor real (M1).
 *
 * Contrato (congelado pelo ADR-011-A):
 *  - faixas ordenadas, contíguas, domínio coberto, sem sobreposição;
 *  - monotonicidade conforme direção declarada;
 *  - teto quando exigido;
 *  - fronteira: limite inferior INCLUSIVO, superior EXCLUSIVO.
 *
 * normalizeByRanges assume faixas já validadas. A validação ocorre na carga (fail fast).
 * Domínio puro: determinístico, sem I/O.
 */

export type RangeDirection = 'ascending' | 'descending';

export interface Range {
  /** Limite inferior inclusivo. */
  min: number;
  /** Limite superior exclusivo. Use Infinity para a faixa-teto. */
  max: number;
  /** Subscore 0-100 da faixa. */
  score: number;
}

export interface RangeSet {
  direction: RangeDirection;
  ranges: Range[];
}

export class RangeValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'RangeValidationError';
  }
}

/**
 * Valida as invariantes do ADR-011-A. Chamado na CARGA da configuração (fail fast),
 * nunca a cada cálculo. Lança RangeValidationError em violação.
 */
export function validateRangeSet(set: RangeSet): void {
  const { ranges, direction } = set;
  if (ranges.length === 0) {
    throw new RangeValidationError('Conjunto de faixas vazio.');
  }
  for (const r of ranges) {
    if (r.min >= r.max) {
      throw new RangeValidationError(`Faixa inválida: min (${r.min}) >= max (${r.max}).`);
    }
    if (r.score < 0 || r.score > 100) {
      throw new RangeValidationError(`Subscore fora de 0-100: ${r.score}.`);
    }
  }
  // Ordenação + contiguidade (sem lacuna, sem sobreposição).
  for (let i = 1; i < ranges.length; i++) {
    const prev = ranges[i - 1]!;
    const cur = ranges[i]!;
    if (cur.min !== prev.max) {
      throw new RangeValidationError(
        `Faixas não contíguas: ${prev.max} -> ${cur.min} (lacuna ou sobreposição).`,
      );
    }
  }
  // Teto: a última faixa deve cobrir até o infinito (saturação).
  const last = ranges[ranges.length - 1]!;
  if (last.max !== Infinity) {
    throw new RangeValidationError('A última faixa deve ser o teto (max = Infinity).');
  }
  // Monotonicidade conforme direção.
  for (let i = 1; i < ranges.length; i++) {
    const prev = ranges[i - 1]!;
    const cur = ranges[i]!;
    if (direction === 'ascending' && cur.score < prev.score) {
      throw new RangeValidationError('Direção ascending exige subscores não-decrescentes.');
    }
    if (direction === 'descending' && cur.score > prev.score) {
      throw new RangeValidationError('Direção descending exige subscores não-crescentes.');
    }
  }
}

/**
 * Normaliza um valor para o subscore da faixa onde ele cai.
 * Fronteira: min inclusivo, max exclusivo. Assume faixas já válidas.
 * Valores abaixo do domínio caem na primeira faixa; o teto cobre o topo.
 */
export function normalizeByRanges(value: number, set: RangeSet): number {
  const { ranges } = set;
  for (const r of ranges) {
    if (value >= r.min && value < r.max) return r.score;
  }
  // value < primeira faixa -> primeira; (o teto já cobre value muito alto via Infinity).
  return ranges[0]!.score;
}

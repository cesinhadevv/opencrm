/**
 * Resultado canônico de toda Server Action (Freeze Review B5).
 *
 * Forma discriminada: sucesso OU erro, mutuamente exclusivos.
 * Actions nunca lançam exceção para a UI; exceções são convertidas em erro aqui.
 *
 * Não altera arquitetura — materializa o contrato congelado.
 */

/** Códigos de erro de domínio (catálogo inicial — Freeze B5, extensível por código, nunca por formato). */
export type ErrorCode =
  'validation' | 'unauthenticated' | 'unauthorized' | 'not_found' | 'conflict' | 'internal';

/** Erros por campo: mapa campo -> mensagem amigável (em português). */
export type FieldErrors = Record<string, string>;

export interface ActionSuccess<T> {
  ok: true;
  data: T;
}

export interface ActionError {
  ok: false;
  code: ErrorCode;
  /** Mensagem pronta para exibição, tom calmo (Design Bible). */
  message: string;
  /** Opcional: erros por campo para validação inline. */
  fieldErrors?: FieldErrors;
}

export type ActionResult<T> = ActionSuccess<T> | ActionError;

export function success<T>(data: T): ActionSuccess<T> {
  return { ok: true, data };
}

export function failure(code: ErrorCode, message: string, fieldErrors?: FieldErrors): ActionError {
  return fieldErrors ? { ok: false, code, message, fieldErrors } : { ok: false, code, message };
}

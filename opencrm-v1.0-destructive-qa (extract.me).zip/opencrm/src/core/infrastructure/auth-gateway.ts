import { createSupabaseServerClient } from '@/lib/supabase/server';
import type { AuthGateway, AuthSession } from '@/core/domain/contracts';

/**
 * Implementação do AuthGateway sobre Supabase Auth (ADR-005, DR-A6).
 * Verificação de e-mail parcialmente bloqueante e vinculação OAuth por e-mail
 * são políticas aplicadas nas camadas de aplicação/guarda — aqui ficam as
 * operações de identidade. display_name vai nos metadados (lido pelo trigger
 * handle_new_user para provisionar o Profile atomicamente).
 */
export class SupabaseAuthGateway implements AuthGateway {
  async getSession(): Promise<AuthSession | null> {
    const supabase = await createSupabaseServerClient();
    const { data } = await supabase.auth.getUser();
    const user = data.user;
    if (!user || !user.email) return null;
    return {
      userId: user.id,
      email: user.email,
      emailVerified: Boolean(user.email_confirmed_at),
    };
  }

  async signUp(input: { email: string; password: string; displayName: string }): Promise<void> {
    const supabase = await createSupabaseServerClient();
    const { error } = await supabase.auth.signUp({
      email: input.email,
      password: input.password,
      options: { data: { display_name: input.displayName } },
    });
    if (error) throw error;
  }

  async signIn(input: { email: string; password: string }): Promise<void> {
    const supabase = await createSupabaseServerClient();
    const { error } = await supabase.auth.signInWithPassword(input);
    if (error) throw error;
  }

  async signOut(): Promise<void> {
    const supabase = await createSupabaseServerClient();
    await supabase.auth.signOut();
  }

  async requestPasswordReset(email: string): Promise<void> {
    const supabase = await createSupabaseServerClient();
    // Resposta neutra é responsabilidade da action (não revela existência — DR-A6/Tech Spec A.5).
    // redirectTo leva o link de recovery ao callback, que roteia para /redefinir-senha.
    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? '';
    await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${siteUrl}/auth/callback?type=recovery`,
    });
  }

  async resetPassword(newPassword: string): Promise<void> {
    const supabase = await createSupabaseServerClient();
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) throw error;
  }

  async signInWithGoogle(): Promise<{ redirectUrl: string }> {
    const supabase = await createSupabaseServerClient();
    const { data, error } = await supabase.auth.signInWithOAuth({ provider: 'google' });
    if (error) throw error;
    return { redirectUrl: data.url };
  }
}

import { toZonedTime } from 'date-fns-tz';
import { differenceInCalendarDays, startOfDay } from 'date-fns';
import type { Clock } from '@/core/domain/contracts';

/**
 * Implementação do Clock (DR-A3). Fonte única de tempo.
 * Armazenamento em UTC; cálculos de "dia/intervalo" no fuso IANA do usuário.
 * Início do dia comercial: 00:00 no fuso do usuário (DR-A3).
 */
export class SystemClock implements Clock {
  now(): Date {
    return new Date();
  }

  startOfUserDay(timeZone: string, reference: Date = new Date()): Date {
    const zoned = toZonedTime(reference, timeZone);
    return startOfDay(zoned);
  }

  daysBetween(from: Date, to: Date, timeZone: string): number {
    const a = toZonedTime(from, timeZone);
    const b = toZonedTime(to, timeZone);
    return Math.abs(differenceInCalendarDays(b, a));
  }
}

import { createSupabaseServerClient } from '@/lib/supabase/server';
import { ensure } from '@/lib/supabase/guard';
import type { ConfigStore, OwnerContext } from '@/core/domain/contracts';

/**
 * Implementação Supabase do ConfigStore — mecanismo ÚNICO de configuração do
 * owner (Ambiguidade 1 + M2). Guarda parâmetros (jsonb), nunca entidades.
 * Unicidade ativa por (owner, namespace, key) garantida por índice parcial (DR-B1).
 */
export class SupabaseConfigStore implements ConfigStore {
  async get<T>(owner: OwnerContext, namespace: string, key: string): Promise<T | null> {
    const supabase = await createSupabaseServerClient();
    const { data, error } = await supabase
      .from('owner_configs')
      .select('value')
      .eq('owner_id', owner.ownerId)
      .eq('namespace', namespace)
      .eq('key', key)
      .is('deleted_at', null)
      .maybeSingle();
    if (error || !data) return null;
    return data.value as T;
  }

  async set<T>(owner: OwnerContext, namespace: string, key: string, value: T): Promise<void> {
    const supabase = await createSupabaseServerClient();
    // O índice único de owner_configs é PARCIAL (where deleted_at is null), o que
    // não satisfaz ON CONFLICT do PostgREST. Fazemos upsert manual: tenta update
    // do registro ativo; se nada foi afetado, insere.
    const { data: existing } = await supabase
      .from('owner_configs')
      .select('id')
      .eq('owner_id', owner.ownerId)
      .eq('namespace', namespace)
      .eq('key', key)
      .is('deleted_at', null)
      .maybeSingle();

    if (existing) {
      ensure(
        await supabase
          .from('owner_configs')
          .update({ value: value as unknown })
          .eq('id', existing.id),
      );
    } else {
      ensure(
        await supabase.from('owner_configs').insert({
          owner_id: owner.ownerId,
          namespace,
          key,
          value: value as unknown,
        }),
      );
    }
  }

  async list(owner: OwnerContext, namespace: string): Promise<Record<string, unknown>> {
    const supabase = await createSupabaseServerClient();
    const { data, error } = await supabase
      .from('owner_configs')
      .select('key, value')
      .eq('owner_id', owner.ownerId)
      .eq('namespace', namespace)
      .is('deleted_at', null);
    if (error || !data) return {};
    return Object.fromEntries(data.map((r) => [r.key, r.value]));
  }
}

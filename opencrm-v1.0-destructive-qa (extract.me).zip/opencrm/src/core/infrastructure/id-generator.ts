import { v7 as uuidv7 } from 'uuid';
import type { IdGenerator } from '@/core/domain/contracts';

/**
 * Implementação do IdGenerator (DR-A2): UUIDv7 — não-enumerável, gerável no
 * cliente, ordenável no tempo (boa localidade de índice). ADR-012: id é identidade.
 */
export class UuidV7Generator implements IdGenerator {
  generate(): string {
    return uuidv7();
  }
}

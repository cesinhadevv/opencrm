import { createSupabaseServerClient } from '@/lib/supabase/server';
import { ensure } from '@/lib/supabase/guard';

/**
 * Persistência específica do onboarding: cria PipelineStages e Channels do owner.
 * PipelineStage é ENTIDADE (ID estável, arquivável — DR-B6), por isso vive em
 * tabela própria, não dentro do ConfigStore (M2: config referencia entidades,
 * não as contém).
 */
export interface OnboardingSeedInput {
  ownerId: string;
  stages: Array<{ name: string; defaultProbability: number }>;
  channels: string[];
}

export class SupabaseOnboardingRepository {
  async seed(input: OnboardingSeedInput): Promise<void> {
    const supabase = await createSupabaseServerClient();

    // Idempotência: se o owner já tem estágios ativos, o seed já rodou — não duplica
    // (suporta retry de onboarding após falha parcial, sem criar funil duplicado).
    const { data: existing } = await supabase
      .from('pipeline_stages')
      .select('id')
      .eq('owner_id', input.ownerId)
      .is('deleted_at', null)
      .limit(1);
    if (existing && existing.length > 0) return;

    const stageRows = input.stages.map((s, index) => ({
      owner_id: input.ownerId,
      name: s.name,
      position: index,
      default_probability: s.defaultProbability,
    }));
    if (stageRows.length > 0) {
      ensure(await supabase.from('pipeline_stages').insert(stageRows));
    }

    const channelRows = input.channels.map((type) => ({
      owner_id: input.ownerId,
      type,
      enabled: true,
    }));
    if (channelRows.length > 0) {
      ensure(await supabase.from('channels').insert(channelRows));
    }
  }
}

import { createSupabaseServerClient } from '@/lib/supabase/server';
import { ensure } from '@/lib/supabase/guard';
import type { Profile, ProfileRepository } from '@/core/domain/contracts';

/**
 * Implementação Supabase do ProfileRepository.
 * Aplica filtro de soft delete por padrão (DR-B1). RLS garante escopo de owner
 * no banco (ADR-005) — defesa em profundidade.
 */
export class SupabaseProfileRepository implements ProfileRepository {
  async findById(id: string): Promise<Profile | null> {
    const supabase = await createSupabaseServerClient();
    const { data, error } = await supabase
      .from('profiles')
      .select('id, display_name, email, time_zone, theme, onboarded')
      .eq('id', id)
      .is('deleted_at', null) // DR-B1: leitura exclui arquivados.
      .maybeSingle();

    if (error || !data) return null;
    return {
      id: data.id,
      displayName: data.display_name,
      email: data.email,
      timeZone: data.time_zone,
      theme: data.theme,
      onboarded: data.onboarded,
    };
  }

  async update(
    id: string,
    patch: Partial<Pick<Profile, 'displayName' | 'timeZone' | 'theme' | 'onboarded'>>,
  ): Promise<void> {
    const supabase = await createSupabaseServerClient();
    const row: Record<string, unknown> = {};
    if (patch.displayName !== undefined) row.display_name = patch.displayName;
    if (patch.timeZone !== undefined) row.time_zone = patch.timeZone;
    if (patch.theme !== undefined) row.theme = patch.theme;
    if (patch.onboarded !== undefined) row.onboarded = patch.onboarded;
    ensure(await supabase.from('profiles').update(row).eq('id', id).is('deleted_at', null));
  }
}

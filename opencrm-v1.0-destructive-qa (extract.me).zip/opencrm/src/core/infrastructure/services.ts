/**
 * Composition root dos serviços fundacionais.
 * Instâncias únicas, injetadas nos casos de uso. Nenhum módulo cria mecanismo
 * paralelo (Ambiguidade 1). Trocar uma implementação é trocar uma linha aqui.
 */
import { SystemClock } from './clock';
import { UuidV7Generator } from './id-generator';
import { SupabaseProfileRepository } from './profile-repository';
import { SupabaseConfigStore } from './config-store';
import { SupabaseAuthGateway } from './auth-gateway';

export const clock = new SystemClock();
export const idGenerator = new UuidV7Generator();
export const profileRepository = new SupabaseProfileRepository();
export const configStore = new SupabaseConfigStore();
export const authGateway = new SupabaseAuthGateway();

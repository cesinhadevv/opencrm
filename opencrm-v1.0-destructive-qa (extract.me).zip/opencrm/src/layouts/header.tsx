'use client';

import { useTheme } from '@/providers/theme-provider';
import { signOutAction } from '@/core/application/auth-actions';
import { Button } from '@/components/ui/button';

/**
 * Header (Tech Spec B.3). Ações globais sempre na mesma posição.
 * Busca e quick-add são shells no Módulo 0 (operam sobre zero entidades).
 */
export function Header({ displayName }: { displayName: string }) {
  const { theme, setTheme } = useTheme();
  return (
    <header className="flex h-14 items-center justify-between border-b bg-surface px-4">
      <div className="text-sm text-neutral-600">Olá, {displayName}</div>
      <div className="flex items-center gap-2">
        <Button
          variant="ghost"
          aria-label="Alternar tema"
          onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
        >
          Tema
        </Button>
        <form action={signOutAction}>
          <Button variant="secondary" type="submit">
            Sair
          </Button>
        </form>
      </div>
    </header>
  );
}

'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { availableDestinations } from '@/lib/utils/navigation';
import { cn } from '@/lib/utils/cn';

/**
 * Sidebar (desktop, >= md) / Tab bar (mobile, < md) — Tech Spec B.2.
 * Navegação aditiva: só destinos disponíveis (Freeze B7). Ativo destacado.
 */
export function Sidebar() {
  const pathname = usePathname();
  const destinations = availableDestinations();
  const primary = destinations.filter((d) => d.group === 'primary');
  const secondary = destinations.filter((d) => d.group === 'secondary');

  return (
    <>
      {/* Desktop: sidebar lateral */}
      <nav className="hidden h-full w-56 shrink-0 flex-col border-r bg-surface p-3 md:flex">
        <div className="px-2 py-3 text-lg font-semibold text-ink">OpenCRM</div>
        <div className="flex flex-col gap-0.5">
          {primary.map((d) => (
            <NavLink key={d.key} href={d.href} label={d.label} active={pathname === d.href} />
          ))}
        </div>
        <div className="my-3 border-t" />
        <div className="flex flex-col gap-0.5">
          {secondary.map((d) => (
            <NavLink key={d.key} href={d.href} label={d.label} active={pathname === d.href} />
          ))}
        </div>
      </nav>

      {/* Mobile: tab bar inferior */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 flex border-t bg-surface md:hidden">
        {destinations.slice(0, 5).map((d) => (
          <Link
            key={d.key}
            href={d.href}
            className={cn(
              'flex flex-1 items-center justify-center py-3 text-xs',
              pathname === d.href ? 'text-brand' : 'text-neutral-500',
            )}
          >
            {d.label}
          </Link>
        ))}
      </nav>
    </>
  );
}

function NavLink({ href, label, active }: { href: string; label: string; active: boolean }) {
  return (
    <Link
      href={href}
      className={cn(
        'rounded-button px-2 py-2 text-sm transition-colors duration-fast',
        active ? 'bg-neutral-100 font-medium text-brand' : 'text-neutral-600 hover:bg-neutral-100',
      )}
    >
      {label}
    </Link>
  );
}

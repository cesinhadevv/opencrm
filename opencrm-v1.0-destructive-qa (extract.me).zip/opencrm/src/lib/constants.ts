/**
 * Tetos defensivos de listagem (não são paginação interativa — são limite de
 * segurança para evitar que uma coleção degenerada degrade a página).
 * Paginação real (cursor + "carregar mais") é evolução futura, fora da V1.0.
 */
export const LIST_HARD_LIMIT = 500;
export const TIMELINE_HARD_LIMIT = 200;

import { createBrowserClient } from '@supabase/ssr';

/** Client Supabase browser-side. Usado por gateways client (ex.: OAuth redirect). */
export function createSupabaseBrowserClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
  );
}

/**
 * Guards de resultado do Supabase. O cliente JS NÃO lança em erro de banco —
 * retorna { data, error }. Estes helpers convertem erro em exceção, para que os
 * try/catch das actions funcionem e nunca retornem success() sem persistir (C1).
 */

export interface SupabaseResult<T> {
  data: T | null;
  error: { message: string; code?: string } | null;
}

/** Lança se houve erro; devolve data (possivelmente null para leituras). */
export function unwrap<T>(result: SupabaseResult<T>): T | null {
  if (result.error) {
    throw new Error(`Supabase: ${result.error.message}`);
  }
  return result.data;
}

/** Para escritas: lança se houve erro. Ignora data. */
export function ensure(result: { error: { message: string } | null }): void {
  if (result.error) {
    throw new Error(`Supabase: ${result.error.message}`);
  }
}

import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

/** Compõe classes Tailwind sem conflito (helper interno). */
export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}

/** Formata centavos -> BRL. Fonte única (M4, antes duplicado ×4). */
export function formatBRL(cents: number): string {
  return (cents / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

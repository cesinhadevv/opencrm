/** Escapa metacaracteres do LIKE/ILIKE (% e _ e \) para busca literal segura. */
export function escapeLike(input: string): string {
  return input.replace(/[\\%_]/g, (m) => `\\${m}`);
}

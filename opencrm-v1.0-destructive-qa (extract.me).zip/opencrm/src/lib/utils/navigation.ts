/**
 * Ordem fixa canônica dos destinos de navegação (Freeze B7).
 * A navegação é ADITIVA: só aparecem destinos de módulos existentes; cada um
 * ocupa sempre a mesma posição. No Módulo 0, apenas 'today' e 'settings'
 * estão disponíveis; os demais surgem com seus módulos.
 */
export interface NavDestination {
  key: string;
  label: string; // PT-BR (Design Bible)
  href: string;
  available: boolean; // Módulo existe?
  group: 'primary' | 'secondary';
}

export const NAV_DESTINATIONS: NavDestination[] = [
  { key: 'today', label: 'Hoje', href: '/', available: true, group: 'primary' },
  { key: 'accounts', label: 'Empresas', href: '/empresas', available: true, group: 'primary' },
  { key: 'pipeline', label: 'Pipeline', href: '/pipeline', available: true, group: 'primary' },
  { key: 'agenda', label: 'Agenda', href: '/agenda', available: false, group: 'primary' },
  { key: 'proposals', label: 'Propostas', href: '/propostas', available: true, group: 'primary' },
  {
    key: 'assistant',
    label: 'Assistente',
    href: '/assistente',
    available: false,
    group: 'primary',
  },
  {
    key: 'aftersale',
    label: 'Pós-venda',
    href: '/pos-venda',
    available: false,
    group: 'secondary',
  },
  {
    key: 'reports',
    label: 'Relatórios',
    href: '/relatorios',
    available: false,
    group: 'secondary',
  },
  {
    key: 'settings',
    label: 'Configurações',
    href: '/configuracoes',
    available: true,
    group: 'secondary',
  },
];

export const availableDestinations = () => NAV_DESTINATIONS.filter((d) => d.available);

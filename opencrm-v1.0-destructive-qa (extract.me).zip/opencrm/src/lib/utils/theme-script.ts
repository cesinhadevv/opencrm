/**
 * Script inline aplicado ANTES do primeiro paint — elimina o FOUC (Tech Spec C.1).
 * Resolve o tema: preferência salva (data-theme) ou preferência do sistema.
 * Inserido no <head> via dangerouslySetInnerHTML no layout raiz.
 */
export const THEME_INIT_SCRIPT = `
(function () {
  try {
    var stored = localStorage.getItem('opencrm-theme');
    var theme = stored && stored !== 'system'
      ? stored
      : (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    document.documentElement.setAttribute('data-theme', theme);
  } catch (e) {
    document.documentElement.setAttribute('data-theme', 'light');
  }
})();
`;

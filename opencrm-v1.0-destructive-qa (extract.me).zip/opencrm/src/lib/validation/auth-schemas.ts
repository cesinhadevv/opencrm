import { z } from 'zod';

/**
 * Schemas de validação de auth (ADR-003: validação na fronteira; Tech Spec A.2-A.7).
 * Compartilhados entre cliente (UX) e servidor (autoridade). Política de senha única.
 */
const PASSWORD_MIN = 8;

export const emailSchema = z
  .string()
  .trim()
  .min(1, 'Informe seu e-mail.')
  .email('Esse e-mail não parece válido.')
  .transform((v) => v.toLowerCase());

export const passwordSchema = z
  .string()
  .min(PASSWORD_MIN, `A senha precisa de pelo menos ${PASSWORD_MIN} caracteres.`);

export const signUpSchema = z.object({
  displayName: z.string().trim().min(1, 'Informe seu nome.').max(120),
  email: emailSchema,
  password: passwordSchema,
});

export const signInSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, 'Informe sua senha.'),
});

export const requestResetSchema = z.object({
  email: emailSchema,
});

export const resetPasswordSchema = z
  .object({
    password: passwordSchema,
    confirm: z.string(),
  })
  .refine((d) => d.password === d.confirm, {
    message: 'As senhas não são iguais.',
    path: ['confirm'],
  });

export type SignUpInput = z.infer<typeof signUpSchema>;
export type SignInInput = z.infer<typeof signInSchema>;

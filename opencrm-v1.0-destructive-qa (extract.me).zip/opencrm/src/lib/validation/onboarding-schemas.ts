import { z } from 'zod';

/** Schemas do onboarding (Tech Spec A.8). Defaults garantem conclusão sem fricção. */
export const CHANNEL_TYPES = ['whatsapp', 'instagram', 'linkedin', 'email', 'phone'] as const;

export const onboardingSchema = z.object({
  displayName: z.string().trim().min(1, 'Informe seu nome.').max(120),
  timeZone: z.string().min(1), // fuso IANA (DR-A3)
  channels: z.array(z.enum(CHANNEL_TYPES)).default([]),
  // Estágios: nome + probabilidade default (DR-B6/DR-E4). Defaults preenchidos na seed.
  stages: z
    .array(
      z.object({
        name: z.string().trim().min(1),
        defaultProbability: z.number().int().min(0).max(100),
      }),
    )
    .min(1),
});

export type OnboardingInput = z.infer<typeof onboardingSchema>;

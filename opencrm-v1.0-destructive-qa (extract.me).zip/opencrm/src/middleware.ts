import { type NextRequest, NextResponse } from 'next/server';
import { createSupabaseMiddlewareClient } from '@/lib/supabase/middleware';

/**
 * Guarda de rotas (Tech Spec C.9 / Permissões).
 * Matriz: autenticado × onboarding × tipo de rota. Também faz refresh de sessão.
 * O client Supabase vem de lib/supabase (zona autorizada) — middleware não
 * importa o SDK diretamente (fronteira respeitada).
 */
const AUTH_ROUTES = ['/login', '/cadastro', '/recuperar-senha', '/redefinir-senha'];
const PUBLIC_PREFIXES = ['/auth']; // callback OAuth

export async function middleware(request: NextRequest) {
  const { supabase, getResponse } = createSupabaseMiddlewareClient(request);

  const { pathname } = request.nextUrl;
  if (PUBLIC_PREFIXES.some((p) => pathname.startsWith(p))) return getResponse();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const isAuthRoute = AUTH_ROUTES.some((r) => pathname.startsWith(r));
  const isOnboarding = pathname.startsWith('/onboarding');

  if (!user && !isAuthRoute) {
    const url = request.nextUrl.clone();
    url.pathname = '/login';
    url.searchParams.set('next', pathname);
    return NextResponse.redirect(url);
  }

  if (user) {
    // M2: preferir o claim do JWT (sem ida ao banco). Fallback à query apenas
    // quando o claim não está presente (ex.: antes do hook de custom claims).
    const claimOnboarded = (user.app_metadata as { onboarded?: boolean } | undefined)?.onboarded;
    let onboardedValue: boolean;
    if (typeof claimOnboarded === 'boolean') {
      onboardedValue = claimOnboarded;
    } else {
      const { data: profile } = await supabase
        .from('profiles')
        .select('onboarded')
        .eq('id', user.id)
        .is('deleted_at', null)
        .maybeSingle();
      onboardedValue = profile?.onboarded ?? false;
    }

    if (isAuthRoute && !pathname.startsWith('/redefinir-senha')) {
      const url = request.nextUrl.clone();
      url.pathname = onboardedValue ? '/' : '/onboarding';
      url.search = '';
      return NextResponse.redirect(url);
    }
    if (!onboardedValue && !isOnboarding) {
      const url = request.nextUrl.clone();
      url.pathname = '/onboarding';
      return NextResponse.redirect(url);
    }
    if (onboardedValue && isOnboarding) {
      const url = request.nextUrl.clone();
      url.pathname = '/';
      return NextResponse.redirect(url);
    }
  }

  return getResponse();
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)'],
};

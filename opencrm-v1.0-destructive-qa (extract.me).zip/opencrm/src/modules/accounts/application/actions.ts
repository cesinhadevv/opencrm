'use server';

import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { createAccountSchema, updateAccountSchema, createContactSchema } from './schemas';
import { normalizeChannels } from './normalize-channels';
import { type ActionResult, type FieldErrors, success, failure } from '@/core/domain/result';
import {
  toFieldErrors,
  resolveOwner,
  requireVerifiedEmail,
} from '@/core/application/action-helpers';
import { authGateway, idGenerator } from '@/core/infrastructure/services';
import { SupabaseAccountRepository } from '../infrastructure/account-repository';
import type { Account, AccountListItem } from '../domain/entities';

const repo = new SupabaseAccountRepository();

export async function createAccountAction(input: unknown): Promise<ActionResult<{ id: string }>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;
  const emailBlock = requireVerifiedEmail(owner);
  if (emailBlock) return emailBlock;

  const parsed = createAccountSchema.safeParse(input);
  if (!parsed.success) {
    return failure('validation', 'Verifique os campos.', toFieldErrors(parsed.error));
  }
  try {
    const id = idGenerator.generate();
    await repo.create({
      id,
      ownerId,
      name: parsed.data.name,
      segment: parsed.data.segment ?? null,
      origin: parsed.data.origin ?? null,
      channels: normalizeChannels(idGenerator, parsed.data.channels),
    });
    revalidatePath('/empresas');
    return success({ id });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível criar a empresa. Tente novamente.');
  }
}

export async function updateAccountAction(
  id: string,
  input: unknown,
): Promise<ActionResult<{ id: string }>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;

  const parsed = updateAccountSchema.safeParse(input);
  if (!parsed.success) {
    return failure('validation', 'Verifique os campos.', toFieldErrors(parsed.error));
  }
  try {
    await repo.update(ownerId, id, parsed.data);
    revalidatePath(`/empresas/${id}`);
    revalidatePath('/empresas');
    return success({ id });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível salvar. Tente novamente.');
  }
}

export async function deleteAccountAction(id: string): Promise<ActionResult<{ id: string }>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;
  try {
    await repo.softDelete(ownerId, id);
    revalidatePath('/empresas');
    return success({ id });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível arquivar. Tente novamente.');
  }
}

export async function addContactAction(input: unknown): Promise<ActionResult<{ id: string }>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;

  const parsed = createContactSchema.safeParse(input);
  if (!parsed.success) {
    return failure('validation', 'Verifique os campos.', toFieldErrors(parsed.error));
  }
  try {
    const id = idGenerator.generate();
    await repo.addContact(ownerId, {
      id,
      accountId: parsed.data.accountId,
      name: parsed.data.name,
      role: parsed.data.role ?? null,
      isPrimary: parsed.data.isPrimary,
      channels: normalizeChannels(idGenerator, parsed.data.channels),
    });
    revalidatePath(`/empresas/${parsed.data.accountId}`);
    return success({ id });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível adicionar o contato. Tente novamente.');
  }
}

export async function listAccountsAction(
  search?: string,
): Promise<ActionResult<AccountListItem[]>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;
  try {
    return success(await repo.list(ownerId, search));
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível carregar as empresas.');
  }
}

export async function getAccountAction(id: string): Promise<ActionResult<Account>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;
  const account = await repo.findById(ownerId, id);
  if (!account) return failure('not_found', 'Empresa não encontrada.');
  return success(account);
}

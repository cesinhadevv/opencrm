import type { ChannelType } from '../domain/entities';
import { normalizeEmail, normalizePhone, normalizeHandle } from '@/core/domain/identifiers';
import type { IdGenerator } from '@/core/domain/contracts';

const DEFAULT_COUNTRY_CODE = '55'; // CR-004: default país; parametrizável futuramente.

/** Aplica normalização canônica por tipo (DR-C2). Gera id de cada canal. */
export function normalizeChannels(
  ids: IdGenerator,
  channels: Array<{ type: ChannelType; value: string }>,
) {
  return channels.map(({ type, value }) => {
    let norm;
    if (type === 'email') norm = normalizeEmail(value);
    else if (type === 'phone') norm = normalizePhone(value, DEFAULT_COUNTRY_CODE);
    else norm = normalizeHandle(value);
    return { id: ids.generate(), type, canonical: norm.canonical, display: norm.display };
  });
}

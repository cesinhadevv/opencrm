import { z } from 'zod';
import { CHANNEL_TYPES } from '@/lib/validation/onboarding-schemas';

const channelInput = z.object({
  type: z.enum(CHANNEL_TYPES),
  value: z.string().trim().min(1),
});

export const createAccountSchema = z.object({
  name: z.string().trim().min(1, 'Informe o nome da empresa.').max(160),
  segment: z.string().trim().max(120).optional().nullable(),
  origin: z.string().trim().max(80).optional().nullable(),
  channels: z.array(channelInput).default([]),
});

export const updateAccountSchema = z.object({
  name: z.string().trim().min(1).max(160).optional(),
  segment: z.string().trim().max(120).nullable().optional(),
  origin: z.string().trim().max(80).nullable().optional(),
  tags: z.array(z.string().trim().min(1)).optional(),
  notes: z.string().trim().max(4000).nullable().optional(),
});

export const createContactSchema = z.object({
  accountId: z.string().min(1),
  name: z.string().trim().min(1, 'Informe o nome do contato.').max(160),
  role: z.string().trim().max(120).optional().nullable(),
  isPrimary: z.boolean().default(false),
  channels: z.array(channelInput).default([]),
});

export type CreateAccountInput = z.infer<typeof createAccountSchema>;
export type CreateContactInput = z.infer<typeof createContactSchema>;

/**
 * Domínio — Empresas & Contatos (Módulo 1).
 * Account é a entidade central (DR-A1): pode existir sem Contacts.
 * Contact pertence a uma Account. ContactChannel guarda identificador canônico+exibição.
 * Identidade por ID interno imutável (ADR-012); identificadores externos são atributos.
 */

export type ChannelType = 'whatsapp' | 'instagram' | 'linkedin' | 'email' | 'phone';

export interface ContactChannel {
  id: string;
  type: ChannelType;
  /** Valor canônico — busca, dedupe, unicidade (DR-C2). */
  canonical: string;
  /** Valor de exibição — apenas UI (DR-C2). */
  display: string;
}

export interface Contact {
  id: string;
  accountId: string;
  name: string;
  role: string | null;
  isPrimary: boolean;
  channels: ContactChannel[];
}

export interface Account {
  id: string;
  ownerId: string;
  name: string;
  segment: string | null;
  /** Canais da própria empresa (quando ainda não há pessoa — DR-A1). */
  channels: ContactChannel[];
  origin: string | null;
  tags: string[];
  notes: string | null;
}

/** Resumo para listagem (Tech Spec: lista escaneável). */
export interface AccountListItem {
  id: string;
  name: string;
  segment: string | null;
  origin: string | null;
  contactCount: number;
}

import type { Account, AccountListItem, ChannelType } from './entities';

/** Contrato de repositório (Domínio declara, Infra implementa — ADR-003). */
export interface CreateAccountData {
  id: string;
  ownerId: string;
  name: string;
  segment: string | null;
  origin: string | null;
  channels: Array<{ id: string; type: ChannelType; canonical: string; display: string }>;
}

export interface CreateContactData {
  id: string;
  accountId: string;
  name: string;
  role: string | null;
  isPrimary: boolean;
  channels: Array<{ id: string; type: ChannelType; canonical: string; display: string }>;
}

export interface AccountRepository {
  create(data: CreateAccountData): Promise<void>;
  findById(ownerId: string, id: string): Promise<Account | null>;
  list(ownerId: string, search?: string): Promise<AccountListItem[]>;
  update(
    ownerId: string,
    id: string,
    patch: Partial<Pick<Account, 'name' | 'segment' | 'origin' | 'tags' | 'notes'>>,
  ): Promise<void>;
  softDelete(ownerId: string, id: string): Promise<void>;
  addContact(ownerId: string, data: CreateContactData): Promise<void>;
}

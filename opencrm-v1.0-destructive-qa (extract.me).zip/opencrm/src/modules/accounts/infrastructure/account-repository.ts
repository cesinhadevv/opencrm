import { createSupabaseServerClient } from '@/lib/supabase/server';
import { LIST_HARD_LIMIT, TIMELINE_HARD_LIMIT } from '@/lib/constants';
import { escapeLike } from '@/lib/utils/like';
import { ensure } from '@/lib/supabase/guard';
import type { AccountRepository, CreateAccountData, CreateContactData } from '../domain/repository';
import type { Account, AccountListItem, ContactChannel } from '../domain/entities';

/**
 * Implementação Supabase do AccountRepository.
 * Soft delete por padrão (DR-B1); RLS garante owner no banco (ADR-005).
 */
export class SupabaseAccountRepository implements AccountRepository {
  async create(data: CreateAccountData): Promise<void> {
    const supabase = await createSupabaseServerClient();
    ensure(
      await supabase.rpc('create_account_with_channels', {
        p_account_id: data.id,
        p_name: data.name,
        p_segment: data.segment,
        p_origin: data.origin,
        p_channels: data.channels.map((c) => ({
          id: c.id,
          type: c.type,
          canonical: c.canonical,
          display: c.display,
        })),
      }),
    );
  }

  async findById(ownerId: string, id: string): Promise<Account | null> {
    const supabase = await createSupabaseServerClient();
    const { data: account } = await supabase
      .from('accounts')
      .select('id, owner_id, name, segment, origin, tags, notes')
      .eq('owner_id', ownerId)
      .eq('id', id)
      .is('deleted_at', null)
      .maybeSingle();
    if (!account) return null;

    const { data: channels } = await supabase
      .from('contact_channels')
      .select('id, type, canonical, display')
      .eq('account_id', id)
      .is('deleted_at', null);

    return {
      id: account.id,
      ownerId: account.owner_id,
      name: account.name,
      segment: account.segment,
      origin: account.origin,
      tags: account.tags ?? [],
      notes: account.notes,
      channels: (channels ?? []) as ContactChannel[],
    };
  }

  async list(ownerId: string, search?: string): Promise<AccountListItem[]> {
    const supabase = await createSupabaseServerClient();
    let query = supabase
      .from('accounts')
      .select('id, name, segment, origin, contacts(count)')
      .eq('owner_id', ownerId)
      .is('deleted_at', null)
      .order('created_at', { ascending: false })
      .limit(LIST_HARD_LIMIT);
    if (search && search.trim()) {
      query = query.ilike('name', `%${escapeLike(search.trim())}%`);
    }

    const { data } = await query;
    return (data ?? []).map((row) => ({
      id: row.id,
      name: row.name,
      segment: row.segment,
      origin: row.origin,
      contactCount: Array.isArray(row.contacts) ? (row.contacts[0]?.count ?? 0) : 0,
    }));
  }

  async update(
    ownerId: string,
    id: string,
    patch: Partial<Pick<Account, 'name' | 'segment' | 'origin' | 'tags' | 'notes'>>,
  ): Promise<void> {
    const supabase = await createSupabaseServerClient();
    const row: Record<string, unknown> = {};
    if (patch.name !== undefined) row.name = patch.name;
    if (patch.segment !== undefined) row.segment = patch.segment;
    if (patch.origin !== undefined) row.origin = patch.origin;
    if (patch.tags !== undefined) row.tags = patch.tags;
    if (patch.notes !== undefined) row.notes = patch.notes;
    ensure(
      await supabase
        .from('accounts')
        .update(row)
        .eq('owner_id', ownerId)
        .eq('id', id)
        .is('deleted_at', null),
    );
  }

  async softDelete(ownerId: string, id: string): Promise<void> {
    const supabase = await createSupabaseServerClient();
    ensure(
      await supabase
        .from('accounts')
        .update({ deleted_at: new Date().toISOString() })
        .eq('owner_id', ownerId)
        .eq('id', id)
        .is('deleted_at', null),
    );
  }

  async addContact(ownerId: string, data: CreateContactData): Promise<void> {
    const supabase = await createSupabaseServerClient();
    ensure(
      await supabase.from('contacts').insert({
        id: data.id,
        owner_id: ownerId,
        account_id: data.accountId,
        name: data.name,
        role: data.role,
        is_primary: data.isPrimary,
      }),
    );
    if (data.channels.length > 0) {
      ensure(
        await supabase.from('contact_channels').insert(
          data.channels.map((c) => ({
            id: c.id,
            owner_id: ownerId,
            contact_id: data.id,
            type: c.type,
            canonical: c.canonical,
            display: c.display,
          })),
        ),
      );
    }
  }
}

'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createAccountAction } from '../application/actions';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Field } from '@/components/ui/field';
import { useToast } from '@/providers/toast-provider';
import { CHANNEL_TYPES } from '@/lib/validation/onboarding-schemas';
import type { FieldErrors } from '@/core/domain/result';

const CHANNEL_LABELS: Record<(typeof CHANNEL_TYPES)[number], string> = {
  whatsapp: 'WhatsApp',
  instagram: 'Instagram',
  linkedin: 'LinkedIn',
  email: 'E-mail',
  phone: 'Telefone',
};

/** Captura rápida de empresa (DR-A1: pode nascer só com canais, sem contato). */
export function AccountForm({ onCreated }: { onCreated?: () => void }) {
  const router = useRouter();
  const { notify } = useToast();
  const [errors, setErrors] = useState<FieldErrors>({});
  const [pending, setPending] = useState(false);
  const [channelValues, setChannelValues] = useState<Record<string, string>>({});

  async function onSubmit(formData: FormData) {
    setPending(true);
    setErrors({});
    const channels = CHANNEL_TYPES.filter((t) => channelValues[t]?.trim()).map((t) => ({
      type: t,
      value: channelValues[t]!.trim(),
    }));
    const result = await createAccountAction({
      name: formData.get('name'),
      segment: formData.get('segment') || null,
      origin: formData.get('origin') || null,
      channels,
    });
    setPending(false);
    if (result.ok) {
      notify('success', 'Empresa criada.');
      if (onCreated) onCreated();
      else router.push(`/empresas/${result.data.id}`);
    } else if (result.fieldErrors) {
      setErrors(result.fieldErrors);
    } else {
      notify('error', result.message);
    }
  }

  return (
    <form action={onSubmit} className="flex flex-col gap-4">
      <Field label="Nome da empresa" htmlFor="name" error={errors.name}>
        <Input id="name" name="name" autoFocus />
      </Field>
      <Field label="Segmento" htmlFor="segment">
        <Input id="segment" name="segment" placeholder="Varejo" />
      </Field>
      <Field label="Origem" htmlFor="origin">
        <Input id="origin" name="origin" placeholder="Instagram, indicação…" />
      </Field>
      <div className="flex flex-col gap-2">
        <span className="text-sm font-medium text-ink">Canais</span>
        {CHANNEL_TYPES.map((t) => (
          <Input
            key={t}
            placeholder={CHANNEL_LABELS[t]}
            value={channelValues[t] ?? ''}
            onChange={(e) => setChannelValues((p) => ({ ...p, [t]: e.target.value }))}
          />
        ))}
      </div>
      <Button type="submit" disabled={pending}>
        {pending ? 'Criando…' : 'Criar empresa'}
      </Button>
    </form>
  );
}

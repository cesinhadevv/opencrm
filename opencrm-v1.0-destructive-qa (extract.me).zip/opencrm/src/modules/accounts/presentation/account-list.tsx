'use client';

import Link from 'next/link';
import type { AccountListItem } from '../domain/entities';
import { Card } from '@/components/ui/card';

/** Lista escaneável de empresas (Tech Spec). Estado vazio ensina o próximo passo. */
export function AccountList({ accounts }: { accounts: AccountListItem[] }) {
  if (accounts.length === 0) {
    return (
      <Card className="text-center">
        <p className="text-base font-medium text-ink">Nenhuma empresa ainda</p>
        <p className="mt-2 text-sm text-neutral-500">
          Adicione sua primeira empresa para começar a organizar suas vendas.
        </p>
      </Card>
    );
  }
  return (
    <ul className="flex flex-col gap-2">
      {accounts.map((a) => (
        <li key={a.id}>
          <Link
            href={`/empresas/${a.id}`}
            className="flex items-center justify-between rounded-card border bg-surface p-4 transition-shadow duration-fast hover:shadow-card"
          >
            <div>
              <p className="font-medium text-ink">{a.name}</p>
              <p className="text-sm text-neutral-500">
                {[a.segment, a.origin].filter(Boolean).join(' · ') || 'Sem detalhes'}
              </p>
            </div>
            <span className="text-sm text-neutral-400">
              {a.contactCount} {a.contactCount === 1 ? 'contato' : 'contatos'}
            </span>
          </Link>
        </li>
      ))}
    </ul>
  );
}

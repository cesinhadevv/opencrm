'use client';

import { useRouter } from 'next/navigation';
import type { Account } from '../domain/entities';
import { deleteAccountAction } from '../application/actions';
import { ContactForm } from './contact-form';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/providers/toast-provider';
import type { Activity, Task, ConversationState } from '@/modules/activities/domain/entities';
import { ConversationBadge } from '@/modules/activities/presentation/conversation-badge';
import { Timeline } from '@/modules/activities/presentation/timeline';
import { RegisterActivity } from '@/modules/activities/presentation/register-activity';
import { TaskList } from '@/modules/activities/presentation/task-list';
import { CreateTask } from '@/modules/activities/presentation/create-task';
import type { Deal, PipelineStage } from '@/modules/pipeline/domain/entities';
import { DealForm } from '@/modules/pipeline/presentation/deal-form';
import { DealCloseActions } from '@/modules/pipeline/presentation/deal-actions';
import { formatBRL } from '@/modules/pipeline/presentation/format';
import type { Proposal } from '@/modules/proposals/domain/entities';
import { DealProposals } from '@/modules/proposals/presentation/deal-proposals';

const CHANNEL_LABELS: Record<string, string> = {
  whatsapp: 'WhatsApp',
  instagram: 'Instagram',
  linkedin: 'LinkedIn',
  email: 'E-mail',
  phone: 'Telefone',
};

/**
 * Perfil da Empresa — Perfil 360° (Tech Spec §7). Módulos 1+2: dados, canais,
 * contatos, timeline (Activity) e follow-ups (Task). Propostas/IA: módulos seguintes.
 */
export function AccountProfile({
  account,
  activities,
  tasks,
  conversationState,
  deals,
  stages,
  proposalsByDeal,
}: {
  account: Account;
  activities: Activity[];
  tasks: Task[];
  conversationState: ConversationState;
  deals: Deal[];
  stages: PipelineStage[];
  proposalsByDeal: Record<string, Proposal[]>;
}) {
  const router = useRouter();
  const { notify } = useToast();

  async function onArchive() {
    const result = await deleteAccountAction(account.id);
    if (result.ok) {
      notify('success', 'Empresa arquivada.');
      router.push('/empresas');
    } else {
      notify('error', result.message);
    }
  }

  return (
    <div className="mx-auto max-w-4xl">
      <div className="mb-6 flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-semibold text-ink">{account.name}</h1>
            <ConversationBadge state={conversationState} />
          </div>
          <p className="text-sm text-neutral-500">
            {[account.segment, account.origin].filter(Boolean).join(' · ') || 'Sem detalhes'}
          </p>
        </div>
        <Button variant="ghost" onClick={onArchive}>
          Arquivar
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        {/* Coluna esquerda: dados e canais */}
        <div className="flex flex-col gap-4">
          <Card>
            <h2 className="mb-3 text-sm font-semibold text-ink">Canais</h2>
            {account.channels.length === 0 ? (
              <p className="text-sm text-neutral-500">Nenhum canal cadastrado.</p>
            ) : (
              <ul className="flex flex-col gap-2">
                {account.channels.map((c) => (
                  <li key={c.id} className="flex justify-between text-sm">
                    <span className="text-neutral-500">{CHANNEL_LABELS[c.type] ?? c.type}</span>
                    <span className="text-ink">{c.display}</span>
                  </li>
                ))}
              </ul>
            )}
          </Card>
          <Card>
            <h2 className="mb-3 text-sm font-semibold text-ink">Contatos</h2>
            <ContactForm accountId={account.id} />
          </Card>
        </div>

        {/* Centro: timeline */}
        <div className="md:col-span-1">
          <Card>
            <h2 className="mb-3 text-sm font-semibold text-ink">Histórico</h2>
            <RegisterActivity accountId={account.id} />
            <div className="mt-4">
              <Timeline activities={activities} />
            </div>
          </Card>
        </div>

        {/* Direita: follow-ups */}
        <div className="flex flex-col gap-4">
          <Card>
            <h2 className="mb-3 text-sm font-semibold text-ink">Próximas ações</h2>
            <TaskList tasks={tasks} accountId={account.id} />
            <div className="mt-3">
              <CreateTask accountId={account.id} />
            </div>
          </Card>
          <Card>
            <h2 className="mb-3 text-sm font-semibold text-ink">Oportunidades</h2>
            {deals.length === 0 ? (
              <p className="mb-3 text-sm text-neutral-500">Nenhuma oportunidade ainda.</p>
            ) : (
              <ul className="mb-3 flex flex-col gap-2">
                {deals.map((d) => (
                  <li key={d.id} className="rounded-button border px-3 py-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-ink">{d.title}</span>
                      <span className="text-xs text-neutral-400">{formatBRL(d.value)}</span>
                    </div>
                    <div className="mt-1">
                      <DealCloseActions deal={d} />
                    </div>
                    <div className="mt-2">
                      <DealProposals dealId={d.id} proposals={proposalsByDeal[d.id] ?? []} />
                    </div>
                  </li>
                ))}
              </ul>
            )}
            <DealForm accountId={account.id} stages={stages} />
          </Card>
          {account.notes ? (
            <Card>
              <h2 className="mb-2 text-sm font-semibold text-ink">Anotações</h2>
              <p className="text-sm text-neutral-500">{account.notes}</p>
            </Card>
          ) : null}
        </div>
      </div>
    </div>
  );
}

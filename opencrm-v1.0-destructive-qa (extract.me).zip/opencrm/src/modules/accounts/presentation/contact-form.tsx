'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { addContactAction } from '../application/actions';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Field } from '@/components/ui/field';
import { useToast } from '@/providers/toast-provider';
import { CHANNEL_TYPES } from '@/lib/validation/onboarding-schemas';
import type { FieldErrors } from '@/core/domain/result';

/** Adiciona contato (pessoa) a uma empresa (DR-A1). */
export function ContactForm({ accountId }: { accountId: string }) {
  const router = useRouter();
  const { notify } = useToast();
  const [errors, setErrors] = useState<FieldErrors>({});
  const [pending, setPending] = useState(false);
  const [channelValues, setChannelValues] = useState<Record<string, string>>({});
  const [open, setOpen] = useState(false);

  async function onSubmit(formData: FormData) {
    setPending(true);
    setErrors({});
    const channels = CHANNEL_TYPES.filter((t) => channelValues[t]?.trim()).map((t) => ({
      type: t,
      value: channelValues[t]!.trim(),
    }));
    const result = await addContactAction({
      accountId,
      name: formData.get('name'),
      role: formData.get('role') || null,
      isPrimary: formData.get('isPrimary') === 'on',
      channels,
    });
    setPending(false);
    if (result.ok) {
      notify('success', 'Contato adicionado.');
      setOpen(false);
      setChannelValues({});
      router.refresh();
    } else if (result.fieldErrors) {
      setErrors(result.fieldErrors);
    } else {
      notify('error', result.message);
    }
  }

  if (!open) {
    return (
      <Button variant="secondary" onClick={() => setOpen(true)}>
        Adicionar contato
      </Button>
    );
  }

  return (
    <form action={onSubmit} className="flex flex-col gap-3 rounded-card border bg-surface p-4">
      <Field label="Nome" htmlFor="c-name" error={errors.name}>
        <Input id="c-name" name="name" autoFocus />
      </Field>
      <Field label="Cargo" htmlFor="c-role">
        <Input id="c-role" name="role" placeholder="Decisor, comprador…" />
      </Field>
      <label className="flex items-center gap-2 text-sm text-ink">
        <input type="checkbox" name="isPrimary" id="isPrimary" /> Contato principal
      </label>
      {CHANNEL_TYPES.map((t) => (
        <Input
          key={t}
          placeholder={t}
          value={channelValues[t] ?? ''}
          onChange={(e) => setChannelValues((p) => ({ ...p, [t]: e.target.value }))}
        />
      ))}
      <div className="flex gap-2">
        <Button variant="ghost" type="button" onClick={() => setOpen(false)}>
          Cancelar
        </Button>
        <Button type="submit" disabled={pending}>
          {pending ? 'Salvando…' : 'Salvar contato'}
        </Button>
      </div>
    </form>
  );
}

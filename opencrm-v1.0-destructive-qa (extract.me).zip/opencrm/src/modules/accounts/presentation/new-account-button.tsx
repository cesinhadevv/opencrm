'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { AccountForm } from './account-form';

/** Botão + overlay simples para nova empresa (uma sobreposição por vez — Princípio 7). */
export function NewAccountButton() {
  const [open, setOpen] = useState(false);
  const router = useRouter();
  return (
    <>
      <Button onClick={() => setOpen(true)}>Nova empresa</Button>
      {open && (
        <div
          className="fixed inset-0 z-50 flex items-start justify-center bg-ink/20 p-4 pt-20"
          onClick={() => setOpen(false)}
        >
          <div
            className="w-full max-w-md rounded-container border bg-surface p-6 shadow-overlay"
            onClick={(e) => e.stopPropagation()}
          >
            <h2 className="mb-4 text-lg font-semibold text-ink">Nova empresa</h2>
            <AccountForm
              onCreated={() => {
                setOpen(false);
                router.refresh();
              }}
            />
          </div>
        </div>
      )}
    </>
  );
}

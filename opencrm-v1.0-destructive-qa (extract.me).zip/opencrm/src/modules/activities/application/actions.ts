'use server';

import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { createActivitySchema, createTaskSchema } from './schemas';
import { deriveConversationState } from '../domain/conversation-state';
import { getConversationThresholds } from './conversation-config';
import { type ActionResult, type FieldErrors, success, failure } from '@/core/domain/result';
import { toFieldErrors, resolveOwner } from '@/core/application/action-helpers';
import { idGenerator, clock, profileRepository } from '@/core/infrastructure/services';
import { SupabaseActivityRepository } from '../infrastructure/activity-repository';
import { SupabaseTaskRepository } from '../infrastructure/task-repository';
import type { Activity, Task, ConversationState } from '../domain/entities';

const activityRepo = new SupabaseActivityRepository();
const taskRepo = new SupabaseTaskRepository();

export async function registerActivityAction(
  input: unknown,
): Promise<ActionResult<{ id: string }>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;

  const parsed = createActivitySchema.safeParse(input);
  if (!parsed.success) {
    return failure('validation', 'Verifique os campos.', toFieldErrors(parsed.error));
  }
  try {
    const id = idGenerator.generate();
    await activityRepo.createActivity({
      id,
      ownerId,
      accountId: parsed.data.accountId,
      contactId: parsed.data.contactId ?? null,
      dealId: parsed.data.dealId ?? null,
      channel: parsed.data.channel ?? null,
      direction: parsed.data.direction,
      source: 'manual',
      content: parsed.data.content,
      occurredAt: parsed.data.occurredAt ? new Date(parsed.data.occurredAt) : clock.now(),
    });
    revalidatePath(`/empresas/${parsed.data.accountId}`);
    return success({ id });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível registrar. Tente novamente.');
  }
}

export async function createTaskAction(input: unknown): Promise<ActionResult<{ id: string }>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;

  const parsed = createTaskSchema.safeParse(input);
  if (!parsed.success) {
    return failure('validation', 'Verifique os campos.', toFieldErrors(parsed.error));
  }
  try {
    const id = idGenerator.generate();
    await taskRepo.createTask({
      id,
      ownerId,
      accountId: parsed.data.accountId,
      dealId: parsed.data.dealId ?? null,
      title: parsed.data.title,
      dueAt: new Date(parsed.data.dueAt),
      priority: parsed.data.priority,
    });
    revalidatePath(`/empresas/${parsed.data.accountId}`);
    return success({ id });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível criar a tarefa. Tente novamente.');
  }
}

export async function completeTaskAction(
  id: string,
  accountId: string,
): Promise<ActionResult<{ id: string }>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;
  try {
    await taskRepo.markDone(ownerId, id);
    revalidatePath(`/empresas/${accountId}`);
    return success({ id });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível concluir.');
  }
}

export async function rescheduleTaskAction(
  id: string,
  accountId: string,
  dueAt: string,
): Promise<ActionResult<{ id: string }>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;
  try {
    await taskRepo.reschedule(ownerId, id, new Date(dueAt));
    revalidatePath(`/empresas/${accountId}`);
    return success({ id });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível reagendar.');
  }
}

export async function getAccountTimelineAction(
  accountId: string,
): Promise<
  ActionResult<{ activities: Activity[]; tasks: Task[]; conversationState: ConversationState }>
> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;
  try {
    const [activities, tasks] = await Promise.all([
      activityRepo.listByAccount(ownerId, accountId),
      taskRepo.listOpenByAccount(ownerId, accountId),
    ]);
    // DR-B4: estado conversacional derivado no domínio; a action apenas orquestra
    // (lê thresholds da config, chama a regra pura). A UI recebe o estado pronto.
    const profile = await profileRepository.findById(ownerId);
    const timeZone = profile?.timeZone ?? 'America/Sao_Paulo';
    const thresholds = await getConversationThresholds({ ownerId });
    const conversationState = deriveConversationState(
      clock,
      timeZone,
      thresholds,
      activities,
      tasks,
    );
    return success({ activities, tasks, conversationState });
  } catch (error) {
    console.error('[getAccountTimelineAction]', error);
    return failure('internal', 'Não foi possível carregar o histórico.');
  }
}

import type { OwnerContext } from '@/core/domain/contracts';
import { configStore } from '@/core/infrastructure/services';
import type { ConversationThresholds } from '../domain/conversation-state';

/**
 * Thresholds de estado conversacional (DR-B4). Defaults na seed; configuráveis
 * via ConfigService único (namespace 'conversation'). Nenhum mecanismo paralelo.
 * X = dias para "esfriando"; Y = dias para "sem retorno".
 */
export const DEFAULT_CONVERSATION_THRESHOLDS: ConversationThresholds = {
  coolingDays: 7,
  noReplyDays: 3,
};

export async function getConversationThresholds(
  owner: OwnerContext,
): Promise<ConversationThresholds> {
  const stored = await configStore.get<ConversationThresholds>(owner, 'conversation', 'thresholds');
  return stored && typeof stored.coolingDays === 'number'
    ? stored
    : DEFAULT_CONVERSATION_THRESHOLDS;
}

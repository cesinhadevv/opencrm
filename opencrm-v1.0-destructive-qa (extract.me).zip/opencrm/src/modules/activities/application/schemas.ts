import { z } from 'zod';
import { CHANNEL_TYPES } from '@/lib/validation/onboarding-schemas';

export const createActivitySchema = z.object({
  accountId: z.string().min(1),
  contactId: z.string().min(1).nullable().optional(),
  dealId: z.string().min(1).nullable().optional(),
  channel: z.enum(CHANNEL_TYPES).nullable().optional(),
  direction: z.enum(['outbound', 'inbound', 'internal_note']),
  content: z.string().trim().min(1, 'Descreva a interação.').max(4000),
  // occurredAt opcional: default "agora" (default inteligente — UX).
  occurredAt: z.string().datetime().optional(),
});

export const createTaskSchema = z.object({
  accountId: z.string().min(1),
  dealId: z.string().min(1).nullable().optional(),
  title: z.string().trim().min(1, 'Descreva a tarefa.').max(200),
  dueAt: z.string().datetime(),
  priority: z.number().int().min(0).max(1).default(0),
});

export type CreateActivityInput = z.infer<typeof createActivitySchema>;
export type CreateTaskInput = z.infer<typeof createTaskSchema>;

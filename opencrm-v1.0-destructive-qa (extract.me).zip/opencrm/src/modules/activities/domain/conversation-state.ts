import type { Clock } from '@/core/domain/contracts';
import {
  type Activity,
  type Task,
  type ConversationState,
  type TaskBand,
  isRealInteraction,
} from './entities';

/**
 * Regras puras de derivação temporal (DR-B4 / DR-A3). Determinísticas e testáveis.
 * Thresholds X (esfriando) e Y (sem retorno) são parâmetros (vêm da config do owner).
 */

export interface ConversationThresholds {
  coolingDays: number; // X
  noReplyDays: number; // Y
}

/**
 * Estado conversacional de uma account/deal, em ordem de precedência:
 *   followup_overdue > no_reply > cooling > ok  (DR-B4)
 */
export function deriveConversationState(
  clock: Clock,
  timeZone: string,
  thresholds: ConversationThresholds,
  realActivities: Activity[], // já filtradas? não — filtramos aqui por segurança
  openTasks: Task[],
): ConversationState {
  const now = clock.now();

  // 1) Follow-up vencido: existe Task open cuja dueAt já passou (prioridade máxima).
  const hasOverdue = openTasks.some(
    (t) => t.status === 'open' && t.dueAt.getTime() < now.getTime(),
  );
  if (hasOverdue) return 'followup_overdue';

  const real = realActivities.filter((a) => isRealInteraction(a.direction));
  const lastReal = real.reduce<Activity | null>(
    (acc, a) => (!acc || a.occurredAt > acc.occurredAt ? a : acc),
    null,
  );

  // 2) Sem retorno: última interação real foi inbound, sem outbound posterior, > Y dias.
  if (lastReal && lastReal.direction === 'inbound') {
    const days = clock.daysBetween(lastReal.occurredAt, now, timeZone);
    if (days >= thresholds.noReplyDays) return 'no_reply';
  }

  // 3) Esfriando: nenhuma interação real há > X dias.
  if (!lastReal) return 'cooling';
  const idleDays = clock.daysBetween(lastReal.occurredAt, now, timeZone);
  if (idleDays >= thresholds.coolingDays) return 'cooling';

  return 'ok';
}

/** Classifica uma Task em faixa temporal (DR-A3). */
export function classifyTaskBand(clock: Clock, timeZone: string, task: Task): TaskBand {
  const now = clock.now();
  const startToday = clock.startOfUserDay(timeZone, now);
  const due = task.dueAt;

  if (due.getTime() < startToday.getTime()) return 'overdue';

  const days = clock.daysBetween(startToday, due, timeZone);
  if (days === 0) return 'today';
  if (days <= 7) return 'this_week';
  return 'upcoming';
}

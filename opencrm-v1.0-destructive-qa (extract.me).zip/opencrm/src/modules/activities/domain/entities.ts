/**
 * Domínio — Atividades & Follow-ups (Módulo 2).
 *
 * Activity = passado imutável (o que aconteceu). Task = futuro (o que fazer).
 * Activity tem direction (enviada/recebida/nota interna) e source (manual/importada) — DR-B4.
 * Estados conversacionais derivados (DR-B4): Follow-up vencido > Sem retorno > Esfriando.
 * Notas internas NÃO contam como interação real (RN-17).
 *
 * Identidade por ID interno (ADR-012). Cálculos temporais via Clock (DR-A3) — o
 * domínio recebe valores já calculados ou o Clock por contrato, nunca calcula data sozinho.
 */
import type { ChannelType } from '@/modules/accounts/domain/entities';

export type ActivityDirection = 'outbound' | 'inbound' | 'internal_note';
export type ActivitySource = 'manual' | 'imported';

export interface Activity {
  id: string;
  ownerId: string;
  accountId: string;
  contactId: string | null;
  dealId: string | null;
  channel: ChannelType | null;
  direction: ActivityDirection;
  source: ActivitySource;
  content: string;
  occurredAt: Date;
}

export type TaskStatus = 'open' | 'done';

export interface Task {
  id: string;
  ownerId: string;
  accountId: string;
  dealId: string | null;
  title: string;
  dueAt: Date;
  status: TaskStatus;
  priority: number; // 0 normal, 1 alta
}

/** Faixa temporal do Cockpit/Agenda (DR-A3). */
export type TaskBand = 'overdue' | 'today' | 'this_week' | 'upcoming';

/** Estado conversacional derivado (DR-B4), em ordem de precedência decrescente. */
export type ConversationState = 'followup_overdue' | 'no_reply' | 'cooling' | 'ok';

/** Direções que contam como interação real (RN-17: nota interna não conta). */
export function isRealInteraction(direction: ActivityDirection): boolean {
  return direction === 'outbound' || direction === 'inbound';
}

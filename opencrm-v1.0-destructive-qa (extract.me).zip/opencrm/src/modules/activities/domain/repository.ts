import type { Activity, ActivityDirection, ActivitySource, Task } from './entities';
import type { ChannelType } from '@/modules/accounts/domain/entities';

export interface CreateActivityData {
  id: string;
  ownerId: string;
  accountId: string;
  contactId: string | null;
  dealId: string | null;
  channel: ChannelType | null;
  direction: ActivityDirection;
  source: ActivitySource;
  content: string;
  occurredAt: Date;
}

export interface CreateTaskData {
  id: string;
  ownerId: string;
  accountId: string;
  dealId: string | null;
  title: string;
  dueAt: Date;
  priority: number;
}

export interface ActivityRepository {
  createActivity(data: CreateActivityData): Promise<void>;
  listByAccount(ownerId: string, accountId: string): Promise<Activity[]>;
}

export interface TaskRepository {
  createTask(data: CreateTaskData): Promise<void>;
  listOpenByAccount(ownerId: string, accountId: string): Promise<Task[]>;
  listOpen(ownerId: string): Promise<Task[]>;
  markDone(ownerId: string, id: string): Promise<void>;
  reschedule(ownerId: string, id: string, dueAt: Date): Promise<void>;
}

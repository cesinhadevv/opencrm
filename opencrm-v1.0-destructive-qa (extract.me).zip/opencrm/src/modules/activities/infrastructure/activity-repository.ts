import { createSupabaseServerClient } from '@/lib/supabase/server';
import { LIST_HARD_LIMIT, TIMELINE_HARD_LIMIT } from '@/lib/constants';
import { ensure } from '@/lib/supabase/guard';
import type { ActivityRepository, CreateActivityData } from '../domain/repository';
import type { Activity } from '../domain/entities';

export class SupabaseActivityRepository implements ActivityRepository {
  async createActivity(data: CreateActivityData): Promise<void> {
    const supabase = await createSupabaseServerClient();
    ensure(
      await supabase.from('activities').insert({
        id: data.id,
        owner_id: data.ownerId,
        account_id: data.accountId,
        contact_id: data.contactId,
        deal_id: data.dealId,
        channel: data.channel,
        direction: data.direction,
        source: data.source,
        content: data.content,
        occurred_at: data.occurredAt.toISOString(),
      }),
    );
  }

  async listByAccount(ownerId: string, accountId: string): Promise<Activity[]> {
    const supabase = await createSupabaseServerClient();
    const { data } = await supabase
      .from('activities')
      .select(
        'id, owner_id, account_id, contact_id, deal_id, channel, direction, source, content, occurred_at',
      )
      .eq('owner_id', ownerId)
      .eq('account_id', accountId)
      .is('deleted_at', null)
      .order('occurred_at', { ascending: false })
      .limit(TIMELINE_HARD_LIMIT);
    return (data ?? []).map((r) => ({
      id: r.id,
      ownerId: r.owner_id,
      accountId: r.account_id,
      contactId: r.contact_id,
      dealId: r.deal_id,
      channel: r.channel,
      direction: r.direction,
      source: r.source,
      content: r.content,
      occurredAt: new Date(r.occurred_at),
    }));
  }
}

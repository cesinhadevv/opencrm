import { createSupabaseServerClient } from '@/lib/supabase/server';
import { ensure } from '@/lib/supabase/guard';
import type { TaskRepository, CreateTaskData } from '../domain/repository';
import type { Task } from '../domain/entities';

function mapTask(r: {
  id: string;
  owner_id: string;
  account_id: string;
  deal_id: string | null;
  title: string;
  due_at: string;
  status: 'open' | 'done';
  priority: number;
}): Task {
  return {
    id: r.id,
    ownerId: r.owner_id,
    accountId: r.account_id,
    dealId: r.deal_id,
    title: r.title,
    dueAt: new Date(r.due_at),
    status: r.status,
    priority: r.priority,
  };
}

const COLS = 'id, owner_id, account_id, deal_id, title, due_at, status, priority';

export class SupabaseTaskRepository implements TaskRepository {
  async createTask(data: CreateTaskData): Promise<void> {
    const supabase = await createSupabaseServerClient();
    ensure(
      await supabase.from('tasks').insert({
        id: data.id,
        owner_id: data.ownerId,
        account_id: data.accountId,
        deal_id: data.dealId,
        title: data.title,
        due_at: data.dueAt.toISOString(),
        priority: data.priority,
      }),
    );
  }

  async listOpenByAccount(ownerId: string, accountId: string): Promise<Task[]> {
    const supabase = await createSupabaseServerClient();
    const { data } = await supabase
      .from('tasks')
      .select(COLS)
      .eq('owner_id', ownerId)
      .eq('account_id', accountId)
      .eq('status', 'open')
      .is('deleted_at', null)
      .order('due_at', { ascending: true });
    return (data ?? []).map(mapTask);
  }

  async listOpen(ownerId: string): Promise<Task[]> {
    const supabase = await createSupabaseServerClient();
    const { data } = await supabase
      .from('tasks')
      .select(COLS)
      .eq('owner_id', ownerId)
      .eq('status', 'open')
      .is('deleted_at', null)
      .order('due_at', { ascending: true });
    return (data ?? []).map(mapTask);
  }

  async markDone(ownerId: string, id: string): Promise<void> {
    const supabase = await createSupabaseServerClient();
    ensure(
      await supabase
        .from('tasks')
        .update({ status: 'done' })
        .eq('owner_id', ownerId)
        .eq('id', id)
        .is('deleted_at', null),
    );
  }

  async reschedule(ownerId: string, id: string, dueAt: Date): Promise<void> {
    const supabase = await createSupabaseServerClient();
    ensure(
      await supabase
        .from('tasks')
        .update({ due_at: dueAt.toISOString() })
        .eq('owner_id', ownerId)
        .eq('id', id)
        .is('deleted_at', null),
    );
  }
}

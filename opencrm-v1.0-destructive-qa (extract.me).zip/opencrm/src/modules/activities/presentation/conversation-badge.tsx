import type { ConversationState } from '../domain/entities';

/**
 * Badge de estado conversacional (DR-B4). Componente PURO de apresentação:
 * recebe o estado já derivado no domínio/aplicação e apenas o renderiza.
 * Nenhuma regra de negócio aqui.
 */
const LABELS: Record<ConversationState, { text: string; cls: string } | null> = {
  followup_overdue: { text: 'Follow-up vencido', cls: 'bg-urgent/10 text-urgent' },
  no_reply: { text: 'Sem retorno', cls: 'bg-attention/10 text-attention' },
  cooling: { text: 'Esfriando', cls: 'bg-attention/10 text-attention' },
  ok: null,
};

export function ConversationBadge({ state }: { state: ConversationState }) {
  const label = LABELS[state];
  if (!label) return null;
  return (
    <span className={`rounded-button px-2 py-0.5 text-xs font-medium ${label.cls}`}>
      {label.text}
    </span>
  );
}

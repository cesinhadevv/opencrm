'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createTaskAction } from '../application/actions';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/providers/toast-provider';

/** Criação de follow-up (a "regra do próximo passo" — RN-01/RN-02). */
export function CreateTask({ accountId }: { accountId: string }) {
  const router = useRouter();
  const { notify } = useToast();
  const [title, setTitle] = useState('');
  const [dueAt, setDueAt] = useState('');
  const [pending, setPending] = useState(false);

  async function submit() {
    if (!title.trim() || !dueAt) return;
    setPending(true);
    const result = await createTaskAction({
      accountId,
      title,
      dueAt: new Date(dueAt).toISOString(),
    });
    setPending(false);
    if (result.ok) {
      notify('success', 'Follow-up agendado.');
      setTitle('');
      setDueAt('');
      router.refresh();
    } else {
      notify('error', result.message);
    }
  }

  return (
    <div className="flex flex-col gap-2 rounded-card border bg-surface p-4">
      <Input
        placeholder="Próxima ação (ex: Ligar para confirmar)"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      <input
        type="datetime-local"
        aria-label="Data e hora"
        value={dueAt}
        onChange={(e) => setDueAt(e.target.value)}
        className="h-10 rounded-button border bg-surface px-3 text-sm text-ink focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/30"
      />
      <div className="flex justify-end">
        <Button onClick={submit} disabled={pending || !title.trim() || !dueAt}>
          {pending ? 'Agendando…' : 'Agendar follow-up'}
        </Button>
      </div>
    </div>
  );
}

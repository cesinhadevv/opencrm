'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { registerActivityAction } from '../application/actions';
import type { ActivityDirection } from '../domain/entities';
import { Button } from '@/components/ui/button';
import { useToast } from '@/providers/toast-provider';

const DIRECTIONS: { value: ActivityDirection; label: string }[] = [
  { value: 'outbound', label: 'Eu contatei' },
  { value: 'inbound', label: 'Cliente respondeu' },
  { value: 'internal_note', label: 'Nota interna' },
];

/** Registro rápido de interação. Default inteligente: direção outbound, agora. */
export function RegisterActivity({ accountId }: { accountId: string }) {
  const router = useRouter();
  const { notify } = useToast();
  const [direction, setDirection] = useState<ActivityDirection>('outbound');
  const [content, setContent] = useState('');
  const [pending, setPending] = useState(false);

  async function submit() {
    if (!content.trim()) return;
    setPending(true);
    const result = await registerActivityAction({ accountId, direction, content });
    setPending(false);
    if (result.ok) {
      notify('success', 'Interação registrada.');
      setContent('');
      router.refresh();
    } else {
      notify('error', result.message);
    }
  }

  return (
    <div className="flex flex-col gap-2 rounded-card border bg-surface p-4">
      <div className="flex gap-2">
        {DIRECTIONS.map((d) => (
          <button
            key={d.value}
            onClick={() => setDirection(d.value)}
            className={
              'rounded-button px-2.5 py-1 text-xs transition-colors duration-fast ' +
              (direction === d.value
                ? 'bg-brand/10 text-brand'
                : 'text-neutral-500 hover:bg-neutral-100')
            }
          >
            {d.label}
          </button>
        ))}
      </div>
      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="O que aconteceu?"
        rows={2}
        className="w-full rounded-button border bg-surface px-3 py-2 text-sm text-ink placeholder:text-neutral-400 focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/30"
      />
      <div className="flex justify-end">
        <Button onClick={submit} disabled={pending || !content.trim()}>
          {pending ? 'Registrando…' : 'Registrar'}
        </Button>
      </div>
    </div>
  );
}

'use client';

import { useRouter } from 'next/navigation';
import type { Task } from '../domain/entities';
import { completeTaskAction } from '../application/actions';
import { useToast } from '@/providers/toast-provider';

/** Lista de follow-ups abertos com conclusão inline (Tech Spec: ação no contexto). */
export function TaskList({ tasks, accountId }: { tasks: Task[]; accountId: string }) {
  const router = useRouter();
  const { notify } = useToast();

  async function complete(id: string) {
    const result = await completeTaskAction(id, accountId);
    if (result.ok) {
      notify('success', 'Tarefa concluída.');
      router.refresh();
    } else {
      notify('error', result.message);
    }
  }

  if (tasks.length === 0) {
    return <p className="text-sm text-neutral-500">Nenhum follow-up pendente.</p>;
  }
  return (
    <ul className="flex flex-col gap-2">
      {tasks.map((t) => (
        <li key={t.id} className="flex items-center gap-3 rounded-button border px-3 py-2">
          <button
            onClick={() => complete(t.id)}
            aria-label="Concluir"
            className="h-4 w-4 shrink-0 rounded-full border border-neutral-300 hover:border-success"
          />
          <div className="flex-1">
            <p className="text-sm text-ink">{t.title}</p>
            <p className="text-xs text-neutral-400">{t.dueAt.toLocaleString('pt-BR')}</p>
          </div>
        </li>
      ))}
    </ul>
  );
}

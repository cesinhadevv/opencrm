'use client';

import type { Activity } from '../domain/entities';

const DIRECTION_LABEL: Record<Activity['direction'], string> = {
  outbound: 'Você',
  inbound: 'Cliente',
  internal_note: 'Nota',
};

const CHANNEL_LABEL: Record<string, string> = {
  whatsapp: 'WhatsApp',
  instagram: 'Instagram',
  linkedin: 'LinkedIn',
  email: 'E-mail',
  phone: 'Ligação',
};

/** Timeline cronológica unificada (Tech Spec §7 / Módulo 2). Estado vazio ensina. */
export function Timeline({ activities }: { activities: Activity[] }) {
  if (activities.length === 0) {
    return (
      <p className="text-sm text-neutral-500">
        Nenhuma interação registrada. Registre a primeira para começar o histórico.
      </p>
    );
  }
  return (
    <ul className="flex flex-col gap-3">
      {activities.map((a) => (
        <li key={a.id} className="border-l-2 border-neutral-200 pl-3">
          <div className="flex items-center gap-2 text-xs text-neutral-400">
            <span>{a.occurredAt.toLocaleString('pt-BR')}</span>
            {a.channel ? <span>· {CHANNEL_LABEL[a.channel] ?? a.channel}</span> : null}
            <span>· {DIRECTION_LABEL[a.direction]}</span>
          </div>
          <p className="text-sm text-ink">{a.content}</p>
        </li>
      ))}
    </ul>
  );
}

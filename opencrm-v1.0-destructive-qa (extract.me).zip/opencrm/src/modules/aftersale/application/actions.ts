'use server';

import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { createRecordSchema, generateMilestonesSchema } from './schemas';
import { getMilestones } from './milestones-config';
import {
  planMilestoneTasks,
  type AfterSaleCustomer,
  type AfterSaleRecord,
} from '../domain/entities';
import { type ActionResult, type FieldErrors, success, failure } from '@/core/domain/result';
import { toFieldErrors, resolveOwner } from '@/core/application/action-helpers';
import {
  authGateway,
  idGenerator,
  clock,
  profileRepository,
  configStore,
} from '@/core/infrastructure/services';
import { SupabaseAfterSaleRepository } from '../infrastructure/aftersale-repository';
import { SupabaseTaskRepository } from '@/modules/activities/infrastructure/task-repository';
import { SupabaseDealRepository } from '@/modules/pipeline/infrastructure/deal-repository';

const afterSaleRepo = new SupabaseAfterSaleRepository();
const taskRepo = new SupabaseTaskRepository();
const dealRepo = new SupabaseDealRepository();

export async function listAfterSaleCustomersAction(): Promise<ActionResult<AfterSaleCustomer[]>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;
  try {
    const profile = await profileRepository.findById(ownerId);
    const timeZone = profile?.timeZone ?? 'America/Sao_Paulo';
    const customers = await afterSaleRepo.listCustomers(ownerId);
    const now = clock.now();
    return success(
      customers.map((c) => ({
        ...c,
        daysSinceWon: clock.daysBetween(c.wonAt, now, timeZone),
      })),
    );
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível carregar os clientes de pós-venda.');
  }
}

/**
 * Gera as Tasks dos marcos de pós-venda para um Deal won (RN-06 / PRD M8).
 * Idempotência simples: marca no ConfigService que os marcos já foram gerados
 * para o deal (namespace 'aftersale', key 'generated:<dealId>').
 */
export async function generateMilestoneTasksAction(
  input: unknown,
): Promise<ActionResult<{ created: number }>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;

  const parsed = generateMilestonesSchema.safeParse(input);
  if (!parsed.success) return failure('validation', 'Dados inválidos.');

  const deal = await dealRepo.findById(ownerId, parsed.data.dealId);
  if (!deal) return failure('not_found', 'Oportunidade não encontrada.');
  if (deal.status !== 'won' || !deal.wonAt) {
    return failure('conflict', 'Os marcos só se aplicam a oportunidades ganhas.');
  }

  const ownerCtx = { ownerId };
  // Idempotência por flag de config. NB: check-then-act não é à prova de corrida
  // sob double-submit simultâneo; para um sistema single-owner o risco é mínimo.
  // A UI também desabilita o botão durante a chamada (defesa adicional).
  const flag = await configStore.get<boolean>(ownerCtx, 'aftersale', `generated:${deal.id}`);
  if (flag === true) return success({ created: 0 });

  try {
    const milestones = await getMilestones(ownerCtx);
    const planned = planMilestoneTasks(deal.wonAt, milestones);
    for (const p of planned) {
      await taskRepo.createTask({
        id: idGenerator.generate(),
        ownerId,
        accountId: deal.accountId,
        dealId: deal.id,
        title: p.title,
        dueAt: p.dueAt,
        priority: 0,
      });
    }
    await configStore.set(ownerCtx, 'aftersale', `generated:${deal.id}`, true);
    revalidatePath(`/pos-venda/${deal.id}`);
    return success({ created: planned.length });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível gerar os marcos de pós-venda.');
  }
}

export async function createAfterSaleRecordAction(
  input: unknown,
): Promise<ActionResult<{ id: string }>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;

  const parsed = createRecordSchema.safeParse(input);
  if (!parsed.success) {
    return failure('validation', 'Verifique os campos.', toFieldErrors(parsed.error));
  }
  try {
    const id = idGenerator.generate();
    await afterSaleRepo.createRecord({
      id,
      ownerId,
      accountId: parsed.data.accountId,
      dealId: parsed.data.dealId,
      type: parsed.data.type,
      content: parsed.data.content,
      satisfactionScore: parsed.data.satisfactionScore ?? null,
    });
    revalidatePath(`/pos-venda/${parsed.data.dealId}`);
    return success({ id });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível registrar o acompanhamento.');
  }
}

export async function listAfterSaleRecordsAction(
  dealId: string,
): Promise<ActionResult<AfterSaleRecord[]>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;
  try {
    return success(await afterSaleRepo.listRecordsByDeal(ownerId, dealId));
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível carregar o histórico.');
  }
}

export async function getAfterSaleCustomerAction(
  dealId: string,
): Promise<ActionResult<AfterSaleCustomer>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  try {
    const profile = await profileRepository.findById(owner.ownerId);
    const timeZone = profile?.timeZone ?? 'America/Sao_Paulo';
    const c = await afterSaleRepo.findCustomerByDeal(owner.ownerId, dealId);
    if (!c) return failure('not_found', 'Cliente de pós-venda não encontrado.');
    return success({ ...c, daysSinceWon: clock.daysBetween(c.wonAt, clock.now(), timeZone) });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível carregar o cliente.');
  }
}

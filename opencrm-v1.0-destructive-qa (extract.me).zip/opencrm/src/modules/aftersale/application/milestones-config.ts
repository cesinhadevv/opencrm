import type { OwnerContext } from '@/core/domain/contracts';
import { configStore } from '@/core/infrastructure/services';
import type { AfterSaleMilestone } from '../domain/entities';

/**
 * Marcos de pós-venda (PRD Módulo 8). Defaults na seed; configuráveis via
 * ConfigService único (namespace 'aftersale', key 'milestones'). Nenhum mecanismo paralelo.
 */
export const DEFAULT_AFTERSALE_MILESTONES: AfterSaleMilestone[] = [
  { offsetDays: 7, title: 'Acompanhar implantação', type: 'follow_up' },
  { offsetDays: 30, title: 'Pesquisa de satisfação', type: 'satisfaction' },
  { offsetDays: 90, title: 'Avaliar upsell e pedir indicação', type: 'upsell' },
];

export async function getMilestones(owner: OwnerContext): Promise<AfterSaleMilestone[]> {
  const stored = await configStore.get<AfterSaleMilestone[]>(owner, 'aftersale', 'milestones');
  return Array.isArray(stored) && stored.length > 0 ? stored : DEFAULT_AFTERSALE_MILESTONES;
}

import { z } from 'zod';

export const createRecordSchema = z.object({
  accountId: z.string().min(1),
  dealId: z.string().min(1),
  type: z.enum(['follow_up', 'satisfaction', 'upsell', 'referral']),
  content: z.string().trim().max(4000).default(''),
  satisfactionScore: z.number().int().min(0).max(10).nullable().optional(),
});

export const generateMilestonesSchema = z.object({
  dealId: z.string().min(1),
});

export type CreateRecordInput = z.infer<typeof createRecordSchema>;

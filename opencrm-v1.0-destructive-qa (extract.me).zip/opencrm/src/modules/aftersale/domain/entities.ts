/**
 * Domínio — Pós-venda (Módulo 8).
 *
 * PRD Módulo 8 / RN-06: Deal 'won' gera tarefa(s) de pós-venda conforme marcos
 * configurados. Marcos temporais (ex.: 7d, 30d, 90d) geram Tasks. Detecção de
 * upsell e gatilho de indicação. Cliente recuperado preserva histórico.
 *
 * Cálculo temporal via Clock (DR-A3). Identidade por ID interno (ADR-012).
 * Marcos vêm do ConfigService (mecanismo único) — defaults na seed.
 */

export type AfterSaleRecordType = 'follow_up' | 'satisfaction' | 'upsell' | 'referral';

export interface AfterSaleRecord {
  id: string;
  ownerId: string;
  accountId: string;
  dealId: string;
  type: AfterSaleRecordType;
  /** Conteúdo livre (nota de acompanhamento, descrição de upsell, etc.). */
  content: string;
  /** Para satisfaction: nota 0-10 (NPS-like). Null nos demais tipos. */
  satisfactionScore: number | null;
  createdAt: Date;
}

/** Marco temporal de pós-venda: gera uma Task em N dias após o fechamento. */
export interface AfterSaleMilestone {
  /** Dias após o won para gerar a tarefa. */
  offsetDays: number;
  /** Título da tarefa gerada. */
  title: string;
  /** Tipo de acompanhamento que o marco representa. */
  type: AfterSaleRecordType;
}

/** Cliente em pós-venda: Deal won com dados de acompanhamento. */
export interface AfterSaleCustomer {
  accountId: string;
  accountName: string;
  dealId: string;
  dealTitle: string;
  wonAt: Date;
  daysSinceWon: number;
}

/**
 * Gera as Tasks de pós-venda a partir dos marcos, com datas calculadas
 * relativamente ao instante do fechamento. Regra pura: recebe wonAt e marcos,
 * devolve as datas-alvo. O cálculo de offset é aritmético determinístico.
 */
export interface PlannedMilestoneTask {
  title: string;
  dueAt: Date;
  type: AfterSaleRecordType;
}

export function planMilestoneTasks(
  wonAt: Date,
  milestones: AfterSaleMilestone[],
): PlannedMilestoneTask[] {
  return milestones.map((m) => ({
    title: m.title,
    type: m.type,
    dueAt: new Date(wonAt.getTime() + m.offsetDays * 86400_000),
  }));
}

import type { AfterSaleCustomer, AfterSaleRecord, AfterSaleRecordType } from './entities';

export interface CreateAfterSaleRecordData {
  id: string;
  ownerId: string;
  accountId: string;
  dealId: string;
  type: AfterSaleRecordType;
  content: string;
  satisfactionScore: number | null;
}

export interface AfterSaleRepository {
  /** Clientes em pós-venda: Deals com status won, não arquivados. */
  listCustomers(ownerId: string): Promise<Omit<AfterSaleCustomer, 'daysSinceWon'>[]>;
  findCustomerByDeal(
    ownerId: string,
    dealId: string,
  ): Promise<Omit<AfterSaleCustomer, 'daysSinceWon'> | null>;
  createRecord(data: CreateAfterSaleRecordData): Promise<void>;
  listRecordsByDeal(ownerId: string, dealId: string): Promise<AfterSaleRecord[]>;
}

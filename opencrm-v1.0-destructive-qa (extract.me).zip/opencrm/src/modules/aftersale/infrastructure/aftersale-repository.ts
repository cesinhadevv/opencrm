import { createSupabaseServerClient } from '@/lib/supabase/server';
import { LIST_HARD_LIMIT, TIMELINE_HARD_LIMIT } from '@/lib/constants';
import { ensure } from '@/lib/supabase/guard';
import type { AfterSaleRepository, CreateAfterSaleRecordData } from '../domain/repository';
import type { AfterSaleCustomer, AfterSaleRecord, AfterSaleRecordType } from '../domain/entities';

export class SupabaseAfterSaleRepository implements AfterSaleRepository {
  async listCustomers(ownerId: string): Promise<Omit<AfterSaleCustomer, 'daysSinceWon'>[]> {
    const supabase = await createSupabaseServerClient();
    const { data } = await supabase
      .from('deals')
      .select('id, title, won_at, account_id, accounts(name)')
      .eq('owner_id', ownerId)
      .eq('status', 'won')
      .is('deleted_at', null)
      .order('won_at', { ascending: false })
      .limit(LIST_HARD_LIMIT);
    return (data ?? [])
      .filter((r) => r.won_at)
      .map((r) => ({
        accountId: r.account_id,
        accountName:
          r.accounts && typeof r.accounts === 'object' && 'name' in r.accounts
            ? (r.accounts as { name: string }).name
            : '',
        dealId: r.id,
        dealTitle: r.title,
        wonAt: new Date(r.won_at as string),
      }));
  }

  async createRecord(data: CreateAfterSaleRecordData): Promise<void> {
    const supabase = await createSupabaseServerClient();
    ensure(
      await supabase.from('aftersale_records').insert({
        id: data.id,
        owner_id: data.ownerId,
        account_id: data.accountId,
        deal_id: data.dealId,
        type: data.type,
        content: data.content,
        satisfaction_score: data.satisfactionScore,
      }),
    );
  }

  async listRecordsByDeal(ownerId: string, dealId: string): Promise<AfterSaleRecord[]> {
    const supabase = await createSupabaseServerClient();
    const { data } = await supabase
      .from('aftersale_records')
      .select('id, owner_id, account_id, deal_id, type, content, satisfaction_score, created_at')
      .eq('owner_id', ownerId)
      .eq('deal_id', dealId)
      .is('deleted_at', null)
      .order('created_at', { ascending: false });
    return (data ?? []).map((r) => ({
      id: r.id,
      ownerId: r.owner_id,
      accountId: r.account_id,
      dealId: r.deal_id,
      type: r.type as AfterSaleRecordType,
      content: r.content,
      satisfactionScore: r.satisfaction_score,
      createdAt: new Date(r.created_at),
    }));
  }
  async findCustomerByDeal(
    ownerId: string,
    dealId: string,
  ): Promise<Omit<AfterSaleCustomer, 'daysSinceWon'> | null> {
    const supabase = await createSupabaseServerClient();
    const { data } = await supabase
      .from('deals')
      .select('id, title, won_at, account_id, accounts(name)')
      .eq('owner_id', ownerId)
      .eq('id', dealId)
      .eq('status', 'won')
      .is('deleted_at', null)
      .maybeSingle();
    if (!data || !data.won_at) return null;
    return {
      accountId: data.account_id,
      accountName:
        data.accounts && typeof data.accounts === 'object' && 'name' in data.accounts
          ? (data.accounts as { name: string }).name
          : '',
      dealId: data.id,
      dealTitle: data.title,
      wonAt: new Date(data.won_at as string),
    };
  }
}

'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import type { AfterSaleRecord, AfterSaleRecordType } from '../domain/entities';
import { createAfterSaleRecordAction, generateMilestoneTasksAction } from '../application/actions';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/providers/toast-provider';

const TYPE_LABEL: Record<AfterSaleRecordType, string> = {
  follow_up: 'Acompanhamento',
  satisfaction: 'Satisfação',
  upsell: 'Upsell',
  referral: 'Indicação',
};

/** Detalhe de pós-venda: gerar marcos, registrar acompanhamento/satisfação/upsell/indicação. */
export function AfterSaleDetail({
  dealId,
  accountId,
  accountName,
  records,
}: {
  dealId: string;
  accountId: string;
  accountName: string;
  records: AfterSaleRecord[];
}) {
  const router = useRouter();
  const { notify } = useToast();
  const [type, setType] = useState<AfterSaleRecordType>('follow_up');
  const [content, setContent] = useState('');
  const [score, setScore] = useState('');
  const [pending, setPending] = useState(false);

  async function generate() {
    const r = await generateMilestoneTasksAction({ dealId });
    if (r.ok) {
      notify(
        'success',
        r.data.created > 0 ? `${r.data.created} marcos agendados.` : 'Marcos já gerados.',
      );
      router.refresh();
    } else notify('error', r.message);
  }

  async function record() {
    setPending(true);
    const r = await createAfterSaleRecordAction({
      accountId,
      dealId,
      type,
      content,
      satisfactionScore: type === 'satisfaction' && score ? Number(score) : null,
    });
    setPending(false);
    if (r.ok) {
      notify('success', 'Registro adicionado.');
      setContent('');
      setScore('');
      router.refresh();
    } else notify('error', r.message);
  }

  return (
    <div className="mx-auto max-w-3xl">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-ink">Pós-venda · {accountName}</h1>
        <Button variant="secondary" onClick={generate}>
          Gerar marcos
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <h2 className="mb-3 text-sm font-semibold text-ink">Novo registro</h2>
          <div className="flex flex-col gap-2">
            <div className="flex flex-wrap gap-2">
              {(Object.keys(TYPE_LABEL) as AfterSaleRecordType[]).map((t) => (
                <button
                  key={t}
                  onClick={() => setType(t)}
                  className={
                    'rounded-button px-2.5 py-1 text-xs transition-colors duration-fast ' +
                    (type === t
                      ? 'bg-brand/10 text-brand'
                      : 'text-neutral-500 hover:bg-neutral-100')
                  }
                >
                  {TYPE_LABEL[t]}
                </button>
              ))}
            </div>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Detalhes do acompanhamento…"
              rows={2}
              className="w-full rounded-button border bg-surface px-3 py-2 text-sm text-ink placeholder:text-neutral-400 focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/30"
            />
            {type === 'satisfaction' ? (
              <Input
                type="number"
                min="0"
                max="10"
                placeholder="Nota (0-10)"
                value={score}
                onChange={(e) => setScore(e.target.value)}
              />
            ) : null}
            <Button onClick={record} disabled={pending}>
              {pending ? 'Salvando…' : 'Registrar'}
            </Button>
          </div>
        </Card>

        <Card>
          <h2 className="mb-3 text-sm font-semibold text-ink">Histórico de pós-venda</h2>
          {records.length === 0 ? (
            <p className="text-sm text-neutral-500">Nenhum registro ainda.</p>
          ) : (
            <ul className="flex flex-col gap-3">
              {records.map((r) => (
                <li key={r.id} className="border-l-2 border-neutral-200 pl-3">
                  <div className="flex items-center gap-2 text-xs text-neutral-400">
                    <span>{r.createdAt.toLocaleString('pt-BR')}</span>
                    <span>· {TYPE_LABEL[r.type]}</span>
                    {r.satisfactionScore !== null ? (
                      <span>· nota {r.satisfactionScore}</span>
                    ) : null}
                  </div>
                  {r.content ? <p className="text-sm text-ink">{r.content}</p> : null}
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}

'use client';

import Link from 'next/link';
import type { AfterSaleCustomer } from '../domain/entities';
import { Card } from '@/components/ui/card';

/** Lista de clientes em pós-venda (Deals won). Estado vazio ensina. */
export function CustomerList({ customers }: { customers: AfterSaleCustomer[] }) {
  if (customers.length === 0) {
    return (
      <Card className="text-center">
        <p className="text-base font-medium text-ink">Nenhum cliente em pós-venda</p>
        <p className="mt-2 text-sm text-neutral-500">
          Quando você ganhar uma oportunidade, o cliente aparece aqui para acompanhamento.
        </p>
      </Card>
    );
  }
  return (
    <ul className="flex flex-col gap-2">
      {customers.map((c) => (
        <li key={c.dealId}>
          <Link
            href={`/pos-venda/${c.dealId}`}
            className="flex items-center justify-between rounded-card border bg-surface p-4 transition-shadow duration-fast hover:shadow-card"
          >
            <div>
              <p className="font-medium text-ink">{c.accountName}</p>
              <p className="text-sm text-neutral-500">{c.dealTitle}</p>
            </div>
            <span className="text-xs text-neutral-400">Fechou há {c.daysSinceWon}d</span>
          </Link>
        </li>
      ))}
    </ul>
  );
}

'use server';

import { type ActionResult, success, failure } from '@/core/domain/result';
import { authGateway, clock, profileRepository } from '@/core/infrastructure/services';
import { SupabaseTaskRepository } from '@/modules/activities/infrastructure/task-repository';
import { SupabaseDealRepository } from '@/modules/pipeline/infrastructure/deal-repository';
import { classifyTaskBand } from '@/modules/activities/domain/conversation-state';
import type { Task, TaskBand } from '@/modules/activities/domain/entities';
import { type CockpitTaskItem, type CockpitData } from './cockpit-types';
import { scoreService } from '@/modules/score/application/score-factory';
import { buildScoreTimes } from '@/modules/score/domain/score-service';
import { isProposalDueSoon } from '@/modules/proposals/domain/entities';
import { DEFAULT_PROPOSAL_WINDOW_DAYS } from '@/modules/score/domain/score-config';

/**
 * Cockpit (Módulo 4). Agrega Tasks em faixas temporais (DR-A3) e ordena por Score
 * (DR-A5). Resumo: tarefas hoje, atrasadas, total em pipeline, deal mais "quente".
 * Cálculo temporal via Clock; Score via ScoreService (ADR-011), sem conhecer a fórmula.
 */
const taskRepo = new SupabaseTaskRepository();
const dealRepo = new SupabaseDealRepository();

export async function getCockpitAction(): Promise<ActionResult<CockpitData>> {
  const session = await authGateway.getSession();
  if (!session) return failure('unauthenticated', 'Sua sessão expirou.');

  try {
    const profile = await profileRepository.findById(session.userId);
    const timeZone = profile?.timeZone ?? 'America/Sao_Paulo';

    const [openTasks, dealCards, scoringData] = await Promise.all([
      taskRepo.listOpen(session.userId),
      dealRepo.listOpenCards(session.userId),
      dealRepo.listOpenScoringData(session.userId),
    ]);

    const bands: Record<TaskBand, CockpitTaskItem[]> = {
      overdue: [],
      today: [],
      this_week: [],
      upcoming: [],
    };
    for (const t of openTasks) {
      const band = classifyTaskBand(clock, timeZone, t);
      bands[band].push(taskToItem(t, band));
    }

    const pipelineTotalCents = dealCards.reduce((s, d) => s + d.value, 0);

    // Top deal por Score (DR-A5) com entradas REAIS (A1 corrigido): última
    // interação e previsão de fechamento por deal, dias resolvidos via Clock.
    let topDeal: { title: string; score: number } | null = null;
    for (const d of scoringData) {
      const times = buildScoreTimes(clock, timeZone, d.lastInteractionAt, d.expectedCloseAt);
      // ADR-011-A: componente "proposta a vencer" alimentado pela regra real
      // (isProposalDueSoon), sem duplicar lógica.
      const proposalDueSoon = isProposalDueSoon(
        clock,
        timeZone,
        DEFAULT_PROPOSAL_WINDOW_DAYS,
        d.activeProposalValidUntil
          ? { status: 'sent', validUntil: d.activeProposalValidUntil }
          : null,
      );
      const breakdown = scoreService.calculate({
        probability: d.probability,
        value: d.value,
        daysSinceLastInteraction: times.daysSinceLastInteraction,
        daysToExpectedClose: times.daysToExpectedClose,
        proposalDueSoon,
      });
      if (!topDeal || breakdown.total > topDeal.score) {
        topDeal = { title: d.title, score: breakdown.total };
      }
    }

    return success({
      summary: {
        tasksToday: bands.today.length,
        overdueCount: bands.overdue.length,
        pipelineTotalCents,
        topDeal,
      },
      bands,
    });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível carregar o cockpit.');
  }
}

function taskToItem(t: Task, band: TaskBand): CockpitTaskItem {
  return {
    id: t.id,
    title: t.title,
    dueAt: t.dueAt.toISOString(),
    accountId: t.accountId,
    band,
  };
}

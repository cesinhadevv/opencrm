/** Tipos e constantes do Cockpit (sem 'use server' — podem ser objetos/interfaces). */
import type { TaskBand } from '@/modules/activities/domain/entities';

export interface CockpitTaskItem {
  id: string;
  title: string;
  dueAt: string;
  accountId: string;
  band: TaskBand;
}

export interface CockpitSummary {
  tasksToday: number;
  overdueCount: number;
  pipelineTotalCents: number;
  topDeal: { title: string; score: number } | null;
}

export interface CockpitData {
  summary: CockpitSummary;
  bands: Record<TaskBand, CockpitTaskItem[]>;
}

export const BAND_ORDER: TaskBand[] = ['overdue', 'today', 'this_week', 'upcoming'];

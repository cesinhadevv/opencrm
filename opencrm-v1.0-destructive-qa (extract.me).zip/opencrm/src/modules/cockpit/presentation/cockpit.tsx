'use client';

import { useRouter } from 'next/navigation';
import type { CockpitData } from '../application/cockpit-types';
import type { TaskBand } from '@/modules/activities/domain/entities';
import { completeTaskAction } from '@/modules/activities/application/actions';
import { Card } from '@/components/ui/card';
import { useToast } from '@/providers/toast-provider';
import { formatBRL } from '@/lib/utils/currency';

const BAND_LABEL: Record<TaskBand, string> = {
  overdue: '🔥 Atrasadas',
  today: 'Hoje',
  this_week: 'Esta Semana',
  upcoming: 'Próximas',
};
const BAND_ORDER: TaskBand[] = ['overdue', 'today', 'this_week', 'upcoming'];

/** Cockpit "Hoje" (Tech Spec §6). Faixas temporais + resumo. Conclusão inline. */
export function Cockpit({ data }: { data: CockpitData }) {
  const router = useRouter();
  const { notify } = useToast();

  async function complete(id: string, accountId: string) {
    const result = await completeTaskAction(id, accountId);
    if (result.ok) {
      notify('success', 'Tarefa concluída.');
      router.refresh();
    } else {
      notify('error', result.message);
    }
  }

  const { summary, bands } = data;

  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="mb-1 text-2xl font-semibold text-ink">Hoje</h1>
      <p className="mb-6 text-sm text-neutral-500">Seu dia, organizado.</p>

      {/* Faixa de resumo */}
      <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        <SummaryCard label="Tarefas hoje" value={String(summary.tasksToday)} />
        <SummaryCard label="Atrasadas" value={String(summary.overdueCount)} accent />
        <SummaryCard label="Em pipeline" value={formatBRL(summary.pipelineTotalCents)} />
        <SummaryCard
          label="Mais perto"
          value={summary.topDeal ? `${summary.topDeal.score}` : '—'}
          hint={summary.topDeal?.title}
        />
      </div>

      {/* Faixas temporais */}
      <div className="flex flex-col gap-5">
        {BAND_ORDER.map((band) => {
          const items = bands[band];
          if (items.length === 0) return null;
          return (
            <section key={band}>
              <h2 className="mb-2 text-sm font-semibold text-ink">{BAND_LABEL[band]}</h2>
              <ul className="flex flex-col gap-2">
                {items.map((t) => (
                  <li
                    key={t.id}
                    className="flex items-center gap-3 rounded-card border bg-surface px-4 py-3"
                  >
                    <button
                      onClick={() => complete(t.id, t.accountId)}
                      aria-label="Concluir"
                      className="h-4 w-4 shrink-0 rounded-full border border-neutral-300 hover:border-success"
                    />
                    <div className="flex-1">
                      <p className="text-sm text-ink">{t.title}</p>
                      <p className="text-xs text-neutral-400">
                        {new Date(t.dueAt).toLocaleString('pt-BR')}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            </section>
          );
        })}

        {BAND_ORDER.every((b) => bands[b].length === 0) ? (
          <Card className="text-center">
            <p className="text-base font-medium text-ink">Tudo em dia</p>
            <p className="mt-2 text-sm text-neutral-500">
              Nenhuma tarefa pendente. Que tal registrar uma nova oportunidade?
            </p>
          </Card>
        ) : null}
      </div>
    </div>
  );
}

function SummaryCard({
  label,
  value,
  hint,
  accent,
}: {
  label: string;
  value: string;
  hint?: string;
  accent?: boolean;
}) {
  return (
    <div className="rounded-card border bg-surface p-4">
      <p className="text-xs text-neutral-500">{label}</p>
      <p className={'mt-1 text-xl font-semibold ' + (accent ? 'text-attention' : 'text-ink')}>
        {value}
      </p>
      {hint ? <p className="mt-0.5 truncate text-xs text-neutral-400">{hint}</p> : null}
    </div>
  );
}

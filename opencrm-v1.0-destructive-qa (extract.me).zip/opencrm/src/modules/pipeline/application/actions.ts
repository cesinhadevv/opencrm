'use server';

import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import {
  createDealSchema,
  moveStageSchema,
  setProbabilitySchema,
  closeDealSchema,
} from './schemas';
import { resolveProbabilityOnStageMove } from '../domain/probability';
import { type ActionResult, type FieldErrors, success, failure } from '@/core/domain/result';
import { toFieldErrors, resolveOwner } from '@/core/application/action-helpers';
import { authGateway, idGenerator, clock } from '@/core/infrastructure/services';
import { SupabaseDealRepository } from '../infrastructure/deal-repository';
import { SupabasePipelineStageRepository } from '../infrastructure/stage-repository';
import { SupabaseTaskRepository } from '@/modules/activities/infrastructure/task-repository';
import { SupabaseAccountRepository } from '@/modules/accounts/infrastructure/account-repository';
import type { Deal, DealCardItem, PipelineStage } from '../domain/entities';

const dealRepo = new SupabaseDealRepository();
const stageRepo = new SupabasePipelineStageRepository();
const taskRepo = new SupabaseTaskRepository();
const accountRepo = new SupabaseAccountRepository();

export async function createDealAction(input: unknown): Promise<ActionResult<{ id: string }>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;

  const parsed = createDealSchema.safeParse(input);
  if (!parsed.success) {
    return failure('validation', 'Verifique os campos.', toFieldErrors(parsed.error));
  }
  // Probabilidade inicial = default do stage (DR-E4).
  const stage = await stageRepo.findById(ownerId, parsed.data.stageId);
  if (!stage) return failure('not_found', 'Estágio inválido.');

  // A4: confirmar posse da account referenciada antes de escrever.
  const account = await accountRepo.findById(ownerId, parsed.data.accountId);
  if (!account) return failure('not_found', 'Empresa não encontrada.');

  try {
    const id = idGenerator.generate();
    await dealRepo.create({
      id,
      ownerId,
      accountId: parsed.data.accountId,
      primaryContactId: parsed.data.primaryContactId ?? null,
      title: parsed.data.title,
      value: parsed.data.value,
      stageId: stage.id,
      probability: stage.defaultProbability,
      expectedCloseAt: parsed.data.expectedCloseAt ? new Date(parsed.data.expectedCloseAt) : null,
    });
    revalidatePath('/pipeline');
    revalidatePath(`/empresas/${parsed.data.accountId}`);
    return success({ id });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível criar a oportunidade.');
  }
}

export async function moveDealStageAction(input: unknown): Promise<ActionResult<{ id: string }>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;

  const parsed = moveStageSchema.safeParse(input);
  if (!parsed.success) return failure('validation', 'Dados inválidos.');

  const [deal, stage] = await Promise.all([
    dealRepo.findById(ownerId, parsed.data.dealId),
    stageRepo.findById(ownerId, parsed.data.stageId),
  ]);
  if (!deal || !stage) return failure('not_found', 'Oportunidade ou estágio não encontrado.');

  // DR-E4: probabilidade só muda se não houver override (sem pop-up).
  const probability = resolveProbabilityOnStageMove(deal, stage);
  try {
    await dealRepo.moveStage(ownerId, deal.id, stage.id, probability);
    revalidatePath('/pipeline');
    return success({ id: deal.id });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível mover a oportunidade.');
  }
}

export async function setDealProbabilityAction(
  input: unknown,
): Promise<ActionResult<{ id: string }>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;

  const parsed = setProbabilitySchema.safeParse(input);
  if (!parsed.success) return failure('validation', 'Probabilidade inválida.');
  try {
    await dealRepo.setProbability(ownerId, parsed.data.dealId, parsed.data.probability);
    revalidatePath('/pipeline');
    return success({ id: parsed.data.dealId });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível atualizar a probabilidade.');
  }
}

export async function closeDealAction(input: unknown): Promise<ActionResult<{ id: string }>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;

  const parsed = closeDealSchema.safeParse(input);
  if (!parsed.success) {
    return failure('validation', 'Verifique os campos.', toFieldErrors(parsed.error));
  }

  const deal = await dealRepo.findById(ownerId, parsed.data.dealId);
  if (!deal) return failure('not_found', 'Oportunidade não encontrada.');
  if (deal.status !== 'open') {
    return failure('conflict', 'Esta oportunidade já foi fechada.');
  }

  try {
    const at = clock.now();
    if (parsed.data.status === 'won') {
      // C2: fechar Won + criar task de pós-venda atomicamente (RN-06).
      await dealRepo.closeWonWithTask(ownerId, {
        dealId: deal.id,
        accountId: deal.accountId,
        taskId: idGenerator.generate(),
        wonAt: at,
        taskTitle: 'Acompanhar pós-venda',
        taskDueAt: new Date(at.getTime() + 7 * 86400_000),
      });
    } else {
      await dealRepo.close(ownerId, deal.id, 'lost', at, parsed.data.lostReason);
    }
    revalidatePath('/pipeline');
    revalidatePath(`/empresas/${deal.accountId}`);
    return success({ id: deal.id });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível concluir a oportunidade.');
  }
}

export async function getPipelineAction(): Promise<
  ActionResult<{ stages: PipelineStage[]; deals: DealCardItem[] }>
> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;
  try {
    const [stages, deals] = await Promise.all([
      stageRepo.listActive(ownerId),
      dealRepo.listOpenCards(ownerId),
    ]);
    return success({ stages, deals });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível carregar o pipeline.');
  }
}

export async function getAccountDealsAction(accountId: string): Promise<ActionResult<Deal[]>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;
  try {
    return success(await dealRepo.listByAccount(ownerId, accountId));
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível carregar as oportunidades.');
  }
}

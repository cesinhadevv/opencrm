import { z } from 'zod';

export const createDealSchema = z.object({
  accountId: z.string().min(1),
  primaryContactId: z.string().min(1).nullable().optional(),
  title: z.string().trim().min(1, 'Informe o título da oportunidade.').max(200),
  value: z.number().int().min(0).max(100_000_000_000), // centavos (teto R$1bi, < 2^53)
  stageId: z.string().min(1, 'Selecione um estágio.'),
  expectedCloseAt: z.string().datetime().nullable().optional(),
});

export const moveStageSchema = z.object({
  dealId: z.string().min(1),
  stageId: z.string().min(1),
});

export const setProbabilitySchema = z.object({
  dealId: z.string().min(1),
  probability: z.number().int().min(0).max(100),
});

// RN-07: motivo obrigatório no Lost.
export const closeDealSchema = z.discriminatedUnion('status', [
  z.object({ status: z.literal('won'), dealId: z.string().min(1) }),
  z.object({
    status: z.literal('lost'),
    dealId: z.string().min(1),
    lostReason: z.string().trim().min(1, 'Informe o motivo da perda.').max(500),
  }),
]);

export type CreateDealInput = z.infer<typeof createDealSchema>;

/**
 * Domínio — Pipeline (Módulo 3).
 *
 * DR-B2: status (Open/Won/Lost) é independente de stage (posição no funil,
 * relevante só enquanto Open). "Em pipeline" = Deals com status Open.
 * Won/Lost carregam timestamp; Lost exige motivo (RN-07).
 *
 * DR-E4: probabilidade = default do stage, com override manual opcional.
 * Mover de stage atualiza a probabilidade só se não houver override (sem pop-up).
 *
 * DR-B6: PipelineStage é entidade com ID estável, arquivável. Deal referencia o ID.
 * ADR-012: identidade por ID interno.
 */

export type DealStatus = 'open' | 'won' | 'lost';

export interface PipelineStage {
  id: string;
  ownerId: string;
  name: string;
  position: number;
  defaultProbability: number; // 0-100
  active: boolean;
}

export interface Deal {
  id: string;
  ownerId: string;
  accountId: string;
  primaryContactId: string | null;
  title: string;
  value: number; // em centavos (inteiro) — evita float
  status: DealStatus;
  stageId: string | null; // relevante enquanto open
  probability: number; // 0-100 (efetiva)
  probabilityOverridden: boolean; // DR-E4: true se ajustada manualmente
  expectedCloseAt: Date | null;
  lostReason: string | null; // obrigatório quando lost (RN-07)
  wonAt: Date | null;
  lostAt: Date | null;
}

export interface DealCardItem {
  id: string;
  title: string;
  value: number;
  probability: number;
  accountName: string;
  stageId: string | null;
}

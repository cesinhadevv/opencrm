import type { Deal, PipelineStage } from './entities';

/**
 * Regra pura de probabilidade ao mover de stage (DR-E4). Determinística.
 *
 * - Se o Deal NUNCA teve override manual: adota a probabilidade default do novo stage.
 * - Se TEVE override: mantém o valor manual (prevalece). Sem pop-up (a UI não confirma).
 */
export function resolveProbabilityOnStageMove(
  deal: Pick<Deal, 'probability' | 'probabilityOverridden'>,
  targetStage: Pick<PipelineStage, 'defaultProbability'>,
): number {
  return deal.probabilityOverridden ? deal.probability : targetStage.defaultProbability;
}

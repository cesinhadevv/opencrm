import type { Deal, DealCardItem, PipelineStage, DealStatus } from './entities';

export interface CreateDealData {
  id: string;
  ownerId: string;
  accountId: string;
  primaryContactId: string | null;
  title: string;
  value: number;
  stageId: string;
  probability: number;
  expectedCloseAt: Date | null;
}

export interface PipelineStageRepository {
  listActive(ownerId: string): Promise<PipelineStage[]>;
  findById(ownerId: string, id: string): Promise<PipelineStage | null>;
}

export interface DealRepository {
  create(data: CreateDealData): Promise<void>;
  findById(ownerId: string, id: string): Promise<Deal | null>;
  listOpenCards(ownerId: string): Promise<DealCardItem[]>;
  listOpenScoringData(ownerId: string): Promise<
    Array<{
      id: string;
      title: string;
      value: number;
      probability: number;
      expectedCloseAt: Date | null;
      lastInteractionAt: Date | null;
      activeProposalValidUntil: Date | null;
    }>
  >;
  listByAccount(ownerId: string, accountId: string): Promise<Deal[]>;
  moveStage(ownerId: string, id: string, stageId: string, probability: number): Promise<void>;
  setProbability(ownerId: string, id: string, probability: number): Promise<void>;
  close(
    ownerId: string,
    id: string,
    status: Extract<DealStatus, 'won' | 'lost'>,
    at: Date,
    lostReason: string | null,
  ): Promise<void>;
  reopen(ownerId: string, id: string): Promise<void>;
  closeWonWithTask(
    ownerId: string,
    input: {
      dealId: string;
      accountId: string;
      taskId: string;
      wonAt: Date;
      taskTitle: string;
      taskDueAt: Date;
    },
  ): Promise<void>;
}

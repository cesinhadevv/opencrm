import { createSupabaseServerClient } from '@/lib/supabase/server';
import { LIST_HARD_LIMIT, TIMELINE_HARD_LIMIT } from '@/lib/constants';
import { ensure } from '@/lib/supabase/guard';
import type { DealRepository, CreateDealData } from '../domain/repository';
import type { Deal, DealCardItem, DealStatus } from '../domain/entities';

interface DealRow {
  id: string;
  owner_id: string;
  account_id: string;
  primary_contact_id: string | null;
  title: string;
  value: number;
  status: DealStatus;
  stage_id: string | null;
  probability: number;
  probability_overridden: boolean;
  expected_close_at: string | null;
  lost_reason: string | null;
  won_at: string | null;
  lost_at: string | null;
}

function mapDeal(r: DealRow): Deal {
  return {
    id: r.id,
    ownerId: r.owner_id,
    accountId: r.account_id,
    primaryContactId: r.primary_contact_id,
    title: r.title,
    value: Number(r.value),
    status: r.status,
    stageId: r.stage_id,
    probability: r.probability,
    probabilityOverridden: r.probability_overridden,
    expectedCloseAt: r.expected_close_at ? new Date(r.expected_close_at) : null,
    lostReason: r.lost_reason,
    wonAt: r.won_at ? new Date(r.won_at) : null,
    lostAt: r.lost_at ? new Date(r.lost_at) : null,
  };
}

const COLS =
  'id, owner_id, account_id, primary_contact_id, title, value, status, stage_id, probability, probability_overridden, expected_close_at, lost_reason, won_at, lost_at';

export class SupabaseDealRepository implements DealRepository {
  async create(data: CreateDealData): Promise<void> {
    const supabase = await createSupabaseServerClient();
    ensure(
      await supabase.from('deals').insert({
        id: data.id,
        owner_id: data.ownerId,
        account_id: data.accountId,
        primary_contact_id: data.primaryContactId,
        title: data.title,
        value: data.value,
        stage_id: data.stageId,
        probability: data.probability,
        expected_close_at: data.expectedCloseAt?.toISOString() ?? null,
      }),
    );
  }

  async findById(ownerId: string, id: string): Promise<Deal | null> {
    const supabase = await createSupabaseServerClient();
    const { data } = await supabase
      .from('deals')
      .select(COLS)
      .eq('owner_id', ownerId)
      .eq('id', id)
      .is('deleted_at', null)
      .maybeSingle();
    return data ? mapDeal(data as DealRow) : null;
  }

  async listOpenCards(ownerId: string): Promise<DealCardItem[]> {
    const supabase = await createSupabaseServerClient();
    const { data } = await supabase
      .from('deals')
      .select('id, title, value, probability, stage_id, accounts(name)')
      .eq('owner_id', ownerId)
      .eq('status', 'open')
      .is('deleted_at', null);
    return (data ?? []).map((r) => ({
      id: r.id,
      title: r.title,
      value: Number(r.value),
      probability: r.probability,
      stageId: r.stage_id,
      accountName:
        r.accounts && typeof r.accounts === 'object' && 'name' in r.accounts
          ? (r.accounts as { name: string }).name
          : '',
    }));
  }

  async listByAccount(ownerId: string, accountId: string): Promise<Deal[]> {
    const supabase = await createSupabaseServerClient();
    const { data } = await supabase
      .from('deals')
      .select(COLS)
      .eq('owner_id', ownerId)
      .eq('account_id', accountId)
      .is('deleted_at', null)
      .order('created_at', { ascending: false })
      .limit(LIST_HARD_LIMIT);
    return (data ?? []).map((r) => mapDeal(r as DealRow));
  }

  async moveStage(
    ownerId: string,
    id: string,
    stageId: string,
    probability: number,
  ): Promise<void> {
    const supabase = await createSupabaseServerClient();
    ensure(
      await supabase
        .from('deals')
        .update({ stage_id: stageId, probability })
        .eq('owner_id', ownerId)
        .eq('id', id)
        .eq('status', 'open')
        .is('deleted_at', null),
    );
  }

  async setProbability(ownerId: string, id: string, probability: number): Promise<void> {
    const supabase = await createSupabaseServerClient();
    ensure(
      await supabase
        .from('deals')
        .update({ probability, probability_overridden: true })
        .eq('owner_id', ownerId)
        .eq('id', id)
        .is('deleted_at', null),
    );
  }

  async close(
    ownerId: string,
    id: string,
    status: Extract<DealStatus, 'won' | 'lost'>,
    at: Date,
    lostReason: string | null,
  ): Promise<void> {
    const supabase = await createSupabaseServerClient();
    const patch: Record<string, unknown> =
      status === 'won'
        ? { status: 'won', won_at: at.toISOString(), lost_at: null, lost_reason: null }
        : { status: 'lost', lost_at: at.toISOString(), lost_reason: lostReason, won_at: null };
    ensure(
      await supabase
        .from('deals')
        .update(patch)
        .eq('owner_id', ownerId)
        .eq('id', id)
        .is('deleted_at', null),
    );
  }

  // Capacidade de reabertura (Módulo 3: 'reopen preserva histórico'). Ainda sem
  // action/UI que a exponha — mantida no contrato para uso futuro, não é dead code.
  async reopen(ownerId: string, id: string): Promise<void> {
    const supabase = await createSupabaseServerClient();
    ensure(
      await supabase
        .from('deals')
        .update({ status: 'open', won_at: null, lost_at: null, lost_reason: null })
        .eq('owner_id', ownerId)
        .eq('id', id)
        .is('deleted_at', null),
    );
  }
  async closeWonWithTask(
    ownerId: string,
    input: {
      dealId: string;
      accountId: string;
      taskId: string;
      wonAt: Date;
      taskTitle: string;
      taskDueAt: Date;
    },
  ): Promise<void> {
    const supabase = await createSupabaseServerClient();
    ensure(
      await supabase.rpc('close_deal_won_with_task', {
        p_deal_id: input.dealId,
        p_account_id: input.accountId,
        p_task_id: input.taskId,
        p_won_at: input.wonAt.toISOString(),
        p_task_title: input.taskTitle,
        p_task_due_at: input.taskDueAt.toISOString(),
      }),
    );
  }
  async listOpenScoringData(ownerId: string): Promise<
    Array<{
      id: string;
      title: string;
      value: number;
      probability: number;
      expectedCloseAt: Date | null;
      lastInteractionAt: Date | null;
      activeProposalValidUntil: Date | null;
    }>
  > {
    const supabase = await createSupabaseServerClient();
    const { data } = await supabase
      .from('deals')
      .select(
        'id, title, value, probability, expected_close_at, activities(occurred_at), proposals(status, valid_until)',
      )
      .eq('owner_id', ownerId)
      .eq('status', 'open')
      .is('deleted_at', null);
    return (data ?? []).map((r) => {
      const acts = Array.isArray(r.activities) ? r.activities : [];
      const last = acts.reduce<number | null>((acc, a) => {
        const t = new Date((a as { occurred_at: string }).occurred_at).getTime();
        return acc === null || t > acc ? t : acc;
      }, null);
      // Proposta 'sent' com a validade mais próxima (a que mais "pressiona" o Score).
      const proposals = Array.isArray(r.proposals) ? r.proposals : [];
      const sentValidUntils = proposals
        .filter(
          (p): p is { status: string; valid_until: string } =>
            (p as { status: string }).status === 'sent' &&
            (p as { valid_until: string | null }).valid_until !== null,
        )
        .map((p) => new Date(p.valid_until).getTime());
      const nearest = sentValidUntils.length > 0 ? Math.min(...sentValidUntils) : null;
      return {
        id: r.id,
        title: r.title,
        value: Number(r.value),
        probability: r.probability,
        expectedCloseAt: r.expected_close_at ? new Date(r.expected_close_at) : null,
        lastInteractionAt: last === null ? null : new Date(last),
        activeProposalValidUntil: nearest === null ? null : new Date(nearest),
      };
    });
  }
}

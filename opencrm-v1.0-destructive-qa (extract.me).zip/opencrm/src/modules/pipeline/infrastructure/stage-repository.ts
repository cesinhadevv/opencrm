import { createSupabaseServerClient } from '@/lib/supabase/server';
import { ensure } from '@/lib/supabase/guard';
import type { PipelineStageRepository } from '../domain/repository';
import type { PipelineStage } from '../domain/entities';

function mapStage(r: {
  id: string;
  owner_id: string;
  name: string;
  position: number;
  default_probability: number;
  active: boolean;
}): PipelineStage {
  return {
    id: r.id,
    ownerId: r.owner_id,
    name: r.name,
    position: r.position,
    defaultProbability: r.default_probability,
    active: r.active,
  };
}

const COLS = 'id, owner_id, name, position, default_probability, active';

export class SupabasePipelineStageRepository implements PipelineStageRepository {
  async listActive(ownerId: string): Promise<PipelineStage[]> {
    const supabase = await createSupabaseServerClient();
    const { data } = await supabase
      .from('pipeline_stages')
      .select(COLS)
      .eq('owner_id', ownerId)
      .eq('active', true)
      .is('deleted_at', null)
      .order('position', { ascending: true });
    return (data ?? []).map(mapStage);
  }

  async findById(ownerId: string, id: string): Promise<PipelineStage | null> {
    const supabase = await createSupabaseServerClient();
    const { data } = await supabase
      .from('pipeline_stages')
      .select(COLS)
      .eq('owner_id', ownerId)
      .eq('id', id)
      .is('deleted_at', null)
      .maybeSingle();
    return data ? mapStage(data) : null;
  }
}

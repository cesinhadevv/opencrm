'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import type { Deal } from '../domain/entities';
import { closeDealAction } from '../application/actions';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/providers/toast-provider';

/** Ações de fechamento de um Deal: Won (1 clique) / Lost (motivo obrigatório — RN-07). */
export function DealCloseActions({ deal }: { deal: Deal }) {
  const router = useRouter();
  const { notify } = useToast();
  const [lostOpen, setLostOpen] = useState(false);
  const [reason, setReason] = useState('');
  const [pending, setPending] = useState(false);

  if (deal.status !== 'open') {
    return (
      <p className="text-sm text-neutral-500">
        {deal.status === 'won' ? 'Ganho 🎉' : `Perdido — ${deal.lostReason ?? ''}`}
      </p>
    );
  }

  async function win() {
    setPending(true);
    const r = await closeDealAction({ status: 'won', dealId: deal.id });
    setPending(false);
    if (r.ok) {
      notify('success', 'Mais uma! 🎉');
      router.refresh();
    } else notify('error', r.message);
  }

  async function lose() {
    if (!reason.trim()) return;
    setPending(true);
    const r = await closeDealAction({ status: 'lost', dealId: deal.id, lostReason: reason });
    setPending(false);
    if (r.ok) {
      router.refresh();
    } else notify('error', r.message);
  }

  return (
    <div className="flex flex-col gap-2">
      <div className="flex gap-2">
        <Button onClick={win} disabled={pending}>
          Ganhou
        </Button>
        <Button variant="secondary" onClick={() => setLostOpen((v) => !v)} disabled={pending}>
          Perdeu
        </Button>
      </div>
      {lostOpen ? (
        <div className="flex flex-col gap-2">
          <Input
            placeholder="Motivo da perda (obrigatório)"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
          />
          <Button onClick={lose} disabled={pending || !reason.trim()}>
            Confirmar perda
          </Button>
        </div>
      ) : null}
    </div>
  );
}

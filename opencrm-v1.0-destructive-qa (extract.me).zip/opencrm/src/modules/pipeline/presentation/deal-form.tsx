'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import type { PipelineStage } from '../domain/entities';
import { createDealAction } from '../application/actions';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Field } from '@/components/ui/field';
import { useToast } from '@/providers/toast-provider';
import type { FieldErrors } from '@/core/domain/result';

/** Criação de oportunidade vinculada a uma empresa. Probabilidade vem do stage (DR-E4). */
export function DealForm({
  accountId,
  stages,
  onCreated,
}: {
  accountId: string;
  stages: PipelineStage[];
  onCreated?: () => void;
}) {
  const router = useRouter();
  const { notify } = useToast();
  const [errors, setErrors] = useState<FieldErrors>({});
  const [pending, setPending] = useState(false);
  const [stageId, setStageId] = useState(stages[0]?.id ?? '');

  async function onSubmit(formData: FormData) {
    setPending(true);
    setErrors({});
    const valueReais = Number(formData.get('value') ?? 0);
    const result = await createDealAction({
      accountId,
      title: formData.get('title'),
      value: Math.round(valueReais * 100),
      stageId,
      expectedCloseAt: formData.get('expectedCloseAt')
        ? new Date(String(formData.get('expectedCloseAt'))).toISOString()
        : null,
    });
    setPending(false);
    if (result.ok) {
      notify('success', 'Oportunidade criada.');
      if (onCreated) onCreated();
      else router.refresh();
    } else if (result.fieldErrors) {
      setErrors(result.fieldErrors);
    } else {
      notify('error', result.message);
    }
  }

  return (
    <form action={onSubmit} className="flex flex-col gap-3">
      <Field label="Título" htmlFor="title" error={errors.title}>
        <Input id="title" name="title" autoFocus />
      </Field>
      <Field label="Valor (R$)" htmlFor="value">
        <Input id="value" name="value" type="number" min="0" step="0.01" />
      </Field>
      <Field label="Estágio" htmlFor="stage" error={errors.stageId}>
        <select
          id="stage"
          value={stageId}
          onChange={(e) => setStageId(e.target.value)}
          className="h-10 w-full rounded-button border bg-surface px-3 text-sm text-ink focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/30"
        >
          {stages.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name} ({s.defaultProbability}%)
            </option>
          ))}
        </select>
      </Field>
      <Field label="Previsão de fechamento" htmlFor="expectedCloseAt">
        <input
          id="expectedCloseAt"
          name="expectedCloseAt"
          type="date"
          aria-label="Previsão de fechamento"
          className="h-10 w-full rounded-button border bg-surface px-3 text-sm text-ink focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/30"
        />
      </Field>
      <Button type="submit" disabled={pending || !stageId}>
        {pending ? 'Criando…' : 'Criar oportunidade'}
      </Button>
    </form>
  );
}

/** Formata centavos -> BRL para exibição (apenas UI; valor canônico é inteiro). */
export { formatBRL } from '@/lib/utils/currency';

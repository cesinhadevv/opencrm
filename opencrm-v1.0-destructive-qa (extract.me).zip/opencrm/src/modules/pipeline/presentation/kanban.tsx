'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import type { DealCardItem, PipelineStage } from '../domain/entities';
import { moveDealStageAction } from '../application/actions';
import { formatBRL } from './format';
import { useToast } from '@/providers/toast-provider';

/**
 * Kanban do Pipeline (Tech Spec). Drag-and-drop entre estágios (DR-B2: move stage,
 * status permanece open). Totais por coluna. Probabilidade no card (DR-E4).
 */
export function Kanban({ stages, deals }: { stages: PipelineStage[]; deals: DealCardItem[] }) {
  const router = useRouter();
  const { notify } = useToast();
  const [dragging, setDragging] = useState<string | null>(null);

  async function onDrop(stageId: string) {
    if (!dragging) return;
    const dealId = dragging;
    setDragging(null);
    const result = await moveDealStageAction({ dealId, stageId });
    if (result.ok) router.refresh();
    else notify('error', result.message);
  }

  const total = deals.reduce((sum, d) => sum + d.value, 0);

  return (
    <div>
      <p className="mb-4 text-sm text-neutral-500">
        Em pipeline: <span className="font-medium text-ink">{formatBRL(total)}</span>
      </p>
      <div className="flex gap-3 overflow-x-auto pb-4">
        {stages.map((stage) => {
          const stageDeals = deals.filter((d) => d.stageId === stage.id);
          const stageTotal = stageDeals.reduce((s, d) => s + d.value, 0);
          return (
            <div
              key={stage.id}
              onDragOver={(e) => e.preventDefault()}
              onDrop={() => onDrop(stage.id)}
              className="flex w-64 shrink-0 flex-col rounded-card border bg-neutral-50 p-3"
            >
              <div className="mb-2 flex items-center justify-between">
                <span className="text-sm font-medium text-ink">{stage.name}</span>
                <span className="text-xs text-neutral-400">{formatBRL(stageTotal)}</span>
              </div>
              <div className="flex flex-col gap-2">
                {stageDeals.map((d) => (
                  <div
                    key={d.id}
                    draggable
                    onDragStart={() => setDragging(d.id)}
                    className="cursor-grab rounded-button border bg-surface p-3 shadow-card active:cursor-grabbing"
                  >
                    <p className="text-sm font-medium text-ink">{d.title}</p>
                    <p className="text-xs text-neutral-500">{d.accountName}</p>
                    <div className="mt-1 flex justify-between text-xs">
                      <span className="text-ink">{formatBRL(d.value)}</span>
                      <span className="text-neutral-400">{d.probability}%</span>
                    </div>
                  </div>
                ))}
                {stageDeals.length === 0 ? (
                  <p className="py-2 text-center text-xs text-neutral-400">Vazio</p>
                ) : null}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

'use server';

import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { createProposalSchema, sendProposalSchema, setProposalStatusSchema } from './schemas';
import { getReminderDays } from './proposal-config';
import { type ActionResult, type FieldErrors, success, failure } from '@/core/domain/result';
import { toFieldErrors, resolveOwner } from '@/core/application/action-helpers';
import { authGateway, idGenerator, clock } from '@/core/infrastructure/services';
import { SupabaseProposalRepository } from '../infrastructure/proposal-repository';
import { SupabaseTaskRepository } from '@/modules/activities/infrastructure/task-repository';
import { SupabaseDealRepository } from '@/modules/pipeline/infrastructure/deal-repository';
import type { Proposal } from '../domain/entities';

const proposalRepo = new SupabaseProposalRepository();
const taskRepo = new SupabaseTaskRepository();
const dealRepo = new SupabaseDealRepository();

export async function createProposalAction(input: unknown): Promise<ActionResult<{ id: string }>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;

  const parsed = createProposalSchema.safeParse(input);
  if (!parsed.success) {
    return failure('validation', 'Verifique os campos.', toFieldErrors(parsed.error));
  }
  try {
    const id = idGenerator.generate();
    await proposalRepo.create({
      id,
      ownerId,
      dealId: parsed.data.dealId,
      value: parsed.data.value,
      validUntil: parsed.data.validUntil ? new Date(parsed.data.validUntil) : null,
    });
    revalidatePath('/propostas');
    return success({ id });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível criar a proposta.');
  }
}

export async function sendProposalAction(input: unknown): Promise<ActionResult<{ id: string }>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;

  const parsed = sendProposalSchema.safeParse(input);
  if (!parsed.success) return failure('validation', 'Dados inválidos.');

  const proposal = await proposalRepo.findById(ownerId, parsed.data.proposalId);
  if (!proposal) return failure('not_found', 'Proposta não encontrada.');

  try {
    await proposalRepo.markSent(ownerId, proposal.id, clock.now());

    // RN-03: agenda lembrete N dias antes do vencimento (via Task, mecanismo único).
    if (proposal.validUntil) {
      const reminderDays = await getReminderDays({ ownerId });
      const reminderAt = new Date(proposal.validUntil.getTime() - reminderDays * 86400_000);
      const deal = await dealRepo.findById(ownerId, proposal.dealId);
      if (deal) {
        await taskRepo.createTask({
          id: idGenerator.generate(),
          ownerId,
          accountId: deal.accountId,
          dealId: deal.id,
          title: 'Acompanhar proposta antes do vencimento',
          dueAt: reminderAt,
          priority: 1,
        });
      }
    }
    revalidatePath('/propostas');
    return success({ id: proposal.id });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível enviar a proposta.');
  }
}

export async function decideProposalAction(
  input: unknown,
): Promise<ActionResult<{ id: string; suggestsWon: boolean }>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;

  const parsed = setProposalStatusSchema.safeParse(input);
  if (!parsed.success) return failure('validation', 'Dados inválidos.');

  const proposal = await proposalRepo.findById(ownerId, parsed.data.proposalId);
  if (!proposal) return failure('not_found', 'Proposta não encontrada.');

  try {
    await proposalRepo.setStatus(ownerId, proposal.id, parsed.data.status);
    // RN-05: aceitar proposta SUGERE mover o Deal para Won — não executa.
    // A sugestão é sinalizada à UI; o fechamento é ação explícita do usuário
    // (closeDealAction), que então dispara o pós-venda (RN-06).
    let suggestsWon = false;
    if (parsed.data.status === 'accepted') {
      const deal = await dealRepo.findById(ownerId, proposal.dealId);
      suggestsWon = Boolean(deal && deal.status === 'open');
    }
    revalidatePath('/propostas');
    return success({ id: proposal.id, suggestsWon });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível atualizar a proposta.');
  }
}

export async function listAllProposalsAction(): Promise<ActionResult<Proposal[]>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  const ownerId = owner.ownerId;
  try {
    return success(await proposalRepo.listByOwner(ownerId));
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível carregar as propostas.');
  }
}

export async function listProposalsByDealsAction(
  dealIds: string[],
): Promise<ActionResult<Record<string, Proposal[]>>> {
  const owner = await resolveOwner();
  if (!owner) return failure('unauthenticated', 'Sua sessão expirou.');
  try {
    const all = await proposalRepo.listByDeals(owner.ownerId, dealIds);
    const grouped: Record<string, Proposal[]> = {};
    for (const p of all) {
      (grouped[p.dealId] ??= []).push(p);
    }
    return success(grouped);
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível carregar as propostas.');
  }
}

import type { OwnerContext } from '@/core/domain/contracts';
import { configStore } from '@/core/infrastructure/services';

/**
 * Lembrete N dias antes do vencimento (RN-03). Default 2 (configurável via
 * ConfigService — mecanismo único). Namespace 'proposals'.
 */
const DEFAULT_REMINDER_DAYS = 2;

export async function getReminderDays(owner: OwnerContext): Promise<number> {
  const stored = await configStore.get<number>(owner, 'proposals', 'reminder_days');
  return typeof stored === 'number' ? stored : DEFAULT_REMINDER_DAYS;
}

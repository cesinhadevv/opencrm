import { z } from 'zod';

export const createProposalSchema = z.object({
  dealId: z.string().min(1),
  value: z.number().int().min(0).max(100_000_000_000), // centavos (teto R$1bi, < 2^53)
  validUntil: z.string().datetime().nullable().optional(),
});

export const sendProposalSchema = z.object({
  proposalId: z.string().min(1),
});

export const setProposalStatusSchema = z.object({
  proposalId: z.string().min(1),
  status: z.enum(['accepted', 'rejected']),
});

export type CreateProposalInput = z.infer<typeof createProposalSchema>;

/**
 * Domínio — Propostas (Módulo 5).
 *
 * Proposal vinculada a um Deal. Status: draft/sent/accepted/rejected/expired.
 * RN-03: enviada agenda lembrete N dias antes do vencimento (via Task).
 * RN-04: ultrapassou validade sem resposta -> expired -> alerta.
 * RN-05: aceitar sugere mover Deal para Won.
 * Alimenta o componente "proposta a vencer" do Score (ADR-011-A).
 *
 * Cálculo temporal via Clock (DR-A3). Identidade por ID interno (ADR-012).
 */
import type { Clock } from '@/core/domain/contracts';

export type ProposalStatus = 'draft' | 'sent' | 'accepted' | 'rejected' | 'expired';

export interface Proposal {
  id: string;
  ownerId: string;
  dealId: string;
  value: number; // centavos
  status: ProposalStatus;
  sentAt: Date | null;
  validUntil: Date | null;
  createdAt: Date;
}

/**
 * RN-04: uma proposta 'sent' cuja validade passou está vencida.
 * Determinístico via Clock — nunca usa Date direto.
 */
export function isExpired(
  clock: Clock,
  proposal: Pick<Proposal, 'status' | 'validUntil'>,
): boolean {
  if (proposal.status !== 'sent' || !proposal.validUntil) return false;
  return proposal.validUntil.getTime() < clock.now().getTime();
}

/**
 * Componente "proposta a vencer" do Score (ADR-011-A): true se há proposta 'sent'
 * vencendo dentro da janela (em dias) OU já vencida sem resposta.
 */
export function isProposalDueSoon(
  clock: Clock,
  timeZone: string,
  windowDays: number,
  proposal: Pick<Proposal, 'status' | 'validUntil'> | null,
): boolean {
  if (!proposal || proposal.status !== 'sent' || !proposal.validUntil) return false;
  const now = clock.now();
  if (proposal.validUntil.getTime() < now.getTime()) return true; // já vencida
  const days = clock.daysBetween(now, proposal.validUntil, timeZone);
  return days <= windowDays;
}

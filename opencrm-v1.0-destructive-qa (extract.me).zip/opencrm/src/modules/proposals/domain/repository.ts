import type { Proposal, ProposalStatus } from './entities';

export interface CreateProposalData {
  id: string;
  ownerId: string;
  dealId: string;
  value: number;
  validUntil: Date | null;
}

export interface ProposalRepository {
  create(data: CreateProposalData): Promise<void>;
  findById(ownerId: string, id: string): Promise<Proposal | null>;
  listByDeal(ownerId: string, dealId: string): Promise<Proposal[]>;
  listByDeals(ownerId: string, dealIds: string[]): Promise<Proposal[]>;
  listByOwner(ownerId: string): Promise<Proposal[]>;
  markSent(ownerId: string, id: string, sentAt: Date): Promise<void>;
  setStatus(ownerId: string, id: string, status: ProposalStatus): Promise<void>;
}

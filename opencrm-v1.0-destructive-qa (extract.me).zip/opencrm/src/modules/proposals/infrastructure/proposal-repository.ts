import { createSupabaseServerClient } from '@/lib/supabase/server';
import { ensure } from '@/lib/supabase/guard';
import type { ProposalRepository, CreateProposalData } from '../domain/repository';
import type { Proposal, ProposalStatus } from '../domain/entities';

interface ProposalRow {
  id: string;
  owner_id: string;
  deal_id: string;
  value: number;
  status: ProposalStatus;
  sent_at: string | null;
  valid_until: string | null;
  created_at: string;
}

function mapProposal(r: ProposalRow): Proposal {
  return {
    id: r.id,
    ownerId: r.owner_id,
    dealId: r.deal_id,
    value: Number(r.value),
    status: r.status,
    sentAt: r.sent_at ? new Date(r.sent_at) : null,
    validUntil: r.valid_until ? new Date(r.valid_until) : null,
    createdAt: new Date(r.created_at),
  };
}

const COLS = 'id, owner_id, deal_id, value, status, sent_at, valid_until, created_at';

export class SupabaseProposalRepository implements ProposalRepository {
  async create(data: CreateProposalData): Promise<void> {
    const supabase = await createSupabaseServerClient();
    ensure(
      await supabase.from('proposals').insert({
        id: data.id,
        owner_id: data.ownerId,
        deal_id: data.dealId,
        value: data.value,
        valid_until: data.validUntil?.toISOString() ?? null,
      }),
    );
  }

  async findById(ownerId: string, id: string): Promise<Proposal | null> {
    const supabase = await createSupabaseServerClient();
    const { data } = await supabase
      .from('proposals')
      .select(COLS)
      .eq('owner_id', ownerId)
      .eq('id', id)
      .is('deleted_at', null)
      .maybeSingle();
    return data ? mapProposal(data as ProposalRow) : null;
  }

  async listByDeal(ownerId: string, dealId: string): Promise<Proposal[]> {
    const supabase = await createSupabaseServerClient();
    const { data } = await supabase
      .from('proposals')
      .select(COLS)
      .eq('owner_id', ownerId)
      .eq('deal_id', dealId)
      .is('deleted_at', null)
      .order('created_at', { ascending: false });
    return (data ?? []).map((r) => mapProposal(r as ProposalRow));
  }

  async listByOwner(ownerId: string): Promise<Proposal[]> {
    const supabase = await createSupabaseServerClient();
    const { data } = await supabase
      .from('proposals')
      .select(COLS)
      .eq('owner_id', ownerId)
      .is('deleted_at', null)
      .order('created_at', { ascending: false });
    return (data ?? []).map((r) => mapProposal(r as ProposalRow));
  }

  async markSent(ownerId: string, id: string, sentAt: Date): Promise<void> {
    const supabase = await createSupabaseServerClient();
    ensure(
      await supabase
        .from('proposals')
        .update({ status: 'sent', sent_at: sentAt.toISOString() })
        .eq('owner_id', ownerId)
        .eq('id', id)
        .is('deleted_at', null),
    );
  }

  async setStatus(ownerId: string, id: string, status: ProposalStatus): Promise<void> {
    const supabase = await createSupabaseServerClient();
    ensure(
      await supabase
        .from('proposals')
        .update({ status })
        .eq('owner_id', ownerId)
        .eq('id', id)
        .is('deleted_at', null),
    );
  }
  async listByDeals(ownerId: string, dealIds: string[]): Promise<Proposal[]> {
    if (dealIds.length === 0) return [];
    const supabase = await createSupabaseServerClient();
    const { data } = await supabase
      .from('proposals')
      .select(COLS)
      .eq('owner_id', ownerId)
      .in('deal_id', dealIds)
      .is('deleted_at', null)
      .order('created_at', { ascending: false });
    return (data ?? []).map((r) => mapProposal(r as ProposalRow));
  }
}

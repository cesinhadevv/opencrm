'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import type { Proposal } from '../domain/entities';
import {
  createProposalAction,
  sendProposalAction,
  decideProposalAction,
} from '../application/actions';
import { formatBRL, STATUS_LABEL } from './format';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/providers/toast-provider';

/** Propostas de um Deal, dentro do Perfil da Empresa. Criar/enviar/aceitar/recusar. */
export function DealProposals({ dealId, proposals }: { dealId: string; proposals: Proposal[] }) {
  const router = useRouter();
  const { notify } = useToast();
  const [value, setValue] = useState('');
  const [validUntil, setValidUntil] = useState('');
  const [pending, setPending] = useState(false);

  async function create() {
    if (!value) return;
    setPending(true);
    const result = await createProposalAction({
      dealId,
      value: Math.round(Number(value) * 100),
      validUntil: validUntil ? new Date(validUntil).toISOString() : null,
    });
    setPending(false);
    if (result.ok) {
      notify('success', 'Proposta criada.');
      setValue('');
      setValidUntil('');
      router.refresh();
    } else notify('error', result.message);
  }

  async function send(id: string) {
    const r = await sendProposalAction({ proposalId: id });
    if (r.ok) {
      notify('success', 'Proposta enviada. Lembrete agendado.');
      router.refresh();
    } else notify('error', r.message);
  }

  async function decide(id: string, status: 'accepted' | 'rejected') {
    const r = await decideProposalAction({ proposalId: id, status });
    if (r.ok) {
      if (status === 'accepted') {
        notify(
          'success',
          r.data.suggestsWon
            ? 'Proposta aceita! Marque a oportunidade como Ganha para concluir.'
            : 'Proposta aceita!',
        );
      } else {
        notify('success', 'Proposta recusada.');
      }
      router.refresh();
    } else notify('error', r.message);
  }

  return (
    <div className="flex flex-col gap-3">
      {proposals.length > 0 ? (
        <ul className="flex flex-col gap-2">
          {proposals.map((p) => (
            <li key={p.id} className="rounded-button border px-3 py-2">
              <div className="flex justify-between">
                <span className="text-sm text-ink">{formatBRL(p.value)}</span>
                <span className="text-xs text-neutral-400">{STATUS_LABEL[p.status]}</span>
              </div>
              {p.validUntil ? (
                <p className="text-xs text-neutral-400">
                  Vence em {p.validUntil.toLocaleDateString('pt-BR')}
                </p>
              ) : null}
              <div className="mt-2 flex gap-2">
                {p.status === 'draft' ? <Button onClick={() => send(p.id)}>Enviar</Button> : null}
                {p.status === 'sent' ? (
                  <>
                    <Button onClick={() => decide(p.id, 'accepted')}>Aceita</Button>
                    <Button variant="secondary" onClick={() => decide(p.id, 'rejected')}>
                      Recusada
                    </Button>
                  </>
                ) : null}
              </div>
            </li>
          ))}
        </ul>
      ) : null}

      <div className="flex flex-col gap-2 rounded-button border p-3">
        <Input
          type="number"
          min="0"
          step="0.01"
          placeholder="Valor (R$)"
          value={value}
          onChange={(e) => setValue(e.target.value)}
        />
        <input
          type="date"
          value={validUntil}
          aria-label="Válida até"
          onChange={(e) => setValidUntil(e.target.value)}
          className="h-10 rounded-button border bg-surface px-3 text-sm text-ink focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/30"
        />
        <Button onClick={create} disabled={pending || !value}>
          {pending ? 'Criando…' : 'Nova proposta'}
        </Button>
      </div>
    </div>
  );
}

export { formatBRL } from '@/lib/utils/currency';

import type { ProposalStatus } from '../domain/entities';

export const STATUS_LABEL: Record<ProposalStatus, string> = {
  draft: 'Rascunho',
  sent: 'Enviada',
  accepted: 'Aceita',
  rejected: 'Recusada',
  expired: 'Vencida',
};

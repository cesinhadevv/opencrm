'use client';

import Link from 'next/link';
import type { Proposal } from '../domain/entities';
import { formatBRL, STATUS_LABEL } from './format';
import { Card } from '@/components/ui/card';

/** Lista geral de propostas com derivação de vencimento já resolvida no servidor. */
export function ProposalList({
  proposals,
  expiredIds,
}: {
  proposals: Proposal[];
  expiredIds: string[];
}) {
  if (proposals.length === 0) {
    return (
      <Card className="text-center">
        <p className="text-base font-medium text-ink">Nenhuma proposta ainda</p>
        <p className="mt-2 text-sm text-neutral-500">
          Crie propostas a partir das oportunidades no perfil de cada empresa.
        </p>
      </Card>
    );
  }
  const expired = new Set(expiredIds);
  return (
    <ul className="flex flex-col gap-2">
      {proposals.map((p) => {
        const isExpired = expired.has(p.id);
        return (
          <li
            key={p.id}
            className="flex items-center justify-between rounded-card border bg-surface px-4 py-3"
          >
            <div>
              <p className="text-sm font-medium text-ink">{formatBRL(p.value)}</p>
              <p className="text-xs text-neutral-400">
                {isExpired ? 'Vencida' : STATUS_LABEL[p.status]}
                {p.validUntil ? ` · vence ${p.validUntil.toLocaleDateString('pt-BR')}` : ''}
              </p>
            </div>
            <Link
              href={`/empresas`}
              className={'text-xs ' + (isExpired ? 'text-attention' : 'text-neutral-400')}
            >
              {isExpired ? '⚠ Atenção' : ''}
            </Link>
          </li>
        );
      })}
    </ul>
  );
}

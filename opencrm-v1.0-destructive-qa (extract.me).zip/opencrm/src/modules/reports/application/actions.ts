'use server';

import { type ActionResult, success, failure } from '@/core/domain/result';
import { authGateway, clock, profileRepository } from '@/core/infrastructure/services';
import { SupabaseReportsRepository } from '../infrastructure/reports-repository';
import { resolvePeriod, type PeriodPreset } from './period';
import type { FullReport } from './reports-types';
import {
  computeDealMetrics,
  type ReportMetrics,
  type ProposalFacts,
  type ActivityFacts,
  type AfterSaleFacts,
} from '../domain/metrics';

const repo = new SupabaseReportsRepository();

export async function getReportAction(
  preset: PeriodPreset = 'this_month',
): Promise<ActionResult<FullReport>> {
  const session = await authGateway.getSession();
  if (!session) return failure('unauthenticated', 'Sua sessão expirou.');

  try {
    const profile = await profileRepository.findById(session.userId);
    const timeZone = profile?.timeZone ?? 'America/Sao_Paulo';
    const period = resolvePeriod(clock, preset);

    const [deals, proposals, activities, afterSale] = await Promise.all([
      repo.listDealFacts(session.userId, period),
      repo.proposalFacts(session.userId, period),
      repo.activityFacts(session.userId, period),
      repo.afterSaleFacts(session.userId, period),
    ]);

    // Tempo de fechamento por deal ganho — dias calculados via Clock (DR-A3).
    const daysToClosePerWon = deals
      .filter((d) => d.status === 'won' && d.wonAt)
      .map((d) => clock.daysBetween(d.createdAt, d.wonAt as Date, timeZone));

    const metrics = computeDealMetrics(deals, daysToClosePerWon);

    return success({ preset, metrics, proposals, activities, afterSale });
  } catch (error) {
    console.error('[action error]', error);
    return failure('internal', 'Não foi possível gerar o relatório.');
  }
}

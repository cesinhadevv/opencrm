import type { Clock } from '@/core/domain/contracts';
import type { ReportPeriod } from '../domain/metrics';

export type PeriodPreset = 'this_month' | 'last_30_days' | 'this_year' | 'all_time';

/**
 * Resolve um preset de período em datas concretas, via Clock (DR-A3).
 * Todo "agora" passa pelo Clock — nunca Date direto na regra.
 */
export function resolvePeriod(clock: Clock, preset: PeriodPreset): ReportPeriod {
  const now = clock.now();
  const to = now;
  let from: Date;
  switch (preset) {
    case 'last_30_days':
      from = new Date(now.getTime() - 30 * 86400_000);
      break;
    case 'this_month':
      from = new Date(now.getFullYear(), now.getMonth(), 1);
      break;
    case 'this_year':
      from = new Date(now.getFullYear(), 0, 1);
      break;
    case 'all_time':
    default:
      from = new Date(0);
      break;
  }
  return { from, to };
}

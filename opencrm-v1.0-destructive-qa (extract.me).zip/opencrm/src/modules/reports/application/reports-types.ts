/** Tipo do relatório completo (sem 'use server'). */
import type {
  ReportMetrics,
  ProposalFacts,
  ActivityFacts,
  AfterSaleFacts,
} from '../domain/metrics';
import type { PeriodPreset } from './period';

export interface FullReport {
  preset: PeriodPreset;
  metrics: ReportMetrics;
  proposals: ProposalFacts;
  activities: ActivityFacts;
  afterSale: AfterSaleFacts;
}

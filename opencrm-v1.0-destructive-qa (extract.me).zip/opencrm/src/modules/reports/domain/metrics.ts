/**
 * Domínio — Relatórios (Módulo 9).
 *
 * Métricas DERIVADAS das entidades existentes — NUNCA persistidas (PRD M9, ADR-011).
 * Funções puras de cálculo, determinísticas. Cálculo temporal via Clock (DR-A3),
 * recebido como número de dias já resolvido pela aplicação (domínio não toca Date direto
 * para "agora", mas opera sobre datas factuais das entidades).
 */

export interface DealFact {
  id: string;
  value: number; // centavos
  status: 'open' | 'won' | 'lost';
  stageId: string | null;
  createdAt: Date;
  wonAt: Date | null;
  lostAt: Date | null;
}

export interface ReportPeriod {
  from: Date;
  to: Date;
}

export interface FunnelStageMetric {
  stageId: string;
  count: number;
  totalValue: number;
}

export interface ReportMetrics {
  pipelineOpenValue: number;
  pipelineOpenCount: number;
  wonValue: number;
  wonCount: number;
  lostValue: number;
  lostCount: number;
  conversionRate: number; // 0-1 (won / (won+lost))
  averageTicket: number; // centavos, sobre won
  averageDaysToClose: number; // dias, sobre won (wonAt - createdAt)
  funnel: FunnelStageMetric[];
}

export interface ProposalFacts {
  sent: number;
  accepted: number;
  rejected: number;
  expired: number;
}

export interface ActivityFacts {
  activitiesDone: number;
  pendingFollowUps: number;
}

export interface AfterSaleFacts {
  customers: number;
  upsells: number;
  referrals: number;
}

/** Filtra deals por interseção de createdAt com o período. */
export function filterByPeriod(deals: DealFact[], period: ReportPeriod): DealFact[] {
  return deals.filter(
    (d) =>
      d.createdAt.getTime() >= period.from.getTime() &&
      d.createdAt.getTime() <= period.to.getTime(),
  );
}

/** Taxa de conversão = won / (won + lost). 0 quando não há fechados. */
export function conversionRate(wonCount: number, lostCount: number): number {
  const closed = wonCount + lostCount;
  return closed === 0 ? 0 : wonCount / closed;
}

/** Ticket médio (centavos) sobre os deals ganhos. 0 quando não há ganhos. */
export function averageTicket(wonDeals: DealFact[]): number {
  if (wonDeals.length === 0) return 0;
  const total = wonDeals.reduce((s, d) => s + d.value, 0);
  return Math.round(total / wonDeals.length);
}

/**
 * Tempo médio de fechamento (dias) sobre os deals ganhos: média de (wonAt - createdAt).
 * Recebe os dias já calculados via Clock pela aplicação para manter pureza temporal.
 */
export function averageDaysToClose(daysPerWonDeal: number[]): number {
  if (daysPerWonDeal.length === 0) return 0;
  const total = daysPerWonDeal.reduce((s, d) => s + d, 0);
  return Math.round(total / daysPerWonDeal.length);
}

/** Funil por estágio: conta e soma valor dos deals OPEN por stageId. */
export function buildFunnel(openDeals: DealFact[]): FunnelStageMetric[] {
  const map = new Map<string, FunnelStageMetric>();
  for (const d of openDeals) {
    if (!d.stageId) continue;
    const cur = map.get(d.stageId) ?? { stageId: d.stageId, count: 0, totalValue: 0 };
    cur.count += 1;
    cur.totalValue += d.value;
    map.set(d.stageId, cur);
  }
  return [...map.values()];
}

/** Agrega as métricas de deals (sem persistir). daysToClose já resolvido via Clock. */
export function computeDealMetrics(
  deals: DealFact[],
  daysToClosePerWon: number[],
): Omit<ReportMetrics, never> {
  const open = deals.filter((d) => d.status === 'open');
  const won = deals.filter((d) => d.status === 'won');
  const lost = deals.filter((d) => d.status === 'lost');
  return {
    pipelineOpenValue: open.reduce((s, d) => s + d.value, 0),
    pipelineOpenCount: open.length,
    wonValue: won.reduce((s, d) => s + d.value, 0),
    wonCount: won.length,
    lostValue: lost.reduce((s, d) => s + d.value, 0),
    lostCount: lost.length,
    conversionRate: conversionRate(won.length, lost.length),
    averageTicket: averageTicket(won),
    averageDaysToClose: averageDaysToClose(daysToClosePerWon),
    funnel: buildFunnel(open),
  };
}

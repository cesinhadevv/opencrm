import type {
  DealFact,
  ProposalFacts,
  ActivityFacts,
  AfterSaleFacts,
  ReportPeriod,
} from './metrics';

/**
 * Contrato de leitura agregada (somente leitura). A implementação consulta as
 * tabelas existentes (deals, activities, tasks, proposals, aftersale_records).
 * Nenhuma métrica é persistida (PRD M9).
 */
export interface ReportsRepository {
  listDealFacts(ownerId: string, period: ReportPeriod): Promise<DealFact[]>;
  proposalFacts(ownerId: string, period: ReportPeriod): Promise<ProposalFacts>;
  activityFacts(ownerId: string, period: ReportPeriod): Promise<ActivityFacts>;
  afterSaleFacts(ownerId: string, period: ReportPeriod): Promise<AfterSaleFacts>;
}

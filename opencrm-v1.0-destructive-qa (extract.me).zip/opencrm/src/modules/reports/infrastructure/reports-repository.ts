import { createSupabaseServerClient } from '@/lib/supabase/server';
import { ensure } from '@/lib/supabase/guard';
import type { ReportsRepository } from '../domain/repository';
import type {
  DealFact,
  ProposalFacts,
  ActivityFacts,
  AfterSaleFacts,
  ReportPeriod,
} from '../domain/metrics';

/**
 * Implementação de leitura agregada. Consome tabelas existentes; respeita owner
 * e soft delete por padrão (DR-B1). Nenhuma escrita, nenhuma métrica persistida.
 */
export class SupabaseReportsRepository implements ReportsRepository {
  async listDealFacts(ownerId: string, period: ReportPeriod): Promise<DealFact[]> {
    const supabase = await createSupabaseServerClient();
    const { data } = await supabase
      .from('deals')
      .select('id, value, status, stage_id, created_at, won_at, lost_at')
      .eq('owner_id', ownerId)
      .is('deleted_at', null)
      .gte('created_at', period.from.toISOString())
      .lte('created_at', period.to.toISOString());
    return (data ?? []).map((r) => ({
      id: r.id,
      value: Number(r.value),
      status: r.status,
      stageId: r.stage_id,
      createdAt: new Date(r.created_at),
      wonAt: r.won_at ? new Date(r.won_at) : null,
      lostAt: r.lost_at ? new Date(r.lost_at) : null,
    }));
  }

  async proposalFacts(ownerId: string, period: ReportPeriod): Promise<ProposalFacts> {
    const supabase = await createSupabaseServerClient();
    const { data } = await supabase
      .from('proposals')
      .select('status, sent_at, valid_until, created_at')
      .eq('owner_id', ownerId)
      .is('deleted_at', null)
      .gte('created_at', period.from.toISOString())
      .lte('created_at', period.to.toISOString());
    const rows = data ?? [];
    const now = Date.now();
    return {
      // Enviadas: já passaram pelo envio (têm sent_at), independentemente do estado atual.
      sent: rows.filter((r) => r.sent_at !== null).length,
      accepted: rows.filter((r) => r.status === 'accepted').length,
      rejected: rows.filter((r) => r.status === 'rejected').length,
      // A2: vencida é derivada (status nunca é gravado como 'expired'):
      // ainda 'sent' e cuja validade já passou. Mesma regra de domínio (isExpired).
      expired: rows.filter(
        (r) =>
          r.status === 'sent' && r.valid_until !== null && new Date(r.valid_until).getTime() < now,
      ).length,
    };
  }

  async activityFacts(ownerId: string, period: ReportPeriod): Promise<ActivityFacts> {
    const supabase = await createSupabaseServerClient();
    const [{ count: activitiesDone }, { count: pendingFollowUps }] = await Promise.all([
      supabase
        .from('activities')
        .select('id', { count: 'exact', head: true })
        .eq('owner_id', ownerId)
        .is('deleted_at', null)
        .gte('occurred_at', period.from.toISOString())
        .lte('occurred_at', period.to.toISOString()),
      supabase
        .from('tasks')
        .select('id', { count: 'exact', head: true })
        .eq('owner_id', ownerId)
        .eq('status', 'open')
        .is('deleted_at', null),
    ]);
    return {
      activitiesDone: activitiesDone ?? 0,
      pendingFollowUps: pendingFollowUps ?? 0,
    };
  }

  async afterSaleFacts(ownerId: string, period: ReportPeriod): Promise<AfterSaleFacts> {
    const supabase = await createSupabaseServerClient();
    const [{ count: customers }, upsellRes, referralRes] = await Promise.all([
      supabase
        .from('deals')
        .select('id', { count: 'exact', head: true })
        .eq('owner_id', ownerId)
        .eq('status', 'won')
        .is('deleted_at', null),
      supabase
        .from('aftersale_records')
        .select('id', { count: 'exact', head: true })
        .eq('owner_id', ownerId)
        .eq('type', 'upsell')
        .is('deleted_at', null)
        .gte('created_at', period.from.toISOString())
        .lte('created_at', period.to.toISOString()),
      supabase
        .from('aftersale_records')
        .select('id', { count: 'exact', head: true })
        .eq('owner_id', ownerId)
        .eq('type', 'referral')
        .is('deleted_at', null)
        .gte('created_at', period.from.toISOString())
        .lte('created_at', period.to.toISOString()),
    ]);
    return {
      customers: customers ?? 0,
      upsells: upsellRes.count ?? 0,
      referrals: referralRes.count ?? 0,
    };
  }
}

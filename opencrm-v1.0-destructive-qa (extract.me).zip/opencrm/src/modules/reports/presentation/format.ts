export { formatBRL } from '@/lib/utils/currency';
export function formatPercent(ratio: number): string {
  return `${Math.round(ratio * 100)}%`;
}

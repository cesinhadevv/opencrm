'use client';

import { Suspense } from 'react';

import { useRouter, useSearchParams } from 'next/navigation';
import type { FullReport } from '../application/reports-types';
import type { PeriodPreset } from '../application/period';
import { formatBRL, formatPercent } from './format';
import { Card } from '@/components/ui/card';

const PRESETS: { value: PeriodPreset; label: string }[] = [
  { value: 'this_month', label: 'Este mês' },
  { value: 'last_30_days', label: '30 dias' },
  { value: 'this_year', label: 'Este ano' },
  { value: 'all_time', label: 'Tudo' },
];

/** Dashboard executivo minimalista (PRD M9). Métricas derivadas, não persistidas. */
function ReportDashboardInner({ report }: { report: FullReport }) {
  const router = useRouter();
  const params = useSearchParams();
  const current = (params.get('period') as PeriodPreset) ?? report.preset;

  function setPeriod(p: PeriodPreset) {
    router.push(`/relatorios?period=${p}`);
  }

  const { metrics, proposals, activities, afterSale } = report;

  return (
    <div className="mx-auto max-w-4xl">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-ink">Relatórios</h1>
        <div className="flex gap-1">
          {PRESETS.map((p) => (
            <button
              key={p.value}
              onClick={() => setPeriod(p.value)}
              className={
                'rounded-button px-2.5 py-1 text-xs transition-colors duration-fast ' +
                (current === p.value
                  ? 'bg-brand/10 text-brand'
                  : 'text-neutral-500 hover:bg-neutral-100')
              }
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* Métricas principais */}
      <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-4">
        <Metric
          label="Em pipeline"
          value={formatBRL(metrics.pipelineOpenValue)}
          hint={`${metrics.pipelineOpenCount} aberto(s)`}
        />
        <Metric
          label="Fechado (ganho)"
          value={formatBRL(metrics.wonValue)}
          hint={`${metrics.wonCount} negócio(s)`}
        />
        <Metric label="Conversão" value={formatPercent(metrics.conversionRate)} />
        <Metric label="Ticket médio" value={formatBRL(metrics.averageTicket)} />
      </div>
      <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        <Metric label="Tempo médio fechamento" value={`${metrics.averageDaysToClose}d`} />
        <Metric
          label="Perdidos"
          value={String(metrics.lostCount)}
          hint={formatBRL(metrics.lostValue)}
        />
        <Metric label="Atividades" value={String(activities.activitiesDone)} />
        <Metric label="Follow-ups pendentes" value={String(activities.pendingFollowUps)} />
      </div>

      {/* Funil */}
      <Card className="mb-4">
        <h2 className="mb-3 text-sm font-semibold text-ink">Funil por estágio (aberto)</h2>
        {metrics.funnel.length === 0 ? (
          <p className="text-sm text-neutral-500">Sem oportunidades abertas no período.</p>
        ) : (
          <ul className="flex flex-col gap-2">
            {metrics.funnel.map((f) => (
              <li key={f.stageId} className="flex justify-between text-sm">
                <span className="text-neutral-500">{f.count} oportunidade(s)</span>
                <span className="text-ink">{formatBRL(f.totalValue)}</span>
              </li>
            ))}
          </ul>
        )}
      </Card>

      {/* Propostas + Pós-venda */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <h2 className="mb-3 text-sm font-semibold text-ink">Propostas</h2>
          <Row label="Enviadas" value={proposals.sent} />
          <Row label="Aceitas" value={proposals.accepted} />
          <Row label="Recusadas" value={proposals.rejected} />
          <Row label="Vencidas" value={proposals.expired} />
        </Card>
        <Card>
          <h2 className="mb-3 text-sm font-semibold text-ink">Pós-venda</h2>
          <Row label="Clientes" value={afterSale.customers} />
          <Row label="Upsells" value={afterSale.upsells} />
          <Row label="Indicações" value={afterSale.referrals} />
        </Card>
      </div>
    </div>
  );
}

function Metric({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-card border bg-surface p-4">
      <p className="text-xs text-neutral-500">{label}</p>
      <p className="mt-1 text-lg font-semibold text-ink">{value}</p>
      {hint ? <p className="mt-0.5 text-xs text-neutral-400">{hint}</p> : null}
    </div>
  );
}

function Row({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex justify-between py-1 text-sm">
      <span className="text-neutral-500">{label}</span>
      <span className="text-ink">{value}</span>
    </div>
  );
}

export function ReportDashboard({ report }: { report: FullReport }) {
  return (
    <Suspense fallback={null}>
      <ReportDashboardInner report={report} />
    </Suspense>
  );
}

import { ScoreService } from '../domain/score-service';
import { DEFAULT_SCORE_RANGES } from '../domain/score-config';
import { validateRangeSet } from '@/core/domain/range-normalizer';

/**
 * Factory do ScoreService. Valida as faixas na CARGA (fail fast — ADR-011-A / Playbook).
 * Configuração inválida impede a inicialização (lança RangeValidationError).
 *
 * Quando o Módulo 6 tornar as faixas configuráveis, ele lê da config do owner e
 * passa por esta mesma validação — sem mecanismo paralelo.
 */
validateRangeSet(DEFAULT_SCORE_RANGES.value);
validateRangeSet(DEFAULT_SCORE_RANGES.urgency);
validateRangeSet(DEFAULT_SCORE_RANGES.proximity);

export const scoreService = new ScoreService(DEFAULT_SCORE_RANGES);

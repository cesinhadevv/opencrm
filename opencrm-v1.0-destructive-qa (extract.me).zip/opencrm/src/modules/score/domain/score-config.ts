import type { RangeSet } from '@/core/domain/range-normalizer';

/**
 * Configuração do Score v0 (ADR-011-A). Pesos CONGELADOS (ADR-011).
 * Faixas são valores DEFAULT de seed (não fazem parte do ADR — DR-A4/CR-002 revisado);
 * vivem na configuração do owner, calibráveis sem alterar arquitetura.
 */

/** Pesos congelados (ADR-011). Somam 1.0. */
export const SCORE_WEIGHTS = {
  probability: 0.35,
  value: 0.3,
  urgency: 0.2,
  proximity: 0.1,
  proposal: 0.05,
} as const;

export interface ScoreRangeConfig {
  /** Faixas de valor (centavos) -> subscore, ascendente com teto. */
  value: RangeSet;
  /** Faixas de dias desde última interação -> subscore, ascendente com teto. */
  urgency: RangeSet;
  /** Faixas de dias até fechamento -> subscore, descendente. */
  proximity: RangeSet;
}

/**
 * Defaults de seed (calibráveis). Valores em centavos para "value".
 * Faixas conforme ADR-011-A (exemplos de partida; cobertura total + teto Infinity).
 */
export const DEFAULT_SCORE_RANGES: ScoreRangeConfig = {
  value: {
    direction: 'ascending',
    ranges: [
      { min: 0, max: 500_000, score: 20 }, // até R$5k
      { min: 500_000, max: 1_500_000, score: 40 }, // R$5k–15k
      { min: 1_500_000, max: 3_000_000, score: 60 }, // R$15k–30k
      { min: 3_000_000, max: 5_000_000, score: 80 }, // R$30k–50k
      { min: 5_000_000, max: Infinity, score: 100 }, // > R$50k (teto)
    ],
  },
  urgency: {
    direction: 'ascending',
    ranges: [
      { min: 0, max: 3, score: 0 },
      { min: 3, max: 6, score: 30 },
      { min: 6, max: 11, score: 60 },
      { min: 11, max: 21, score: 85 },
      { min: 21, max: Infinity, score: 100 },
    ],
  },
  proximity: {
    direction: 'descending',
    ranges: [
      { min: 0, max: 4, score: 100 }, // <=3 dias
      { min: 4, max: 8, score: 80 }, // 4-7
      { min: 8, max: 16, score: 60 }, // 8-15
      { min: 16, max: 31, score: 40 }, // 16-30
      { min: 31, max: Infinity, score: 20 }, // >30
    ],
  },
};

/** Janela default (dias) em que "proposta a vencer" pontua 100 (ADR-011-A). */
export const DEFAULT_PROPOSAL_WINDOW_DAYS = 5;

import type { Clock } from '@/core/domain/contracts';
import { normalizeByRanges } from '@/core/domain/range-normalizer';
import { SCORE_WEIGHTS, type ScoreRangeConfig } from './score-config';

/**
 * ScoreService — cálculo determinístico do Score v0 (ADR-011 / ADR-011-A).
 *
 * Princípios congelados:
 *  - determinístico, NUNCA depende de IA;
 *  - calculado sob demanda (derivado), nunca persistido;
 *  - explicável: a decomposição dos fatores É a explicação (RN-14);
 *  - a UI consome via esta interface, sem conhecer a fórmula (DR-A5).
 *
 * Entrada: dados já materializados do Deal (a camada de aplicação resolve os
 * casos especiais — "sem data", "vencido" — antes de chamar, conforme nota de
 * Playbook sobre a fronteira do normalizador).
 */

export interface ScoreInput {
  /** Probabilidade efetiva do Deal (0-100). */
  probability: number;
  /** Valor do Deal em centavos. */
  value: number;
  /** Dias desde a última interação real (já calculado via Clock). Null = sem interação. */
  daysSinceLastInteraction: number | null;
  /** Dias até a data prevista de fechamento (já calculado). Null = sem data; <0 = vencida. */
  daysToExpectedClose: number | null;
  /** Proposta ativa vence dentro da janela, ou já vencida sem resposta. */
  proposalDueSoon: boolean;
}

export interface ScoreBreakdown {
  total: number; // 0-100
  components: {
    probability: number;
    value: number;
    urgency: number;
    proximity: number;
    proposal: number;
  };
}

export class ScoreService {
  constructor(private readonly ranges: ScoreRangeConfig) {}

  calculate(input: ScoreInput): ScoreBreakdown {
    // Probabilidade: mapeamento direto (0-100).
    const probability = clamp(input.probability);

    // Valor: faixas com teto.
    const value = normalizeByRanges(input.value, this.ranges.value);

    // Urgência: dias desde última interação. Sem interação => urgência máxima
    // (tratamento de caso especial antes do normalizador).
    const urgency =
      input.daysSinceLastInteraction === null
        ? 100
        : normalizeByRanges(input.daysSinceLastInteraction, this.ranges.urgency);

    // Proximidade: dias até fechamento. Sem data => 0 (neutro); vencida (<0) => 100.
    let proximity: number;
    if (input.daysToExpectedClose === null) proximity = 0;
    else if (input.daysToExpectedClose < 0) proximity = 100;
    else proximity = normalizeByRanges(input.daysToExpectedClose, this.ranges.proximity);

    // Proposta a vencer: binário.
    const proposal = input.proposalDueSoon ? 100 : 0;

    const total =
      probability * SCORE_WEIGHTS.probability +
      value * SCORE_WEIGHTS.value +
      urgency * SCORE_WEIGHTS.urgency +
      proximity * SCORE_WEIGHTS.proximity +
      proposal * SCORE_WEIGHTS.proposal;

    return {
      total: Math.round(total),
      components: { probability, value, urgency, proximity, proposal },
    };
  }
}

function clamp(n: number): number {
  return Math.max(0, Math.min(100, n));
}

/**
 * Helper para calcular os dias a partir de datas, usando o Clock (DR-A3).
 * Mantém o ScoreService puro (recebe números), centralizando o tempo no Clock.
 */
export function buildScoreTimes(
  clock: Clock,
  timeZone: string,
  lastInteractionAt: Date | null,
  expectedCloseAt: Date | null,
): { daysSinceLastInteraction: number | null; daysToExpectedClose: number | null } {
  const now = clock.now();
  return {
    daysSinceLastInteraction:
      lastInteractionAt === null ? null : clock.daysBetween(lastInteractionAt, now, timeZone),
    daysToExpectedClose:
      expectedCloseAt === null ? null : signedDaysTo(clock, now, expectedCloseAt, timeZone),
  };
}

function signedDaysTo(clock: Clock, now: Date, target: Date, timeZone: string): number {
  const days = clock.daysBetween(now, target, timeZone);
  return target.getTime() < now.getTime() ? -days : days;
}

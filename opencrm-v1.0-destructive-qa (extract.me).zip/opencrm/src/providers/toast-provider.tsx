'use client';

import { createContext, useCallback, useContext, useState, type ReactNode } from 'react';
import { cn } from '@/lib/utils/cn';

/**
 * Sistema de Toasts (Tech Spec C.5). Não interrompe; desliza e se dissolve.
 * Tipos semânticos (Design Bible). Auto-dismiss; empilhamento ordenado.
 */
type ToastType = 'success' | 'attention' | 'error' | 'info';
interface Toast {
  id: string;
  type: ToastType;
  message: string;
}

const ToastContext = createContext<{ notify: (type: ToastType, message: string) => void } | null>(
  null,
);

const typeClasses: Record<ToastType, string> = {
  success: 'border-l-success',
  attention: 'border-l-attention',
  error: 'border-l-urgent',
  info: 'border-l-brand',
};

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const notify = useCallback((type: ToastType, message: string) => {
    const id = Math.random().toString(36).slice(2);
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 4000);
  }, []);

  return (
    <ToastContext.Provider value={{ notify }}>
      {children}
      <div
        className="pointer-events-none fixed bottom-4 right-4 z-50 flex flex-col gap-2"
        role="status"
        aria-live="polite"
      >
        {toasts.map((t) => (
          <div
            key={t.id}
            className={cn(
              'pointer-events-auto rounded-card border border-l-4 bg-surface px-4 py-3 text-sm text-ink shadow-overlay',
              'animate-in',
              typeClasses[t.type],
            )}
          >
            {t.message}
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast deve ser usado dentro de ToastProvider');
  return ctx;
}

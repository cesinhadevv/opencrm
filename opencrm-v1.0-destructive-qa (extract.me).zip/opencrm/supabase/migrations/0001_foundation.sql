-- =============================================================================
-- OpenCRM — Migration 0001: Fundação (Módulo 0)
-- Materializa: ADR-004 (colunas-padrão, soft delete, IDs), ADR-005 (RLS),
--              DR-A3 (fuso IANA no Profile), DR-B1 (unicidade sobre ativos via
--              índice parcial), DR-B6 (PipelineStage com ID estável e arquivamento),
--              Ambiguidade 1 + M2 (owner_configs como mecanismo único de config).
--
-- Convenções (Freeze C1): snake_case, tabelas no plural, PK "id",
--   FKs "{entidade}_id", colunas-padrão em toda tabela.
-- IDs: gerados pela aplicação (UUIDv7 ou equivalente — DR-A2). O DEFAULT abaixo
--   (gen_random_uuid / v4) é apenas rede de segurança; a identidade canônica é o
--   id fornecido pela aplicação. ADR-012: id interno é a única identidade.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- profiles — estende o usuário de auth (Supabase auth.users). Owner de tudo.
-- -----------------------------------------------------------------------------
create table if not exists public.profiles (
  id            uuid primary key references auth.users (id) on delete cascade,
  display_name  text not null,
  email         text not null,
  -- DR-A3: fuso IANA do usuário; todo cálculo de "dia" usa este valor no servidor.
  time_zone     text not null default 'America/Sao_Paulo',
  -- Sistema de temas (Tech Spec C.1): 'system' | 'light' | 'dark'.
  theme         text not null default 'system' check (theme in ('system', 'light', 'dark')),
  -- Onboarding (Tech Spec A.8): marca de conclusão.
  onboarded     boolean not null default false,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  deleted_at    timestamptz
);

-- -----------------------------------------------------------------------------
-- owner_configs — mecanismo ÚNICO de configuração do owner (Ambiguidade 1 + M2).
-- Estrutura chave-valor por namespace. Guarda PARÂMETROS (valores), nunca
-- entidades com ciclo de vida próprio (M2). Ex.: thresholds, pesos, faixas
-- (quando seus módulos chegarem) — todos pelo mesmo mecanismo.
-- -----------------------------------------------------------------------------
create table if not exists public.owner_configs (
  id          uuid primary key default gen_random_uuid(),
  owner_id    uuid not null references public.profiles (id) on delete cascade,
  namespace   text not null,            -- ex.: 'onboarding', 'score', 'pipeline'
  key         text not null,            -- ex.: 'channels', 'weights', 'thresholds'
  value       jsonb not null,           -- valor estruturado do parâmetro
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  deleted_at  timestamptz
);

-- DR-B1: unicidade considera apenas registros ativos (índice parcial).
-- Uma (owner, namespace, key) ativa é única; arquivados não bloqueiam.
create unique index if not exists owner_configs_unique_active
  on public.owner_configs (owner_id, namespace, key)
  where deleted_at is null;

create index if not exists owner_configs_owner_idx
  on public.owner_configs (owner_id)
  where deleted_at is null;

-- -----------------------------------------------------------------------------
-- pipeline_stages — entidade do owner com ID estável (DR-B6). Deal referencia o
-- id (módulo futuro). Nunca excluída fisicamente: arquivamento preserva
-- archived_at/active/order. "active" + "archived_at" = padrão soft delete
-- aplicado à configuração (simetria registrada no DR-B6).
-- -----------------------------------------------------------------------------
create table if not exists public.pipeline_stages (
  id                  uuid primary key default gen_random_uuid(),
  owner_id            uuid not null references public.profiles (id) on delete cascade,
  name                text not null,
  position            integer not null,        -- "order" é palavra reservada; usar "position"
  -- DR-E4: probabilidade default por estágio (0-100). Override manual vive no Deal (futuro).
  default_probability integer not null default 0
                        check (default_probability between 0 and 100),
  active              boolean not null default true,
  archived_at         timestamptz,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  deleted_at          timestamptz
);

create index if not exists pipeline_stages_owner_idx
  on public.pipeline_stages (owner_id)
  where deleted_at is null;

-- -----------------------------------------------------------------------------
-- channels — canais de prospecção do owner (Tech Spec A.8). Tipo + se está ativo.
-- (Identificadores de canal por Account/Contact pertencem ao Módulo 1.)
-- -----------------------------------------------------------------------------
create table if not exists public.channels (
  id          uuid primary key default gen_random_uuid(),
  owner_id    uuid not null references public.profiles (id) on delete cascade,
  -- 'whatsapp' | 'instagram' | 'linkedin' | 'email' | 'phone'
  type        text not null check (type in ('whatsapp', 'instagram', 'linkedin', 'email', 'phone')),
  enabled     boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  deleted_at  timestamptz
);

-- DR-B1: um tipo de canal ativo por owner é único; arquivados não bloqueiam.
create unique index if not exists channels_unique_active
  on public.channels (owner_id, type)
  where deleted_at is null;

-- -----------------------------------------------------------------------------
-- updated_at automático
-- -----------------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger profiles_set_updated_at
  before update on public.profiles
  for each row execute function public.set_updated_at();

create trigger owner_configs_set_updated_at
  before update on public.owner_configs
  for each row execute function public.set_updated_at();

create trigger pipeline_stages_set_updated_at
  before update on public.pipeline_stages
  for each row execute function public.set_updated_at();

create trigger channels_set_updated_at
  before update on public.channels
  for each row execute function public.set_updated_at();

-- =============================================================================
-- OpenCRM — Migration 0002: Row Level Security (Módulo 0)
-- Materializa ADR-005: isolamento por owner desde o dia 1, defesa em profundidade.
-- Princípio: a RLS é a linha final de defesa, independente da camada de aplicação.
-- A RLS é ortogonal ao soft delete (DR-B1): protege "de quem"; o filtro de
-- soft delete (deleted_at) é aplicado pela camada de acesso, não pela RLS.
-- =============================================================================

alter table public.profiles        enable row level security;
alter table public.owner_configs   enable row level security;
alter table public.pipeline_stages enable row level security;
alter table public.channels        enable row level security;

-- -----------------------------------------------------------------------------
-- profiles: o usuário só acessa o próprio profile (id == auth.uid()).
-- -----------------------------------------------------------------------------
create policy profiles_select_own on public.profiles
  for select using (id = auth.uid());

create policy profiles_insert_own on public.profiles
  for insert with check (id = auth.uid());

create policy profiles_update_own on public.profiles
  for update using (id = auth.uid()) with check (id = auth.uid());

-- -----------------------------------------------------------------------------
-- owner_configs / pipeline_stages / channels: owner_id == auth.uid().
-- Mesmo padrão para as três (consistência — Princípio 1).
-- -----------------------------------------------------------------------------
create policy owner_configs_all_own on public.owner_configs
  for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy pipeline_stages_all_own on public.pipeline_stages
  for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy channels_all_own on public.channels
  for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());

-- -----------------------------------------------------------------------------
-- Provisionamento atômico de Profile no signup (mitiga risco de conta órfã —
-- Tech Spec A.2 / Riscos R3). Trigger em auth.users cria o profile na mesma
-- transação do cadastro. display_name e email vêm dos metadados do signup.
-- -----------------------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, display_name, email)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'display_name', split_part(new.email, '@', 1)),
    new.email
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

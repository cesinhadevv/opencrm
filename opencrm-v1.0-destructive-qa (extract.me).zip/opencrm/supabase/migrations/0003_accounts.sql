-- =============================================================================
-- OpenCRM — Migration 0003: Empresas & Contatos (Módulo 1)
-- ADR-004 (colunas-padrão, soft delete, IDs), DR-A1 (Account central, sem Contact
-- obrigatório), DR-C2 (canônico/exibição), DR-B1 (unicidade ativa via índice
-- parcial), ADR-012 (id interno = identidade; canais são atributos).
-- =============================================================================

-- accounts — empresa (entidade central). Pode existir sem contacts (DR-A1).
create table if not exists public.accounts (
  id          uuid primary key default gen_random_uuid(),
  owner_id    uuid not null references public.profiles (id) on delete cascade,
  name        text not null,
  segment     text,
  origin      text,
  tags        text[] not null default '{}',
  notes       text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  deleted_at  timestamptz
);

create index if not exists accounts_owner_idx
  on public.accounts (owner_id)
  where deleted_at is null;

-- contacts — pessoa. Pertence a uma account (DR-A1).
create table if not exists public.contacts (
  id          uuid primary key default gen_random_uuid(),
  owner_id    uuid not null references public.profiles (id) on delete cascade,
  account_id  uuid not null references public.accounts (id) on delete cascade,
  name        text not null,
  role        text,
  is_primary  boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  deleted_at  timestamptz
);

create index if not exists contacts_account_idx
  on public.contacts (account_id)
  where deleted_at is null;

create index if not exists contacts_owner_idx
  on public.contacts (owner_id)
  where deleted_at is null;

-- contact_channels — identificador de canal de uma account OU de um contact.
-- canonical (busca/dedupe/unicidade — DR-C2) + display (UI). Exatamente um dono.
create table if not exists public.contact_channels (
  id          uuid primary key default gen_random_uuid(),
  owner_id    uuid not null references public.profiles (id) on delete cascade,
  account_id  uuid references public.accounts (id) on delete cascade,
  contact_id  uuid references public.contacts (id) on delete cascade,
  type        text not null check (type in ('whatsapp', 'instagram', 'linkedin', 'email', 'phone')),
  canonical   text not null,
  display     text not null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  deleted_at  timestamptz,
  constraint contact_channels_one_owner
    check (num_nonnulls(account_id, contact_id) = 1)
);

create index if not exists contact_channels_account_idx
  on public.contact_channels (account_id)
  where deleted_at is null;

create index if not exists contact_channels_contact_idx
  on public.contact_channels (contact_id)
  where deleted_at is null;

-- DR-B1: dedupe por valor canônico ativo por owner+tipo (índice parcial).
create unique index if not exists contact_channels_unique_active
  on public.contact_channels (owner_id, type, canonical)
  where deleted_at is null;

-- updated_at triggers
create trigger accounts_set_updated_at
  before update on public.accounts
  for each row execute function public.set_updated_at();

create trigger contacts_set_updated_at
  before update on public.contacts
  for each row execute function public.set_updated_at();

create trigger contact_channels_set_updated_at
  before update on public.contact_channels
  for each row execute function public.set_updated_at();

-- RLS por owner (ADR-005)
alter table public.accounts         enable row level security;
alter table public.contacts         enable row level security;
alter table public.contact_channels enable row level security;

create policy accounts_all_own on public.accounts
  for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy contacts_all_own on public.contacts
  for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy contact_channels_all_own on public.contact_channels
  for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());

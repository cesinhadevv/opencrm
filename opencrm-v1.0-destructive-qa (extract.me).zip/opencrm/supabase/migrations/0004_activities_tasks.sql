-- =============================================================================
-- OpenCRM — Migration 0004: Atividades & Follow-ups (Módulo 2)
-- DR-B4 (direction/source em Activity), DR-A3 (UTC), ADR-004 (colunas-padrão/
-- soft delete), ADR-005 (RLS), ADR-012 (id interno).
-- Activity = passado imutável; Task = futuro. Tabelas distintas.
-- =============================================================================

-- activities — registro imutável de interação (passado).
create table if not exists public.activities (
  id          uuid primary key default gen_random_uuid(),
  owner_id    uuid not null references public.profiles (id) on delete cascade,
  account_id  uuid not null references public.accounts (id) on delete cascade,
  contact_id  uuid references public.contacts (id) on delete set null,
  deal_id     uuid, -- FK adicionada no Módulo 3 (deals ainda não existe)
  channel     text check (channel in ('whatsapp', 'instagram', 'linkedin', 'email', 'phone')),
  -- DR-B4: direção e fonte.
  direction   text not null check (direction in ('outbound', 'inbound', 'internal_note')),
  source      text not null default 'manual' check (source in ('manual', 'imported')),
  content     text not null,
  occurred_at timestamptz not null default now(),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  deleted_at  timestamptz
);

-- Índices para timeline e cálculo temporal (alto volume — ADR-004/006).
create index if not exists activities_account_occurred_idx
  on public.activities (account_id, occurred_at desc)
  where deleted_at is null;

create index if not exists activities_owner_idx
  on public.activities (owner_id)
  where deleted_at is null;

-- tasks — follow-up futuro.
create table if not exists public.tasks (
  id          uuid primary key default gen_random_uuid(),
  owner_id    uuid not null references public.profiles (id) on delete cascade,
  account_id  uuid not null references public.accounts (id) on delete cascade,
  deal_id     uuid, -- FK adicionada no Módulo 3
  title       text not null,
  due_at      timestamptz not null,
  status      text not null default 'open' check (status in ('open', 'done')),
  priority    integer not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  deleted_at  timestamptz
);

-- Índice base do Cockpit/Agenda (owner + due_at, abertas) — ADR-004/006.
create index if not exists tasks_owner_due_open_idx
  on public.tasks (owner_id, due_at)
  where deleted_at is null and status = 'open';

create index if not exists tasks_account_idx
  on public.tasks (account_id)
  where deleted_at is null;

-- updated_at triggers
create trigger activities_set_updated_at
  before update on public.activities
  for each row execute function public.set_updated_at();

create trigger tasks_set_updated_at
  before update on public.tasks
  for each row execute function public.set_updated_at();

-- RLS por owner
alter table public.activities enable row level security;
alter table public.tasks      enable row level security;

create policy activities_all_own on public.activities
  for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy tasks_all_own on public.tasks
  for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());

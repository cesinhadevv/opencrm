-- =============================================================================
-- OpenCRM — Migration 0005: Pipeline / Deals (Módulo 3)
-- DR-B2 (status open/won/lost separado de stage), DR-E4 (probabilidade
-- default+override), DR-B6 (stage por ID estável), RN-07 (lost exige motivo),
-- ADR-004 (colunas-padrão/soft delete), ADR-005 (RLS), ADR-012 (id interno).
-- Adiciona as FKs reais de deal_id em activities e tasks (decisão registrada no M2).
-- =============================================================================

-- deals
create table if not exists public.deals (
  id                     uuid primary key default gen_random_uuid(),
  owner_id               uuid not null references public.profiles (id) on delete cascade,
  account_id             uuid not null references public.accounts (id) on delete cascade,
  primary_contact_id     uuid references public.contacts (id) on delete set null,
  title                  text not null,
  value                  bigint not null default 0,  -- centavos (inteiro)
  -- DR-B2: status independente de stage.
  status                 text not null default 'open'
                           check (status in ('open', 'won', 'lost')),
  stage_id               uuid references public.pipeline_stages (id) on delete restrict,
  -- DR-E4: probabilidade efetiva + flag de override manual.
  probability            integer not null default 0 check (probability between 0 and 100),
  probability_overridden boolean not null default false,
  expected_close_at      timestamptz,
  -- RN-07: motivo obrigatório quando lost (validado por constraint).
  lost_reason            text,
  won_at                 timestamptz,
  lost_at                timestamptz,
  created_at             timestamptz not null default now(),
  updated_at             timestamptz not null default now(),
  deleted_at             timestamptz,
  -- RN-07: lost <-> lost_reason presente; won <-> won_at; open sem desfecho.
  constraint deals_status_consistency check (
    (status = 'open'  and won_at is null and lost_at is null and lost_reason is null) or
    (status = 'won'   and won_at is not null and lost_at is null) or
    (status = 'lost'  and lost_at is not null and lost_reason is not null and won_at is null)
  )
);

create index if not exists deals_owner_open_idx
  on public.deals (owner_id, stage_id)
  where deleted_at is null and status = 'open';

create index if not exists deals_account_idx
  on public.deals (account_id)
  where deleted_at is null;

create trigger deals_set_updated_at
  before update on public.deals
  for each row execute function public.set_updated_at();

alter table public.deals enable row level security;

create policy deals_all_own on public.deals
  for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());

-- FKs reais de deal_id (decisão registrada no Módulo 2: criadas aqui).
-- Idempotente: só adiciona se ainda não existir (permite re-execução segura).
do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'activities_deal_fk'
  ) then
    alter table public.activities
      add constraint activities_deal_fk
      foreign key (deal_id) references public.deals (id) on delete set null;
  end if;

  if not exists (
    select 1 from pg_constraint where conname = 'tasks_deal_fk'
  ) then
    alter table public.tasks
      add constraint tasks_deal_fk
      foreign key (deal_id) references public.deals (id) on delete set null;
  end if;
end $$;

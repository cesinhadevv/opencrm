-- =============================================================================
-- OpenCRM — Migration 0006: Propostas (Módulo 5)
-- RN-03/04/05, ADR-004 (colunas-padrão/soft delete), ADR-005 (RLS),
-- ADR-012 (id interno). Proposal vinculada a Deal.
-- =============================================================================

create table if not exists public.proposals (
  id           uuid primary key default gen_random_uuid(),
  owner_id     uuid not null references public.profiles (id) on delete cascade,
  deal_id      uuid not null references public.deals (id) on delete cascade,
  value        bigint not null default 0,  -- centavos
  status       text not null default 'draft'
                 check (status in ('draft', 'sent', 'accepted', 'rejected', 'expired')),
  sent_at      timestamptz,
  valid_until  timestamptz,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  deleted_at   timestamptz
);

create index if not exists proposals_deal_idx
  on public.proposals (deal_id)
  where deleted_at is null;

create index if not exists proposals_owner_idx
  on public.proposals (owner_id)
  where deleted_at is null;

-- Índice para varredura de "vencendo" (status sent + valid_until) — RN-04.
create index if not exists proposals_owner_sent_valid_idx
  on public.proposals (owner_id, valid_until)
  where deleted_at is null and status = 'sent';

create trigger proposals_set_updated_at
  before update on public.proposals
  for each row execute function public.set_updated_at();

alter table public.proposals enable row level security;

create policy proposals_all_own on public.proposals
  for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());

-- =============================================================================
-- OpenCRM — Migration 0007: Pós-venda (Módulo 8)
-- PRD Módulo 8 / RN-06. ADR-004 (colunas-padrão/soft delete), ADR-005 (RLS),
-- ADR-012 (id interno). Registros de acompanhamento de pós-venda vinculados a
-- Deal (won) e Account.
-- Clientes em pós-venda derivam de deals.status='won' (não há tabela própria de
-- "cliente pós-venda": é uma visão dos Deals won — evita duplicação de entidade).
-- =============================================================================

create table if not exists public.aftersale_records (
  id                  uuid primary key default gen_random_uuid(),
  owner_id            uuid not null references public.profiles (id) on delete cascade,
  account_id          uuid not null references public.accounts (id) on delete cascade,
  deal_id             uuid not null references public.deals (id) on delete cascade,
  type                text not null
                        check (type in ('follow_up', 'satisfaction', 'upsell', 'referral')),
  content             text not null default '',
  satisfaction_score  integer check (satisfaction_score between 0 and 10),
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  deleted_at          timestamptz
);

create index if not exists aftersale_records_deal_idx
  on public.aftersale_records (deal_id)
  where deleted_at is null;

create index if not exists aftersale_records_owner_idx
  on public.aftersale_records (owner_id)
  where deleted_at is null;

create trigger aftersale_records_set_updated_at
  before update on public.aftersale_records
  for each row execute function public.set_updated_at();

alter table public.aftersale_records enable row level security;

create policy aftersale_records_all_own on public.aftersale_records
  for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());

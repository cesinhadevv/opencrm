-- =============================================================================
-- OpenCRM — Migration 0008: Hardening V1.0
-- C2: operações compostas atômicas via RPC (transação implícita da função).
-- M3: unicidade de canal deixa de ser global por owner (dedupe vira sugestão).
-- Segurança: RPCs derivam o owner de auth.uid(), não confiam em parâmetro do cliente.
-- =============================================================================

-- M3: troca do índice único por índice de busca (não-único).
drop index if exists public.contact_channels_unique_active;

create index if not exists contact_channels_lookup_idx
  on public.contact_channels (owner_id, type, canonical)
  where deleted_at is null;

-- C2: criar account + canais atomicamente. Owner via auth.uid() (segurança).
create or replace function public.create_account_with_channels(
  p_account_id uuid,
  p_name text,
  p_segment text,
  p_origin text,
  p_channels jsonb
)
returns void
language plpgsql
security invoker
set search_path = public
as $$
declare
  ch jsonb;
  v_owner uuid := auth.uid();
begin
  if v_owner is null then
    raise exception 'not authenticated';
  end if;

  insert into public.accounts (id, owner_id, name, segment, origin)
  values (p_account_id, v_owner, p_name, p_segment, p_origin);

  if p_channels is not null then
    for ch in select * from jsonb_array_elements(p_channels)
    loop
      insert into public.contact_channels
        (id, owner_id, account_id, type, canonical, display)
      values (
        (ch ->> 'id')::uuid,
        v_owner,
        p_account_id,
        ch ->> 'type',
        ch ->> 'canonical',
        ch ->> 'display'
      );
    end loop;
  end if;
end;
$$;

-- C2: fechar deal WON + task de pós-venda atomicamente (RN-06).
-- Owner via auth.uid(); só fecha deal OPEN; task só se o deal foi fechado agora.
create or replace function public.close_deal_won_with_task(
  p_deal_id uuid,
  p_account_id uuid,
  p_task_id uuid,
  p_won_at timestamptz,
  p_task_title text,
  p_task_due_at timestamptz
)
returns void
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_owner uuid := auth.uid();
  v_updated integer;
begin
  if v_owner is null then
    raise exception 'not authenticated';
  end if;

  update public.deals
     set status = 'won', won_at = p_won_at, lost_at = null, lost_reason = null
   where id = p_deal_id
     and owner_id = v_owner
     and deleted_at is null
     and status = 'open';

  get diagnostics v_updated = row_count;
  if v_updated = 1 then
    insert into public.tasks (id, owner_id, account_id, deal_id, title, due_at, priority)
    values (p_task_id, v_owner, p_account_id, p_deal_id, p_task_title, p_task_due_at, 0);
  end if;
end;
$$;

-- Grants: PostgREST executa RPCs com o role do chamador (authenticated/anon).
-- Sem EXECUTE para authenticated, supabase.rpc() retorna "permission denied".
-- security invoker garante que a RLS continua valendo dentro da função.
grant execute on function public.create_account_with_channels(uuid, text, text, text, jsonb)
  to authenticated;
grant execute on function public.close_deal_won_with_task(uuid, uuid, uuid, timestamptz, text, timestamptz)
  to authenticated;

import type { Config } from 'tailwindcss';

/**
 * Tailwind — mapeia os design tokens (globals.css) para utilitários.
 * Breakpoints (Freeze D5): três faixas. Transição sidebar<->tab bar na fronteira
 * estreita/intermediária (md). Valores vivem aqui (tokens), nunca hardcoded.
 */
const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    screens: {
      // mobile: padrão (< md); tab bar inferior, layout empilhado
      md: '768px', // tablet — fronteira onde sidebar substitui tab bar
      lg: '1024px', // desktop — layout multicoluna
    },
    extend: {
      colors: {
        ink: 'var(--color-ink)',
        canvas: 'var(--color-canvas)',
        brand: 'var(--color-brand)',
        attention: 'var(--color-attention)',
        urgent: 'var(--color-urgent)',
        success: 'var(--color-success)',
        surface: 'var(--color-surface)',
        border: 'var(--color-border)',
        neutral: {
          50: 'var(--color-neutral-50)',
          100: 'var(--color-neutral-100)',
          200: 'var(--color-neutral-200)',
          300: 'var(--color-neutral-300)',
          400: 'var(--color-neutral-400)',
          500: 'var(--color-neutral-500)',
          600: 'var(--color-neutral-600)',
          700: 'var(--color-neutral-700)',
          800: 'var(--color-neutral-800)',
          900: 'var(--color-neutral-900)',
        },
      },
      fontFamily: { sans: 'var(--font-sans)' },
      borderRadius: {
        button: 'var(--radius-button)',
        card: 'var(--radius-card)',
        container: 'var(--radius-container)',
      },
      boxShadow: {
        card: 'var(--shadow-card)',
        overlay: 'var(--shadow-overlay)',
      },
      transitionTimingFunction: { 'ease-out-soft': 'var(--ease-out)' },
      transitionDuration: { fast: '120ms', base: '180ms' },
    },
  },
  plugins: [],
};

export default config;

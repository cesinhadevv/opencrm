import { test, expect } from '@playwright/test';
import { login, logout, USER_A } from './helpers';

test.describe('Autenticação (F1, F2)', () => {
  test('login com credenciais válidas entra no app', async ({ page }) => {
    await login(page, USER_A);
    await expect(page).toHaveURL(/\/(|$)/);
  });

  test('login com senha errada mostra erro neutro', async ({ page }) => {
    await page.goto('/login');
    await page.getByLabel('E-mail').fill(USER_A.email);
    await page.getByLabel('Senha').fill('senha-errada-xyz');
    await page.getByRole('button', { name: 'Entrar' }).click();
    await expect(page.getByText(/E-mail ou senha incorretos/i)).toBeVisible();
  });

  test('logout encerra a sessão', async ({ page }) => {
    await login(page, USER_A);
    await logout(page);
    await expect(page).toHaveURL(/\/login/);
  });

  test('rota protegida sem sessão redireciona para login', async ({ page }) => {
    await page.goto('/empresas');
    await expect(page).toHaveURL(/\/login/);
  });

  test('recuperar senha mostra confirmação neutra', async ({ page }) => {
    await page.goto('/recuperar-senha');
    await page.getByLabel('E-mail').fill('qualquer@example.com');
    await page.getByRole('button', { name: /Enviar/ }).click();
    await expect(page.getByText(/Se houver uma conta/i)).toBeVisible();
  });
});

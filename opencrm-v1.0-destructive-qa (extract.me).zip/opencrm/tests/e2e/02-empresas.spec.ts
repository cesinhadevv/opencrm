import { test, expect } from '@playwright/test';
import { login, USER_A, uniqueSuffix } from './helpers';

test.describe('Empresas e Contatos (F5, F6)', () => {
  test.beforeEach(async ({ page }) => {
    await login(page, USER_A);
  });

  test('criar empresa com canais (RPC create_account_with_channels)', async ({ page }) => {
    const nome = `Loja Teste ${uniqueSuffix()}`;
    await page.goto('/empresas');
    await page.getByRole('button', { name: 'Nova empresa' }).click();
    await page.getByLabel('Nome da empresa').fill(nome);
    await page.getByLabel('Segmento').fill('Varejo');
    // canais opcionais: preenche WhatsApp
    await page.getByPlaceholder('WhatsApp').fill('(11) 99999-0000');
    await page.getByRole('button', { name: /Criar empresa/ }).click();
    // empresa aparece na lista ou abre o perfil
    await expect(page.getByText(nome)).toBeVisible({ timeout: 15000 });
  });

  test('empresa criada aparece na listagem', async ({ page }) => {
    const nome = `Empresa List ${uniqueSuffix()}`;
    await page.goto('/empresas');
    await page.getByRole('button', { name: 'Nova empresa' }).click();
    await page.getByLabel('Nome da empresa').fill(nome);
    await page.getByRole('button', { name: /Criar empresa/ }).click();
    await page.goto('/empresas');
    await expect(page.getByText(nome)).toBeVisible();
  });

  test('adicionar contato a uma empresa', async ({ page }) => {
    const nome = `Empresa Contato ${uniqueSuffix()}`;
    await page.goto('/empresas');
    await page.getByRole('button', { name: 'Nova empresa' }).click();
    await page.getByLabel('Nome da empresa').fill(nome);
    await page.getByRole('button', { name: /Criar empresa/ }).click();
    await page.getByText(nome).click();
    await page.getByRole('button', { name: 'Adicionar contato' }).click();
    await page.getByLabel('Nome').fill('João Comprador');
    await page.getByRole('button', { name: /Salvar contato/ }).click();
    await expect(page.getByText('Contato adicionado')).toBeVisible({ timeout: 10000 });
  });
});

import { test, expect } from '@playwright/test';
import { login, USER_A, uniqueSuffix } from './helpers';

test.describe('Pipeline (F7)', () => {
  test.beforeEach(async ({ page }) => {
    await login(page, USER_A);
  });

  test('criar oportunidade a partir do perfil da empresa', async ({ page }) => {
    const nome = `Empresa Deal ${uniqueSuffix()}`;
    await page.goto('/empresas');
    await page.getByRole('button', { name: 'Nova empresa' }).click();
    await page.getByLabel('Nome da empresa').fill(nome);
    await page.getByRole('button', { name: /Criar empresa/ }).click();
    await page.getByText(nome).click();
    // Form de oportunidade no perfil
    await page.getByLabel('Título').fill('Projeto Piloto');
    await page.getByLabel('Valor (R$)').fill('8000');
    await page.getByRole('button', { name: /Criar oportunidade/ }).click();
    await expect(page.getByText('Oportunidade criada')).toBeVisible({ timeout: 10000 });
  });

  test('pipeline mostra o kanban com estágios', async ({ page }) => {
    await page.goto('/pipeline');
    await expect(page.getByRole('heading', { name: 'Pipeline' })).toBeVisible();
    // estágios default do onboarding
    await expect(page.getByText('Prospecção')).toBeVisible();
  });
});

import { test, expect } from '@playwright/test';
import { login, USER_A, uniqueSuffix } from './helpers';

test.describe('Atividades e Follow-up (F8)', () => {
  test.beforeEach(async ({ page }) => {
    await login(page, USER_A);
  });

  async function criarEmpresa(page: import('@playwright/test').Page) {
    const nome = `Emp Ativ ${uniqueSuffix()}`;
    await page.goto('/empresas');
    await page.getByRole('button', { name: 'Nova empresa' }).click();
    await page.getByLabel('Nome da empresa').fill(nome);
    await page.getByRole('button', { name: /Criar empresa/ }).click();
    await page.getByText(nome).click();
    return nome;
  }

  test('registrar interação outbound aparece na timeline', async ({ page }) => {
    await criarEmpresa(page);
    await page.getByRole('button', { name: /Registrar interação/ }).click();
    await page.getByLabel('Conteúdo').fill('Liguei para apresentar a proposta');
    await page.getByRole('button', { name: /Salvar/ }).click();
    await expect(page.getByText('Liguei para apresentar a proposta')).toBeVisible({
      timeout: 10000,
    });
  });

  test('criar follow-up gera tarefa', async ({ page }) => {
    await criarEmpresa(page);
    await page.getByRole('button', { name: /Criar follow-up/ }).click();
    await page.getByLabel('Título').fill('Retornar ligação');
    await page.getByRole('button', { name: /Agendar/ }).click();
    await expect(page.getByText('Retornar ligação')).toBeVisible({ timeout: 10000 });
  });
});

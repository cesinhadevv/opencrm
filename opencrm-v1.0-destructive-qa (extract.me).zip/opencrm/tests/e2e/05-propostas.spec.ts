import { test, expect } from '@playwright/test';
import { login, USER_A, uniqueSuffix } from './helpers';

test.describe('Propostas (F9)', () => {
  test.beforeEach(async ({ page }) => {
    await login(page, USER_A);
  });

  test('aceitar proposta SUGERE ganhar (não executa Won automaticamente — RN-05)', async ({
    page,
  }) => {
    // pré: criar empresa + deal + proposta
    const nome = `Emp Prop ${uniqueSuffix()}`;
    await page.goto('/empresas');
    await page.getByRole('button', { name: 'Nova empresa' }).click();
    await page.getByLabel('Nome da empresa').fill(nome);
    await page.getByRole('button', { name: /Criar empresa/ }).click();
    await page.getByText(nome).click();
    await page.getByLabel('Título').fill('Deal Proposta');
    await page.getByLabel('Valor (R$)').fill('5000');
    await page.getByRole('button', { name: /Criar oportunidade/ }).click();
    // criar proposta no deal
    await page.getByRole('button', { name: /Nova proposta/ }).click();
    await page.getByLabel('Valor (R$)').last().fill('5000');
    await page.getByRole('button', { name: /Criar proposta/ }).click();
    // enviar
    await page.getByRole('button', { name: /Enviar/ }).click();
    // aceitar
    await page.getByRole('button', { name: /Aceitar/ }).click();
    // ESPERADO: sugestão de ganhar, deal ainda NÃO está won
    await expect(page.getByText(/Marcar como ganho|Sugest/i)).toBeVisible({ timeout: 10000 });
  });
});

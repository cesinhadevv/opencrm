import { test, expect } from '@playwright/test';
import { login, USER_A, uniqueSuffix } from './helpers';

test.describe('Pós-venda (F10, F11)', () => {
  test.beforeEach(async ({ page }) => {
    await login(page, USER_A);
  });

  test('ganhar deal cria tarefa de pós-venda (RPC close_deal_won_with_task)', async ({ page }) => {
    const nome = `Emp Won ${uniqueSuffix()}`;
    await page.goto('/empresas');
    await page.getByRole('button', { name: 'Nova empresa' }).click();
    await page.getByLabel('Nome da empresa').fill(nome);
    await page.getByRole('button', { name: /Criar empresa/ }).click();
    await page.getByText(nome).click();
    await page.getByLabel('Título').fill('Deal Ganho');
    await page.getByLabel('Valor (R$)').fill('12000');
    await page.getByRole('button', { name: /Criar oportunidade/ }).click();
    await page.getByRole('button', { name: /Ganhar|Marcar como ganho/ }).click();
    await expect(page.getByText(/ganho|pós-venda/i)).toBeVisible({ timeout: 10000 });
  });

  test('marcos de pós-venda são idempotentes (2ª geração não duplica)', async ({ page }) => {
    await page.goto('/pos-venda');
    const card = page.locator('[data-testid="aftersale-customer"]').first();
    if (await card.count()) {
      await card.click();
      await page.getByRole('button', { name: /Gerar marcos/ }).click();
      await expect(page.getByText(/marcos|gerad/i)).toBeVisible({ timeout: 10000 });
      // segunda geração: não deve duplicar (mensagem de já gerado ou contagem estável)
      await page.getByRole('button', { name: /Gerar marcos/ }).click();
    }
  });
});

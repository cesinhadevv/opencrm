import { test, expect } from '@playwright/test';
import { login, USER_A } from './helpers';

test.describe('Cockpit / Hoje (F12)', () => {
  test.beforeEach(async ({ page }) => {
    await login(page, USER_A);
  });

  test('cockpit exibe as faixas temporais de tarefas', async ({ page }) => {
    await page.goto('/');
    // faixas DR-A3
    await expect(page.getByText(/Atrasadas|Hoje|Esta semana|Próximas/)).toBeVisible({
      timeout: 15000,
    });
  });

  test('cockpit exibe resumo com total de pipeline', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByText(/pipeline|R\$/i)).toBeVisible({ timeout: 15000 });
  });
});

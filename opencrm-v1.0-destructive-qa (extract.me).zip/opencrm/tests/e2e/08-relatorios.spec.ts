import { test, expect } from '@playwright/test';
import { login, USER_A } from './helpers';

test.describe('Relatórios (F13)', () => {
  test.beforeEach(async ({ page }) => {
    await login(page, USER_A);
  });

  test('relatórios carregam métricas', async ({ page }) => {
    await page.goto('/relatorios');
    await expect(page.getByText(/Conversão|Ticket|Funil/i)).toBeVisible({ timeout: 15000 });
  });

  test('alternar período recarrega os dados', async ({ page }) => {
    await page.goto('/relatorios');
    await page.getByRole('button', { name: /Últimos 30 dias|30 dias/ }).click();
    await expect(page).toHaveURL(/period=last_30_days/);
  });
});

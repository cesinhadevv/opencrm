import { test, expect } from '@playwright/test';
import { login, USER_A } from './helpers';

test.describe('Configurações', () => {
  test('página de configurações carrega', async ({ page }) => {
    await login(page, USER_A);
    await page.goto('/configuracoes');
    await expect(page.getByRole('heading', { name: /Configurações/ })).toBeVisible({
      timeout: 15000,
    });
  });

  test('alternar tema (dark mode) persiste', async ({ page }) => {
    await login(page, USER_A);
    await page.goto('/configuracoes');
    const toggle = page.getByRole('button', { name: /tema|Tema|escuro|claro/ }).first();
    if (await toggle.count()) {
      await toggle.click();
      // html ganha data-theme
      await expect(page.locator('html')).toHaveAttribute('data-theme', /dark|light/);
    }
  });
});

import { test, expect } from '@playwright/test';
import { login, USER_A, USER_B, uniqueSuffix } from './helpers';

test.describe('Isolamento cross-tenant (F14 — CRÍTICO)', () => {
  test('userB não acessa empresa criada por userA via URL direta', async ({ page }) => {
    // userA cria empresa e capturamos a URL do perfil
    await login(page, USER_A);
    const nome = `Privada A ${uniqueSuffix()}`;
    await page.goto('/empresas');
    await page.getByRole('button', { name: 'Nova empresa' }).click();
    await page.getByLabel('Nome da empresa').fill(nome);
    await page.getByRole('button', { name: /Criar empresa/ }).click();
    await page.getByText(nome).click();
    await expect(page).toHaveURL(/\/empresas\/[0-9a-f-]+/);
    const urlPrivada = page.url();

    // logout A, login B
    await page.getByRole('button', { name: 'Sair' }).click();
    await expect(page).toHaveURL(/\/login/);
    await login(page, USER_B);

    // userB tenta acessar a URL privada de A
    await page.goto(urlPrivada);
    // ESPERADO: não vê o nome da empresa de A (RLS bloqueia → notFound ou vazio)
    await expect(page.getByText(nome)).not.toBeVisible();
  });
});

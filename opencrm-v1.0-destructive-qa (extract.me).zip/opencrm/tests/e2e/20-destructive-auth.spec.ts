import { test, expect } from '@playwright/test';
import { login, USER_A } from './helpers';

test.describe('Destructive — Auth', () => {
  test('A-02: senha incorreta dá mensagem neutra (anti-enumeração)', async ({ page }) => {
    await page.goto('/login');
    await page.getByLabel('E-mail').fill(USER_A.email);
    await page.getByLabel('Senha').fill('errada-de-proposito');
    await page.getByRole('button', { name: 'Entrar' }).click();
    const msg = page.getByText(/E-mail ou senha incorretos/i);
    await expect(msg).toBeVisible();
    // não deve revelar "usuário não encontrado" vs "senha errada"
    await expect(page.getByText(/não encontrado|não existe|usuário inválido/i)).toHaveCount(0);
  });

  test('A-03: e-mail malformado é barrado pela validação', async ({ page }) => {
    await page.goto('/login');
    await page.getByLabel('E-mail').fill('abc');
    await page.getByLabel('Senha').fill('x');
    await page.getByRole('button', { name: 'Entrar' }).click();
    // permanece em login (validação barra antes de autenticar)
    await expect(page).toHaveURL(/\/login/);
  });

  test('A-06: rota protegida sem sessão redireciona', async ({ page }) => {
    for (const route of ['/empresas', '/pipeline', '/relatorios', '/pos-venda', '/configuracoes']) {
      await page.goto(route);
      await expect(page).toHaveURL(/\/login/);
    }
  });

  test('R-05: recuperação para e-mail inexistente dá resposta neutra', async ({ page }) => {
    await page.goto('/recuperar-senha');
    await page.getByLabel('E-mail').fill(`naoexiste-${Date.now()}@nowhere.dev`);
    await page.getByRole('button', { name: /Enviar/ }).click();
    await expect(page.getByText(/Se houver uma conta/i)).toBeVisible();
  });

  test('R-03: senhas divergentes na redefinição são rejeitadas', async ({ page }) => {
    // acesso direto à página (sem token real, valida só a validação client)
    await page.goto('/redefinir-senha');
    const pwd = page.getByLabel('Nova senha');
    if (await pwd.count()) {
      await pwd.fill('senhaA12345');
      await page.getByLabel('Confirmar senha').fill('senhaB12345');
      await page.getByRole('button', { name: /Redefinir/ }).click();
      await expect(page.getByText(/não coincidem|conferem|iguais/i)).toBeVisible();
    }
  });
});

import { test, expect } from '@playwright/test';
import { login, USER_A, uniqueSuffix } from './helpers';

test.describe('Destructive — Empresa', () => {
  test.beforeEach(async ({ page }) => {
    await login(page, USER_A);
  });

  test('E-05: nome só com espaços é rejeitado', async ({ page }) => {
    await page.goto('/empresas');
    await page.getByRole('button', { name: 'Nova empresa' }).click();
    await page.getByLabel('Nome da empresa').fill('   ');
    await page.getByRole('button', { name: /Criar empresa/ }).click();
    await expect(page.getByText(/Informe o nome da empresa/i)).toBeVisible();
  });

  test('E-06: XSS no nome é renderizado como texto literal (não executa)', async ({ page }) => {
    const payload = `<img src=x onerror=window.__xss=1>${uniqueSuffix()}`;
    let dialogFired = false;
    page.on('dialog', async (d) => {
      dialogFired = true;
      await d.dismiss();
    });
    await page.goto('/empresas');
    await page.getByRole('button', { name: 'Nova empresa' }).click();
    await page.getByLabel('Nome da empresa').fill(payload);
    await page.getByRole('button', { name: /Criar empresa/ }).click();
    await page.waitForTimeout(1500);
    // o script NÃO deve ter executado
    const xss = await page.evaluate(() => (window as unknown as { __xss?: number }).__xss);
    expect(xss).toBeUndefined();
    expect(dialogFired).toBe(false);
  });

  test('E-04: nome com 161 chars é rejeitado (limite 160)', async ({ page }) => {
    await page.goto('/empresas');
    await page.getByRole('button', { name: 'Nova empresa' }).click();
    await page.getByLabel('Nome da empresa').fill('a'.repeat(161));
    await page.getByRole('button', { name: /Criar empresa/ }).click();
    // validação barra (permanece no form com erro) — não navega para perfil
    await expect(page).not.toHaveURL(/\/empresas\/[0-9a-f-]{36}/);
  });
});

import { test, expect } from '@playwright/test';
import { login, USER_A, uniqueSuffix } from './helpers';

async function novaEmpresaComDeal(page: import('@playwright/test').Page, valor: string) {
  const nome = `Destr ${uniqueSuffix()}`;
  await page.goto('/empresas');
  await page.getByRole('button', { name: 'Nova empresa' }).click();
  await page.getByLabel('Nome da empresa').fill(nome);
  await page.getByRole('button', { name: /Criar empresa/ }).click();
  await page.getByText(nome).click();
  await page.getByLabel('Título').fill('Deal Destrutivo');
  await page.getByLabel('Valor (R$)').fill(valor);
  await page.getByRole('button', { name: /Criar oportunidade/ }).click();
  return nome;
}

test.describe('Destructive — Deal / Fechamento', () => {
  test.beforeEach(async ({ page }) => {
    await login(page, USER_A);
  });

  test('D-02: valor negativo é rejeitado', async ({ page }) => {
    const nome = `Destr ${uniqueSuffix()}`;
    await page.goto('/empresas');
    await page.getByRole('button', { name: 'Nova empresa' }).click();
    await page.getByLabel('Nome da empresa').fill(nome);
    await page.getByRole('button', { name: /Criar empresa/ }).click();
    await page.getByText(nome).click();
    await page.getByLabel('Título').fill('Valor Negativo');
    await page.getByLabel('Valor (R$)').fill('-500');
    await page.getByRole('button', { name: /Criar oportunidade/ }).click();
    // não cria — erro de validação visível
    await expect(page.getByText('Oportunidade criada')).toHaveCount(0);
  });

  test('W-02: fechar deal já ganho é rejeitado (sem duplicar pós-venda)', async ({ page }) => {
    await novaEmpresaComDeal(page, '7000');
    const ganhar = page.getByRole('button', { name: /Ganhar|Marcar como ganho/ }).first();
    await ganhar.click();
    await expect(page.getByText(/ganho|pós-venda/i)).toBeVisible({ timeout: 10000 });
    // tentar ganhar de novo: o botão não deve mais existir, ou a ação deve ser rejeitada
    const aindaTemBotao = await page
      .getByRole('button', { name: /Ganhar|Marcar como ganho/ })
      .count();
    expect(aindaTemBotao).toBe(0);
  });

  test('W-03: duplo clique em Ganhar não cria duas tarefas (idempotência RPC)', async ({
    page,
  }) => {
    await novaEmpresaComDeal(page, '9000');
    const ganhar = page.getByRole('button', { name: /Ganhar|Marcar como ganho/ }).first();
    // duplo clique rápido
    await Promise.all([ganhar.click(), ganhar.click().catch(() => {})]);
    await expect(page.getByText(/ganho|pós-venda/i)).toBeVisible({ timeout: 10000 });
    // verificação de não-duplicação é confirmada via SQL (tests/sql/03 R2b);
    // aqui garantimos que a UI não entrou em estado inconsistente
    await expect(page).toHaveURL(/\/empresas\/[0-9a-f-]+/);
  });
});

import { test, expect } from '@playwright/test';
import { login, logout, USER_A, USER_B, uniqueSuffix } from './helpers';

test.describe('Destructive — Cross-tenant (P0 segurança)', () => {
  test('X-01: userB não acessa empresa de userA por URL direta', async ({ page }) => {
    await login(page, USER_A);
    const nome = `SecretA ${uniqueSuffix()}`;
    await page.goto('/empresas');
    await page.getByRole('button', { name: 'Nova empresa' }).click();
    await page.getByLabel('Nome da empresa').fill(nome);
    await page.getByRole('button', { name: /Criar empresa/ }).click();
    await page.getByText(nome).click();
    await expect(page).toHaveURL(/\/empresas\/[0-9a-f-]+/);
    const url = page.url();

    await logout(page);
    await login(page, USER_B);
    await page.goto(url);
    // RLS: B não vê o nome de A
    await expect(page.getByText(nome)).toHaveCount(0);
  });

  test('X-01b: userB não vê empresas de A na própria listagem', async ({ page }) => {
    await login(page, USER_B);
    await page.goto('/empresas');
    // não deve aparecer nenhuma "SecretA" criada por A
    await expect(page.getByText(/SecretA /)).toHaveCount(0);
  });
});

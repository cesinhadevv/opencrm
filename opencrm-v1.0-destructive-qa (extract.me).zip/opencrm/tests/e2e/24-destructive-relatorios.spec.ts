import { test, expect } from '@playwright/test';
import { login, USER_A } from './helpers';

test.describe('Destructive — Relatórios', () => {
  test.beforeEach(async ({ page }) => {
    await login(page, USER_A);
  });

  test('RP-03: período inválido na URL cai em default seguro (sem crash)', async ({ page }) => {
    await page.goto('/relatorios?period=hack-injection-%27%22');
    // página carrega normalmente (default all_time/this_month), sem erro
    await expect(page.getByText(/Conversão|Ticket|Funil/i)).toBeVisible({ timeout: 15000 });
  });

  test('RP-03b: período vazio carrega default', async ({ page }) => {
    await page.goto('/relatorios?period=');
    await expect(page.getByText(/Conversão|Ticket|Funil/i)).toBeVisible({ timeout: 15000 });
  });
});

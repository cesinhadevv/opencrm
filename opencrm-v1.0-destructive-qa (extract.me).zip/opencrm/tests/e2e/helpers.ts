import { type Page, expect } from '@playwright/test';

// Reexporta os helpers de cadastro/onboarding pré-existentes (contas únicas por run).
export { uniqueEmail, TEST_PASSWORD, signUp, signIn, completeOnboarding } from './helpers/auth';

/**
 * Contas FIXAS para testes que exigem dois tenants estáveis (cross-tenant F14)
 * ou um usuário já confirmado + onboarded. Pré-criar em staging e informar via env.
 */
export const USER_A = {
  email: process.env.E2E_USER_A_EMAIL ?? 'a@opencrm-test.dev',
  password: process.env.E2E_USER_A_PASSWORD ?? 'Test1234!seguro',
};
export const USER_B = {
  email: process.env.E2E_USER_B_EMAIL ?? 'b@opencrm-test.dev',
  password: process.env.E2E_USER_B_PASSWORD ?? 'Test1234!seguro',
};

export async function login(page: Page, user: { email: string; password: string }) {
  await page.goto('/login');
  await page.getByLabel('E-mail').fill(user.email);
  await page.getByLabel('Senha').fill(user.password);
  await page.getByRole('button', { name: 'Entrar' }).click();
  await expect(page).not.toHaveURL(/\/login/, { timeout: 15000 });
}

export async function logout(page: Page) {
  await page.getByRole('button', { name: 'Sair' }).click();
  await expect(page).toHaveURL(/\/login/, { timeout: 15000 });
}

export function uniqueSuffix(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

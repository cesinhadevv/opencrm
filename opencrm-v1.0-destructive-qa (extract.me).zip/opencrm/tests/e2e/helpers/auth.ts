import { type Page, expect } from '@playwright/test';

/**
 * Helpers de autenticação E2E. Geram contas únicas por execução para isolar testes.
 * NB: se "Confirm email" estiver LIGADO no Supabase (DR-A6), o signUp não autentica
 * automaticamente — use E2E_CONFIRM_EMAIL=off num projeto de teste, ou um usuário
 * pré-confirmado via SQL seed. Ver TEST_PLAN.md §Pré-condições.
 */
export function uniqueEmail(prefix = 'qa'): string {
  return `${prefix}+${Date.now()}-${Math.floor(Math.random() * 1e6)}@opencrm-test.dev`;
}

export const TEST_PASSWORD = 'Test1234!seguro';

export async function signUp(page: Page, email: string, name = 'QA Tester') {
  await page.goto('/cadastro');
  await page.getByLabel('Nome').fill(name);
  await page.getByLabel('E-mail').fill(email);
  await page.getByLabel('Senha').fill(TEST_PASSWORD);
  await page.getByRole('button', { name: 'Criar conta' }).click();
}

export async function signIn(page: Page, email: string) {
  await page.goto('/login');
  await page.getByLabel('E-mail').fill(email);
  await page.getByLabel('Senha').fill(TEST_PASSWORD);
  await page.getByRole('button', { name: 'Entrar' }).click();
}

export async function completeOnboarding(page: Page) {
  await page.waitForURL('**/onboarding', { timeout: 15_000 });
  await page.getByLabel('Seu nome').fill('QA Tester');
  await page.getByRole('button', { name: 'Continuar' }).click(); // passo 1 -> 2
  await page.getByRole('button', { name: 'Continuar' }).click(); // passo 2 -> 3
  await page.getByRole('button', { name: 'Concluir' }).click();
  await page.waitForURL((url) => !url.pathname.includes('onboarding'), { timeout: 15_000 });
}

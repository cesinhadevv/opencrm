#!/usr/bin/env bash
# =============================================================================
# reset_db.sh — Limpa e recria os dados de teste do OpenCRM.
# NUNCA rodar em produção. Exige DATABASE_URL de um banco de STAGING/local.
# Uso:
#   export DATABASE_URL="postgresql://...staging..."
#   export SEED_OWNER="<uuid-de-um-profile-existente>"
#   ./tests/seed/reset_db.sh
# =============================================================================
set -euo pipefail

if [[ -z "${DATABASE_URL:-}" ]]; then
  echo "ERRO: defina DATABASE_URL (staging/local, nunca produção)." >&2
  exit 1
fi
if [[ "$DATABASE_URL" == *"prod"* ]]; then
  echo "ERRO: DATABASE_URL parece ser de produção. Abortando por segurança." >&2
  exit 1
fi
if [[ -z "${SEED_OWNER:-}" ]]; then
  echo "ERRO: defina SEED_OWNER (UUID de um usuário/profile existente)." >&2
  exit 1
fi

echo "==> Limpando dados de negócio (preserva auth.users, profiles, estágios, canais)..."
psql "$DATABASE_URL" <<SQL
begin;
delete from public.aftersale_records;
delete from public.proposals;
delete from public.tasks;
delete from public.activities;
delete from public.deals;
delete from public.contact_channels where contact_id is not null or account_id is not null;
delete from public.contacts;
delete from public.accounts;
commit;
SQL

echo "==> Reaplicando seed para owner $SEED_OWNER ..."
psql "$DATABASE_URL" -v owner="'$SEED_OWNER'" -f "$(dirname "$0")/seed.sql"

echo "==> Concluído."

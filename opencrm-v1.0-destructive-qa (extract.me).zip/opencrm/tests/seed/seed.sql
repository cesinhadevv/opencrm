-- =============================================================================
-- SEED de desenvolvimento — OpenCRM V1.0
-- Popula dados realistas para um owner já existente.
-- USO: substitua :owner por um UUID real de public.profiles (usuário cadastrado).
--   psql "$DATABASE_URL" -v owner="'<UUID>'" -f tests/seed/seed.sql
-- NÃO usar em produção. Idempotente por prefixo de id fixo (apaga antes de inserir).
-- =============================================================================

\set ON_ERROR_STOP on

begin;

-- Limpa dados de seed anteriores deste owner (ids com prefixo 5eed)
delete from public.aftersale_records where owner_id = :owner and id::text like '5eed%';
delete from public.proposals       where owner_id = :owner and id::text like '5eed%';
delete from public.tasks           where owner_id = :owner and id::text like '5eed%';
delete from public.activities      where owner_id = :owner and id::text like '5eed%';
delete from public.deals           where owner_id = :owner and id::text like '5eed%';
delete from public.contact_channels where owner_id = :owner and id::text like '5eed%';
delete from public.contacts        where owner_id = :owner and id::text like '5eed%';
delete from public.accounts        where owner_id = :owner and id::text like '5eed%';

-- Estágios: assume que o onboarding já criou. Pega o primeiro como referência.
-- (Se não houver, rode o onboarding na app antes.)

-- Empresas
insert into public.accounts (id, owner_id, name, segment, origin) values
  ('5eed0000-0000-0000-0000-000000000001', :owner, 'Mercado Boa Compra', 'Varejo alimentar', 'Instagram'),
  ('5eed0000-0000-0000-0000-000000000002', :owner, 'Farmácia Saúde Já',  'Farmácia',        'Indicação'),
  ('5eed0000-0000-0000-0000-000000000003', :owner, 'Loja TecModa',        'Vestuário',       'LinkedIn');

-- Contatos
insert into public.contacts (id, owner_id, account_id, name, role) values
  ('5eed0000-0000-0000-0000-000000000101', :owner, '5eed0000-0000-0000-0000-000000000001', 'Ana Souza', 'Compradora'),
  ('5eed0000-0000-0000-0000-000000000102', :owner, '5eed0000-0000-0000-0000-000000000002', 'Carlos Lima', 'Gerente');

-- Canais
insert into public.contact_channels (id, owner_id, account_id, contact_id, type, canonical, display) values
  ('5eed0000-0000-0000-0000-000000000201', :owner, '5eed0000-0000-0000-0000-000000000001', '5eed0000-0000-0000-0000-000000000101', 'whatsapp', '+5511988887777', '(11) 98888-7777'),
  ('5eed0000-0000-0000-0000-000000000202', :owner, '5eed0000-0000-0000-0000-000000000002', '5eed0000-0000-0000-0000-000000000102', 'email', 'carlos@saudeja.com', 'carlos@saudeja.com');

-- Oportunidades (valores em centavos). stage_id pega o primeiro estágio do owner.
insert into public.deals (id, owner_id, account_id, title, value, status, stage_id, probability, expected_close_at)
select '5eed0000-0000-0000-0000-000000000301', :owner, '5eed0000-0000-0000-0000-000000000001',
       'Implantar PDV', 1500000, 'open',
       (select id from public.pipeline_stages where owner_id = :owner and deleted_at is null order by position limit 1),
       40, now() + interval '15 days';
insert into public.deals (id, owner_id, account_id, title, value, status, stage_id, probability, expected_close_at)
select '5eed0000-0000-0000-0000-000000000302', :owner, '5eed0000-0000-0000-0000-000000000002',
       'Sistema de estoque', 800000, 'open',
       (select id from public.pipeline_stages where owner_id = :owner and deleted_at is null order by position limit 1),
       60, now() + interval '5 days';

-- Atividades
insert into public.activities (id, owner_id, account_id, deal_id, direction, source, content, occurred_at) values
  ('5eed0000-0000-0000-0000-000000000401', :owner, '5eed0000-0000-0000-0000-000000000001', '5eed0000-0000-0000-0000-000000000301', 'outbound', 'manual', 'Apresentei a proposta inicial', now() - interval '3 days'),
  ('5eed0000-0000-0000-0000-000000000402', :owner, '5eed0000-0000-0000-0000-000000000002', '5eed0000-0000-0000-0000-000000000302', 'inbound', 'manual', 'Cliente pediu desconto', now() - interval '1 day');

-- Tarefas (follow-ups)
insert into public.tasks (id, owner_id, account_id, deal_id, title, due_at, status, priority) values
  ('5eed0000-0000-0000-0000-000000000501', :owner, '5eed0000-0000-0000-0000-000000000001', '5eed0000-0000-0000-0000-000000000301', 'Retornar com condições', now() + interval '1 day', 'open', 1),
  ('5eed0000-0000-0000-0000-000000000502', :owner, '5eed0000-0000-0000-0000-000000000002', '5eed0000-0000-0000-0000-000000000302', 'Enviar contrato', now() - interval '1 day', 'open', 1);

-- Proposta enviada (alimenta "proposta a vencer" no Score)
insert into public.proposals (id, owner_id, deal_id, status, value, sent_at, valid_until) values
  ('5eed0000-0000-0000-0000-000000000601', :owner, '5eed0000-0000-0000-0000-000000000301', 'sent', 1500000, now() - interval '1 day', now() + interval '2 days');

commit;

-- Resumo
select 'accounts' as tabela, count(*) from public.accounts where owner_id = :owner and id::text like '5eed%'
union all select 'deals', count(*) from public.deals where owner_id = :owner and id::text like '5eed%'
union all select 'activities', count(*) from public.activities where owner_id = :owner and id::text like '5eed%'
union all select 'tasks', count(*) from public.tasks where owner_id = :owner and id::text like '5eed%'
union all select 'proposals', count(*) from public.proposals where owner_id = :owner and id::text like '5eed%';

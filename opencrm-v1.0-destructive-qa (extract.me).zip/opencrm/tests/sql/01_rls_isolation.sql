-- =============================================================================
-- TESTE SQL 01 — Isolamento RLS cross-tenant (F14)
-- Executar no SQL Editor do Supabase de STAGING. Requer dois usuários reais.
-- Substitua :user_a e :user_b pelos UUIDs de auth.users de duas contas de teste.
-- Cada bloco simula o contexto de um usuário via set_config do JWT claim.
-- =============================================================================

-- Helper: simula a sessão de um usuário (auth.uid()).
-- No SQL Editor use: select set_config('request.jwt.claims', '{"sub":"<UUID>"}', true);

-- --- Setup: como user A, cria uma empresa ---
select set_config('request.jwt.claims', json_build_object('sub', '<USER_A_UUID>')::text, true);
insert into public.accounts (id, owner_id, name)
values ('aaaaaaaa-0000-0000-0000-000000000001', '<USER_A_UUID>', 'Empresa do A');

-- --- Teste: como user B, NÃO deve ver a empresa de A ---
select set_config('request.jwt.claims', json_build_object('sub', '<USER_B_UUID>')::text, true);

-- ESPERADO: 0 linhas (RLS accounts_all_own bloqueia leitura cross-tenant)
select count(*) as deve_ser_zero
from public.accounts
where id = 'aaaaaaaa-0000-0000-0000-000000000001';

-- --- Teste: como user B, NÃO deve conseguir alterar a empresa de A ---
-- ESPERADO: 0 linhas afetadas (RLS USING filtra; UPDATE não encontra a linha)
update public.accounts set name = 'Invadido'
where id = 'aaaaaaaa-0000-0000-0000-000000000001';

-- --- Verificação final: como user A, a empresa continua intacta ---
select set_config('request.jwt.claims', json_build_object('sub', '<USER_A_UUID>')::text, true);
-- ESPERADO: name = 'Empresa do A' (não foi alterada por B)
select name from public.accounts
where id = 'aaaaaaaa-0000-0000-0000-000000000001';

-- --- Cleanup ---
delete from public.accounts where id = 'aaaaaaaa-0000-0000-0000-000000000001';

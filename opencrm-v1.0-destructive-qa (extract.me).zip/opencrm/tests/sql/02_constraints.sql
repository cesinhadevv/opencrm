-- =============================================================================
-- TESTE SQL 02 — Constraints
-- Cada INSERT abaixo DEVE FALHAR. Se algum suceder, a constraint está ausente.
-- Executar como um usuário autenticado (set_config do claim sub).
-- =============================================================================
select set_config('request.jwt.claims', json_build_object('sub', '<USER_A_UUID>')::text, true);

-- C1: deals_status_consistency — won sem won_at deve FALHAR
-- ESPERADO: ERROR (violates check constraint "deals_status_consistency")
insert into public.deals (owner_id, account_id, title, status, won_at)
values ('<USER_A_UUID>', '<ACCOUNT_UUID>', 'Inválido', 'won', null);

-- C2: deals lost sem lost_reason deve FALHAR
-- ESPERADO: ERROR
insert into public.deals (owner_id, account_id, title, status, lost_at, lost_reason)
values ('<USER_A_UUID>', '<ACCOUNT_UUID>', 'Inválido', 'lost', now(), null);

-- C3: activity com direction inválido deve FALHAR
-- ESPERADO: ERROR (check direction in (...))
insert into public.activities (owner_id, account_id, direction, content)
values ('<USER_A_UUID>', '<ACCOUNT_UUID>', 'telepatia', 'x');

-- C4: contact_channel sem dono (account_id e contact_id nulos) deve FALHAR
-- ESPERADO: ERROR (num_nonnulls = 1)
insert into public.contact_channels (owner_id, type, canonical, display)
values ('<USER_A_UUID>', 'email', 'x@y.com', 'x@y.com');

-- C5: proposal com status inválido deve FALHAR
-- ESPERADO: ERROR
insert into public.proposals (owner_id, deal_id, status)
values ('<USER_A_UUID>', '<DEAL_UUID>', 'talvez');

-- C6: aftersale satisfaction_score fora de 0-10 deve FALHAR
-- ESPERADO: ERROR
insert into public.aftersale_records (owner_id, account_id, deal_id, type, satisfaction_score)
values ('<USER_A_UUID>', '<ACCOUNT_UUID>', '<DEAL_UUID>', 'satisfaction', 99);

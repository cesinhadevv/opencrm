-- =============================================================================
-- TESTE SQL 03 — Triggers e RPCs
-- =============================================================================

-- T1: handle_new_user — ao inserir em auth.users, profile é criado.
-- (Validado indiretamente: após cadastro real, confirmar:)
-- ESPERADO: 1 linha por usuário cadastrado
select count(*) as profiles_provisionados from public.profiles;

-- T2: set_updated_at — updated_at muda em UPDATE.
select set_config('request.jwt.claims', json_build_object('sub', '<USER_A_UUID>')::text, true);
insert into public.accounts (id, owner_id, name)
values ('bbbbbbbb-0000-0000-0000-000000000002', '<USER_A_UUID>', 'Trigger Test');
-- captura o updated_at inicial, espera, atualiza
select updated_at as antes from public.accounts where id = 'bbbbbbbb-0000-0000-0000-000000000002';
update public.accounts set name = 'Trigger Test 2'
where id = 'bbbbbbbb-0000-0000-0000-000000000002';
-- ESPERADO: depois > antes
select updated_at as depois from public.accounts where id = 'bbbbbbbb-0000-0000-0000-000000000002';
delete from public.accounts where id = 'bbbbbbbb-0000-0000-0000-000000000002';

-- R1: create_account_with_channels — cria account + canais atomicamente.
-- ESPERADO: sucesso; 1 account + 2 canais
select public.create_account_with_channels(
  'cccccccc-0000-0000-0000-000000000003'::uuid,
  'Empresa RPC',
  'Varejo',
  'Instagram',
  '[{"id":"dddddddd-0000-0000-0000-000000000004","type":"email","canonical":"loja@x.com","display":"loja@x.com"},
    {"id":"dddddddd-0000-0000-0000-000000000005","type":"whatsapp","canonical":"+5511999990000","display":"(11) 99999-0000"}]'::jsonb
);
-- ESPERADO: 1
select count(*) as account_criada from public.accounts where id = 'cccccccc-0000-0000-0000-000000000003';
-- ESPERADO: 2
select count(*) as canais_criados from public.contact_channels
where account_id = 'cccccccc-0000-0000-0000-000000000003';

-- R2: close_deal_won_with_task — fecha won + cria task atomicamente.
-- Pré: criar um deal aberto primeiro.
insert into public.deals (id, owner_id, account_id, title, status, stage_id)
values ('eeeeeeee-0000-0000-0000-000000000006', '<USER_A_UUID>',
        'cccccccc-0000-0000-0000-000000000003', 'Deal RPC', 'open', '<STAGE_UUID>');
select public.close_deal_won_with_task(
  'eeeeeeee-0000-0000-0000-000000000006'::uuid,
  'cccccccc-0000-0000-0000-000000000003'::uuid,
  'ffffffff-0000-0000-0000-000000000007'::uuid,
  now(), 'Acompanhar pós-venda', now() + interval '7 days'
);
-- ESPERADO: status='won', won_at não nulo
select status, won_at is not null as tem_won_at from public.deals
where id = 'eeeeeeee-0000-0000-0000-000000000006';
-- ESPERADO: 1 task criada
select count(*) as task_pos_venda from public.tasks
where id = 'ffffffff-0000-0000-0000-000000000007';

-- R2b: idempotência — chamar de novo sobre deal já won NÃO cria 2ª task.
select public.close_deal_won_with_task(
  'eeeeeeee-0000-0000-0000-000000000006'::uuid,
  'cccccccc-0000-0000-0000-000000000003'::uuid,
  'ffffffff-0000-0000-0000-000000000008'::uuid,
  now(), 'Duplicata', now() + interval '7 days'
);
-- ESPERADO: 0 (deal não estava mais 'open', task nova não foi criada)
select count(*) as task_duplicada from public.tasks
where id = 'ffffffff-0000-0000-0000-000000000008';

-- Cleanup
delete from public.tasks where id in ('ffffffff-0000-0000-0000-000000000007','ffffffff-0000-0000-0000-000000000008');
delete from public.deals where id = 'eeeeeeee-0000-0000-0000-000000000006';
delete from public.contact_channels where account_id = 'cccccccc-0000-0000-0000-000000000003';
delete from public.accounts where id = 'cccccccc-0000-0000-0000-000000000003';

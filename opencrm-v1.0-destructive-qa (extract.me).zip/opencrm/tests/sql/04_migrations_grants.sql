-- =============================================================================
-- TESTE SQL 04 — Migrations, índices, grants (validação estrutural)
-- =============================================================================

-- M1: 12 tabelas existem
-- ESPERADO: 12
select count(*) as total_tabelas from pg_tables
where schemaname = 'public'
  and tablename in ('profiles','owner_configs','pipeline_stages','channels','accounts',
    'contacts','contact_channels','activities','tasks','deals','proposals','aftersale_records');

-- M2: RLS habilitada em todas
-- ESPERADO: 12 linhas, todas relrowsecurity=true
select relname, relrowsecurity from pg_class
where relnamespace = 'public'::regnamespace
  and relname in ('profiles','owner_configs','pipeline_stages','channels','accounts',
    'contacts','contact_channels','activities','tasks','deals','proposals','aftersale_records')
order by relname;

-- M3: 14 policies existem
-- ESPERADO: 14
select count(*) as total_policies from pg_policies where schemaname = 'public';

-- M4: 2 RPCs de negócio com grant execute para authenticated
-- ESPERADO: 2 linhas
select p.proname, has_function_privilege('authenticated', p.oid, 'execute') as authenticated_pode
from pg_proc p
join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public'
  and p.proname in ('create_account_with_channels','close_deal_won_with_task');

-- M5: índices parciais de unicidade existem
-- ESPERADO: linhas para owner_configs_unique_active, channels_unique_active, etc.
select indexname from pg_indexes
where schemaname = 'public' and indexname like '%unique_active';

-- M6: FKs de deal_id em activities e tasks
-- ESPERADO: activities_deal_fk e tasks_deal_fk
select conname from pg_constraint where conname in ('activities_deal_fk','tasks_deal_fk');

-- M7: contact_channels NÃO tem mais índice único global (M3 hardening)
-- ESPERADO: 0 (foi trocado por contact_channels_lookup_idx não-único)
select count(*) as indice_unico_removido from pg_indexes
where schemaname='public' and indexname='contact_channels_unique_active';

-- =============================================================================
-- TESTE SQL 05 — Destrutivo (rollback, atomicidade, idempotência)
-- Casos que o Playwright NÃO alcança: falha interna de RPC, transação parcial.
-- Executar em STAGING, como usuário autenticado (set_config do claim sub).
-- =============================================================================
select set_config('request.jwt.claims', json_build_object('sub', '<USER_A_UUID>')::text, true);

-- ---------------------------------------------------------------------------
-- E-03 [RB] Atomicidade de create_account_with_channels:
-- canal com type INVÁLIDO no meio do array deve abortar TUDO.
-- ---------------------------------------------------------------------------
do $$
declare
  v_count int;
begin
  begin
    perform public.create_account_with_channels(
      '5eedfa11-0000-0000-0000-000000000001'::uuid,
      'Empresa Rollback', 'Varejo', 'Teste',
      '[{"id":"5eedfa11-0000-0000-0000-000000000002","type":"email","canonical":"a@b.com","display":"a@b.com"},
        {"id":"5eedfa11-0000-0000-0000-000000000003","type":"INVALIDO","canonical":"x","display":"x"}]'::jsonb
    );
    raise notice 'FALHA DE TESTE: RPC nao abortou com canal invalido';
  exception when others then
    raise notice 'OK: RPC abortou (% )', sqlerrm;
  end;

  -- ESPERADO: 0 — a account NÃO deve existir (rollback da transação da função)
  select count(*) into v_count from public.accounts
  where id = '5eedfa11-0000-0000-0000-000000000001';
  raise notice 'accounts criadas (deve ser 0): %', v_count;
end $$;

-- ---------------------------------------------------------------------------
-- W-03/W-02 [RACE/DUP] close_deal_won_with_task idempotente:
-- fechar duas vezes só cria UMA task.
-- ---------------------------------------------------------------------------
do $$
declare
  v_stage uuid;
  v_tasks int;
begin
  select id into v_stage from public.pipeline_stages
  where owner_id = '<USER_A_UUID>'::uuid and deleted_at is null order by position limit 1;

  insert into public.accounts (id, owner_id, name)
  values ('5eedfa11-0000-0000-0000-000000000010', '<USER_A_UUID>', 'Won Idem');
  insert into public.deals (id, owner_id, account_id, title, status, stage_id)
  values ('5eedfa11-0000-0000-0000-000000000011', '<USER_A_UUID>',
          '5eedfa11-0000-0000-0000-000000000010', 'Deal Idem', 'open', v_stage);

  -- 1ª chamada
  perform public.close_deal_won_with_task(
    '5eedfa11-0000-0000-0000-000000000011'::uuid,
    '5eedfa11-0000-0000-0000-000000000010'::uuid,
    '5eedfa11-0000-0000-0000-000000000012'::uuid,
    now(), 'Pos-venda', now() + interval '7 days');
  -- 2ª chamada (deal já won) — não deve criar nova task
  perform public.close_deal_won_with_task(
    '5eedfa11-0000-0000-0000-000000000011'::uuid,
    '5eedfa11-0000-0000-0000-000000000010'::uuid,
    '5eedfa11-0000-0000-0000-000000000013'::uuid,
    now(), 'Duplicata', now() + interval '7 days');

  select count(*) into v_tasks from public.tasks
  where deal_id = '5eedfa11-0000-0000-0000-000000000011';
  -- ESPERADO: 1 (não 2)
  raise notice 'tasks de pos-venda (deve ser 1): %', v_tasks;

  -- cleanup
  delete from public.tasks where deal_id = '5eedfa11-0000-0000-0000-000000000011';
  delete from public.deals where id = '5eedfa11-0000-0000-0000-000000000011';
  delete from public.accounts where id = '5eedfa11-0000-0000-0000-000000000010';
end $$;

-- ---------------------------------------------------------------------------
-- PV-03 [RPC] config upsert NÃO usa ON CONFLICT em índice parcial:
-- dois set seguidos da mesma chave devem resultar em UMA linha (update, não erro).
-- (Validação do upsert manual do config-store.)
-- ---------------------------------------------------------------------------
do $$
declare
  v_count int;
begin
  delete from public.owner_configs
   where owner_id='<USER_A_UUID>' and namespace='test' and key='k1';
  insert into public.owner_configs (owner_id, namespace, key, value)
  values ('<USER_A_UUID>', 'test', 'k1', '"v1"'::jsonb);
  -- simula 2º set: update do registro ativo (como o repo faz)
  update public.owner_configs set value='"v2"'::jsonb
   where owner_id='<USER_A_UUID>' and namespace='test' and key='k1' and deleted_at is null;
  select count(*) into v_count from public.owner_configs
   where owner_id='<USER_A_UUID>' and namespace='test' and key='k1' and deleted_at is null;
  -- ESPERADO: 1 (sem duplicata)
  raise notice 'config rows (deve ser 1): %', v_count;
  delete from public.owner_configs
   where owner_id='<USER_A_UUID>' and namespace='test' and key='k1';
end $$;

-- ---------------------------------------------------------------------------
-- X-02 [RLS] close_deal_won_with_task como OUTRO usuário não afeta deal alheio.
-- Como auth.uid() vem do claim, trocar o claim simula o atacante.
-- ---------------------------------------------------------------------------
-- (Pré: criar deal como A; depois trocar claim para B e tentar fechar.)
-- ESPERADO: o UPDATE dentro da RPC casa owner_id = auth.uid() (B) e NÃO encontra
-- o deal de A → nenhuma task criada, deal de A intacto.

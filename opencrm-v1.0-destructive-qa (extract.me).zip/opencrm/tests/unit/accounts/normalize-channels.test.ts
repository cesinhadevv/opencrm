import { describe, it, expect } from 'vitest';
import { normalizeChannels } from '@/modules/accounts/application/normalize-channels';

const fakeIds = { generate: () => 'fixed-id' };

/** DR-C2: normalização canônica por tipo, com display preservado. */
describe('normalizeChannels', () => {
  it('normaliza email, telefone e handle ao canônico correto', () => {
    const result = normalizeChannels(fakeIds, [
      { type: 'email', value: 'Joao@Gmail.com' },
      { type: 'phone', value: '(11) 99999-8888' },
      { type: 'instagram', value: '@LojaX' },
    ]);
    expect(result[0]!.canonical).toBe('joao@gmail.com');
    expect(result[1]!.canonical).toBe('+5511999998888');
    expect(result[2]!.canonical).toBe('lojax');
    // display preservado
    expect(result[2]!.display).toBe('@LojaX');
  });
});

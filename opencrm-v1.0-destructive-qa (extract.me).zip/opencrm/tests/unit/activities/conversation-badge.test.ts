import { describe, it, expect } from 'vitest';
import type { ConversationState } from '@/modules/activities/domain/entities';

/**
 * O badge é presentation pura: mapeia estado->rótulo, sem lógica de negócio.
 * Validamos o mapeamento (a regra de QUAL estado vem é testada no domínio).
 */
const LABELS: Record<ConversationState, string | null> = {
  followup_overdue: 'Follow-up vencido',
  no_reply: 'Sem retorno',
  cooling: 'Esfriando',
  ok: null,
};

describe('conversation badge mapping', () => {
  it('ok não renderiza rótulo', () => {
    expect(LABELS.ok).toBeNull();
  });
  it('estados de risco têm rótulo PT-BR', () => {
    expect(LABELS.followup_overdue).toBe('Follow-up vencido');
    expect(LABELS.no_reply).toBe('Sem retorno');
    expect(LABELS.cooling).toBe('Esfriando');
  });
});

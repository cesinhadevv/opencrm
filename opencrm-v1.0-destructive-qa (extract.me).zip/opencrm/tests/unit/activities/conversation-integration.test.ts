import { describe, it, expect } from 'vitest';
import {
  deriveConversationState,
  type ConversationThresholds,
} from '@/modules/activities/domain/conversation-state';
import { DEFAULT_CONVERSATION_THRESHOLDS } from '@/modules/activities/application/conversation-config';
import { SystemClock } from '@/core/infrastructure/clock';
import type { Activity, Task } from '@/modules/activities/domain/entities';

const clock = new SystemClock();
const TZ = 'America/Sao_Paulo';

/** Garante que os defaults de config produzem estados coerentes (DR-B4 conectado). */
describe('conversation thresholds default (DR-B4 integração)', () => {
  it('defaults expõem coolingDays e noReplyDays válidos', () => {
    const t: ConversationThresholds = DEFAULT_CONVERSATION_THRESHOLDS;
    expect(t.coolingDays).toBeGreaterThan(0);
    expect(t.noReplyDays).toBeGreaterThan(0);
  });

  it('lead sem interação há muito tempo => cooling com defaults', () => {
    const old: Activity = {
      id: 'a',
      ownerId: 'o',
      accountId: 'acc',
      contactId: null,
      dealId: null,
      channel: null,
      direction: 'outbound',
      source: 'manual',
      content: 'x',
      occurredAt: new Date(Date.now() - 20 * 86400_000),
    };
    const state = deriveConversationState(
      clock,
      TZ,
      DEFAULT_CONVERSATION_THRESHOLDS,
      [old],
      [] as Task[],
    );
    expect(state).toBe('cooling');
  });
});

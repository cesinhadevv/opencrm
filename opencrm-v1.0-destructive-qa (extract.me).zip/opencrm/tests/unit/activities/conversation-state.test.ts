import { describe, it, expect } from 'vitest';
import {
  deriveConversationState,
  classifyTaskBand,
  type ConversationThresholds,
} from '@/modules/activities/domain/conversation-state';
import { SystemClock } from '@/core/infrastructure/clock';
import type { Activity, Task } from '@/modules/activities/domain/entities';

const clock = new SystemClock();
const TZ = 'America/Sao_Paulo';
const thresholds: ConversationThresholds = { coolingDays: 7, noReplyDays: 3 };

function activity(partial: Partial<Activity>): Activity {
  return {
    id: 'a',
    ownerId: 'o',
    accountId: 'acc',
    contactId: null,
    dealId: null,
    channel: null,
    direction: 'outbound',
    source: 'manual',
    content: 'x',
    occurredAt: new Date(),
    ...partial,
  };
}

function task(partial: Partial<Task>): Task {
  return {
    id: 't',
    ownerId: 'o',
    accountId: 'acc',
    dealId: null,
    title: 'x',
    dueAt: new Date(),
    status: 'open',
    priority: 0,
    ...partial,
  };
}

describe('deriveConversationState (DR-B4)', () => {
  it('followup_overdue tem precedência máxima mesmo com interação recente', () => {
    const recent = activity({ occurredAt: new Date() });
    const overdue = task({ dueAt: new Date(Date.now() - 86400_000) });
    expect(deriveConversationState(clock, TZ, thresholds, [recent], [overdue])).toBe(
      'followup_overdue',
    );
  });

  it('no_reply: última interação inbound sem resposta há >= Y dias', () => {
    const inbound = activity({
      direction: 'inbound',
      occurredAt: new Date(Date.now() - 4 * 86400_000),
    });
    expect(deriveConversationState(clock, TZ, thresholds, [inbound], [])).toBe('no_reply');
  });

  it('cooling: nenhuma interação real há >= X dias', () => {
    const old = activity({ occurredAt: new Date(Date.now() - 10 * 86400_000) });
    expect(deriveConversationState(clock, TZ, thresholds, [old], [])).toBe('cooling');
  });

  it('nota interna NÃO conta como interação real (RN-17)', () => {
    const note = activity({ direction: 'internal_note', occurredAt: new Date() });
    // Só há nota -> nenhuma interação real -> cooling
    expect(deriveConversationState(clock, TZ, thresholds, [note], [])).toBe('cooling');
  });

  it('ok: interação real recente, sem follow-up vencido', () => {
    const recent = activity({ occurredAt: new Date() });
    expect(deriveConversationState(clock, TZ, thresholds, [recent], [])).toBe('ok');
  });
});

describe('classifyTaskBand (DR-A3)', () => {
  it('classifica tarefa passada como overdue', () => {
    const t = task({ dueAt: new Date(Date.now() - 2 * 86400_000) });
    expect(classifyTaskBand(clock, TZ, t)).toBe('overdue');
  });
  it('classifica tarefa distante como upcoming', () => {
    const t = task({ dueAt: new Date(Date.now() + 30 * 86400_000) });
    expect(classifyTaskBand(clock, TZ, t)).toBe('upcoming');
  });
});

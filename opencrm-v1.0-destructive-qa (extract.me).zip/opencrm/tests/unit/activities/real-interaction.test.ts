import { describe, it, expect } from 'vitest';
import { isRealInteraction } from '@/modules/activities/domain/entities';

describe('isRealInteraction (RN-17)', () => {
  it('outbound e inbound contam', () => {
    expect(isRealInteraction('outbound')).toBe(true);
    expect(isRealInteraction('inbound')).toBe(true);
  });
  it('nota interna não conta', () => {
    expect(isRealInteraction('internal_note')).toBe(false);
  });
});

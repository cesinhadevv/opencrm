import { describe, it, expect } from 'vitest';
import { planMilestoneTasks } from '@/modules/aftersale/domain/entities';
import { DEFAULT_AFTERSALE_MILESTONES } from '@/modules/aftersale/application/milestones-config';

/** PRD M8 / RN-06: marcos geram tarefas em offsets determinísticos a partir do won. */
describe('planMilestoneTasks', () => {
  it('gera datas relativas ao won conforme offsets dos marcos', () => {
    const wonAt = new Date('2026-06-01T12:00:00Z');
    const planned = planMilestoneTasks(wonAt, DEFAULT_AFTERSALE_MILESTONES);
    expect(planned).toHaveLength(3);
    expect(planned[0]!.dueAt.toISOString()).toBe(
      new Date(wonAt.getTime() + 7 * 86400_000).toISOString(),
    );
    expect(planned[1]!.dueAt.toISOString()).toBe(
      new Date(wonAt.getTime() + 30 * 86400_000).toISOString(),
    );
    expect(planned[2]!.type).toBe('upsell');
  });

  it('sem marcos => nenhuma tarefa', () => {
    expect(planMilestoneTasks(new Date(), [])).toHaveLength(0);
  });
});

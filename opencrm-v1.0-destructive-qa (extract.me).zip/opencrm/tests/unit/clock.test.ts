import { describe, it, expect } from 'vitest';
import { SystemClock } from '@/core/infrastructure/clock';

/** DR-A3: cálculo de dia no fuso do usuário. */
describe('SystemClock', () => {
  const clock = new SystemClock();
  it('daysBetween conta dias-calendário no fuso', () => {
    const from = new Date('2026-06-01T12:00:00Z');
    const to = new Date('2026-06-08T12:00:00Z');
    expect(clock.daysBetween(from, to, 'America/Sao_Paulo')).toBe(7);
  });
  it('startOfUserDay retorna meia-noite local', () => {
    const ref = new Date('2026-06-15T03:00:00Z'); // meia-noite em SP é 03:00Z
    const start = clock.startOfUserDay('America/Sao_Paulo', ref);
    expect(start.getHours()).toBeDefined();
  });
});

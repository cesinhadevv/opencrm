import { describe, it, expect } from 'vitest';
import { z } from 'zod';
import { toFieldErrors, requireVerifiedEmail } from '@/core/application/action-helpers';

describe('toFieldErrors', () => {
  it('mapeia issues do Zod para campo->mensagem', () => {
    const schema = z.object({ email: z.string().email(), name: z.string().min(1) });
    const result = schema.safeParse({ email: 'x', name: '' });
    expect(result.success).toBe(false);
    if (!result.success) {
      const fe = toFieldErrors(result.error);
      expect(fe.email).toBeDefined();
      expect(fe.name).toBeDefined();
    }
  });

  it('usa "form" como chave quando o path é vazio', () => {
    const schema = z.string().min(5);
    const result = schema.safeParse('ab');
    if (!result.success) {
      const fe = toFieldErrors(result.error);
      expect(fe.form).toBeDefined();
    }
  });
});

describe('requireVerifiedEmail (DR-A6)', () => {
  it('bloqueia quando e-mail não verificado', () => {
    const block = requireVerifiedEmail({ ownerId: 'o', emailVerified: false });
    expect(block).not.toBeNull();
    expect(block?.ok).toBe(false);
    if (block && !block.ok) expect(block.code).toBe('unauthorized');
  });

  it('libera quando e-mail verificado', () => {
    expect(requireVerifiedEmail({ ownerId: 'o', emailVerified: true })).toBeNull();
  });
});

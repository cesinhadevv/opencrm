import { describe, it, expect } from 'vitest';
import { ensure, unwrap } from '@/lib/supabase/guard';

describe('supabase guard (C1)', () => {
  it('ensure lança quando há erro', () => {
    expect(() => ensure({ error: { message: 'constraint x' } })).toThrow(/constraint x/);
  });
  it('ensure não lança quando ok', () => {
    expect(() => ensure({ error: null })).not.toThrow();
  });
  it('unwrap lança em erro e retorna data em sucesso', () => {
    expect(() => unwrap({ data: null, error: { message: 'rls' } })).toThrow(/rls/);
    expect(unwrap({ data: [1, 2], error: null })).toEqual([1, 2]);
  });
});

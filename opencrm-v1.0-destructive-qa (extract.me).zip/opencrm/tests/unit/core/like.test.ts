import { describe, it, expect } from 'vitest';
import { escapeLike } from '@/lib/utils/like';

describe('escapeLike (#10 — busca literal)', () => {
  it('escapa porcentagem e underscore', () => {
    expect(escapeLike('100%')).toBe('100\\%');
    expect(escapeLike('a_b')).toBe('a\\_b');
  });
  it('escapa a própria barra invertida', () => {
    expect(escapeLike('a\\b')).toBe('a\\\\b');
  });
  it('texto comum permanece intacto', () => {
    expect(escapeLike('Loja Centro')).toBe('Loja Centro');
  });
});

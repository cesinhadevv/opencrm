import { describe, it, expect } from 'vitest';
import { normalizeEmail, normalizePhone, normalizeHandle } from '@/core/domain/identifiers';

/** DR-C2/ADR-012: canônico para regras; exibição para UI. */
describe('normalizeEmail', () => {
  it('canônico é minúsculo e sem espaços; exibição preserva original', () => {
    const r = normalizeEmail('  Joao@Gmail.com ');
    expect(r.canonical).toBe('joao@gmail.com');
    expect(r.display).toBe('Joao@Gmail.com');
  });
});

describe('normalizePhone', () => {
  it('aplica país default quando não há prefixo internacional', () => {
    expect(normalizePhone('(11) 99999-8888', '55').canonical).toBe('+5511999998888');
  });
  it('preserva prefixo internacional existente', () => {
    expect(normalizePhone('+1 415 555 0100', '55').canonical).toBe('+14155550100');
  });
});

describe('normalizeHandle', () => {
  it('remove @ e baixa caixa', () => {
    expect(normalizeHandle('@LojaX').canonical).toBe('lojax');
  });
  it('extrai handle de URL de instagram', () => {
    expect(normalizeHandle('https://instagram.com/lojax/').canonical).toBe('lojax');
  });
});

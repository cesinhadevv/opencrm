import { describe, it, expect } from 'vitest';
import { resolveProbabilityOnStageMove } from '@/modules/pipeline/domain/probability';

/** DR-E4: default do stage prevalece, exceto se houver override manual. */
describe('resolveProbabilityOnStageMove', () => {
  it('adota default do novo stage quando não houve override', () => {
    const result = resolveProbabilityOnStageMove(
      { probability: 30, probabilityOverridden: false },
      { defaultProbability: 85 },
    );
    expect(result).toBe(85);
  });

  it('mantém valor manual quando houve override (sem pop-up)', () => {
    const result = resolveProbabilityOnStageMove(
      { probability: 50, probabilityOverridden: true },
      { defaultProbability: 85 },
    );
    expect(result).toBe(50);
  });
});

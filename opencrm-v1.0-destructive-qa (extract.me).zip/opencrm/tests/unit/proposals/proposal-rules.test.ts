import { describe, it, expect } from 'vitest';
import { isExpired, isProposalDueSoon } from '@/modules/proposals/domain/entities';
import { SystemClock } from '@/core/infrastructure/clock';

const clock = new SystemClock();
const TZ = 'America/Sao_Paulo';

describe('isExpired (RN-04)', () => {
  it('sent + validade passada => vencida', () => {
    expect(isExpired(clock, { status: 'sent', validUntil: new Date(Date.now() - 86400_000) })).toBe(
      true,
    );
  });
  it('sent + validade futura => não vencida', () => {
    expect(isExpired(clock, { status: 'sent', validUntil: new Date(Date.now() + 86400_000) })).toBe(
      false,
    );
  });
  it('draft nunca vence', () => {
    expect(
      isExpired(clock, { status: 'draft', validUntil: new Date(Date.now() - 86400_000) }),
    ).toBe(false);
  });
});

describe('isProposalDueSoon (componente do Score — ADR-011-A)', () => {
  it('vence dentro da janela => true', () => {
    expect(
      isProposalDueSoon(clock, TZ, 5, {
        status: 'sent',
        validUntil: new Date(Date.now() + 3 * 86400_000),
      }),
    ).toBe(true);
  });
  it('já vencida sem resposta => true', () => {
    expect(
      isProposalDueSoon(clock, TZ, 5, {
        status: 'sent',
        validUntil: new Date(Date.now() - 86400_000),
      }),
    ).toBe(true);
  });
  it('vence fora da janela => false', () => {
    expect(
      isProposalDueSoon(clock, TZ, 5, {
        status: 'sent',
        validUntil: new Date(Date.now() + 30 * 86400_000),
      }),
    ).toBe(false);
  });
  it('sem proposta => false', () => {
    expect(isProposalDueSoon(clock, TZ, 5, null)).toBe(false);
  });
});

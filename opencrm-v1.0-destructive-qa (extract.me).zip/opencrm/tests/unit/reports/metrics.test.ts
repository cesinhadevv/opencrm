import { describe, it, expect } from 'vitest';
import {
  conversionRate,
  averageTicket,
  averageDaysToClose,
  buildFunnel,
  computeDealMetrics,
  filterByPeriod,
  type DealFact,
} from '@/modules/reports/domain/metrics';

function deal(p: Partial<DealFact>): DealFact {
  return {
    id: 'd',
    value: 100000,
    status: 'open',
    stageId: 's1',
    createdAt: new Date('2026-06-01T00:00:00Z'),
    wonAt: null,
    lostAt: null,
    ...p,
  };
}

describe('conversionRate', () => {
  it('won / (won+lost)', () => {
    expect(conversionRate(3, 1)).toBe(0.75);
  });
  it('0 quando nada fechado', () => {
    expect(conversionRate(0, 0)).toBe(0);
  });
});

describe('averageTicket', () => {
  it('média dos valores ganhos (centavos)', () => {
    expect(averageTicket([deal({ value: 100000 }), deal({ value: 300000 })])).toBe(200000);
  });
  it('0 sem ganhos', () => {
    expect(averageTicket([])).toBe(0);
  });
});

describe('averageDaysToClose', () => {
  it('média dos dias', () => {
    expect(averageDaysToClose([10, 20, 30])).toBe(20);
  });
  it('0 sem dados', () => {
    expect(averageDaysToClose([])).toBe(0);
  });
});

describe('buildFunnel', () => {
  it('agrupa abertos por estágio com contagem e valor', () => {
    const funnel = buildFunnel([
      deal({ stageId: 's1', value: 100000 }),
      deal({ stageId: 's1', value: 200000 }),
      deal({ stageId: 's2', value: 50000 }),
    ]);
    const s1 = funnel.find((f) => f.stageId === 's1')!;
    expect(s1.count).toBe(2);
    expect(s1.totalValue).toBe(300000);
  });
});

describe('computeDealMetrics', () => {
  it('consistência: pipeline conta só open, conversão usa won/lost', () => {
    const deals = [
      deal({ status: 'open', value: 100000, stageId: 's1' }),
      deal({ status: 'won', value: 500000, wonAt: new Date() }),
      deal({ status: 'lost', value: 300000, lostAt: new Date() }),
    ];
    const m = computeDealMetrics(deals, [15]);
    expect(m.pipelineOpenValue).toBe(100000);
    expect(m.pipelineOpenCount).toBe(1);
    expect(m.wonValue).toBe(500000);
    expect(m.lostCount).toBe(1);
    expect(m.conversionRate).toBe(0.5);
    expect(m.averageTicket).toBe(500000);
    expect(m.averageDaysToClose).toBe(15);
  });
});

describe('filterByPeriod', () => {
  it('inclui apenas deals criados dentro do intervalo', () => {
    const deals = [
      deal({ id: 'in', createdAt: new Date('2026-06-15T00:00:00Z') }),
      deal({ id: 'out', createdAt: new Date('2026-05-01T00:00:00Z') }),
    ];
    const result = filterByPeriod(deals, {
      from: new Date('2026-06-01T00:00:00Z'),
      to: new Date('2026-06-30T23:59:59Z'),
    });
    expect(result).toHaveLength(1);
    expect(result[0]!.id).toBe('in');
  });
});

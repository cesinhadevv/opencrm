import { describe, it, expect } from 'vitest';
import { resolvePeriod } from '@/modules/reports/application/period';
import type { Clock } from '@/core/domain/contracts';

// Clock fixo determinístico para o teste.
const fixedNow = new Date('2026-06-15T12:00:00Z');
const clock: Clock = {
  now: () => fixedNow,
  startOfUserDay: () => fixedNow,
  daysBetween: () => 0,
};

describe('resolvePeriod (filtro temporal — via Clock)', () => {
  it('last_30_days começa 30 dias antes de now', () => {
    const p = resolvePeriod(clock, 'last_30_days');
    expect(p.to).toEqual(fixedNow);
    expect(p.from.getTime()).toBe(fixedNow.getTime() - 30 * 86400_000);
  });
  it('this_year começa em 1 de janeiro', () => {
    const p = resolvePeriod(clock, 'this_year');
    expect(p.from.getFullYear()).toBe(2026);
    expect(p.from.getMonth()).toBe(0);
  });
  it('all_time começa na época Unix', () => {
    const p = resolvePeriod(clock, 'all_time');
    expect(p.from.getTime()).toBe(0);
  });
});

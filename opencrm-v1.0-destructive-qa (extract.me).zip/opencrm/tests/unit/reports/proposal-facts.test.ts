import { describe, it, expect } from 'vitest';

/**
 * A2: regra de "vencida" no relatório deve ser idêntica à do domínio:
 * sent + valid_until no passado. Testamos a regra de classificação isolada.
 */
function isExpiredFact(status: string, validUntil: Date | null, now: number): boolean {
  return status === 'sent' && validUntil !== null && validUntil.getTime() < now;
}

describe('reports proposalFacts — vencida derivada (A2)', () => {
  const now = Date.now();
  it('sent + vencida conta como expired', () => {
    expect(isExpiredFact('sent', new Date(now - 86400_000), now)).toBe(true);
  });
  it('accepted não conta como expired mesmo com validade passada', () => {
    expect(isExpiredFact('accepted', new Date(now - 86400_000), now)).toBe(false);
  });
  it('sent futura não é expired', () => {
    expect(isExpiredFact('sent', new Date(now + 86400_000), now)).toBe(false);
  });
});

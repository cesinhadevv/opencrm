import { describe, it, expect } from 'vitest';
import { success, failure } from '@/core/domain/result';

/** Freeze B5: resultado discriminado sucesso/erro. */
describe('ResultContract', () => {
  it('success carrega data e ok=true', () => {
    const r = success({ next: '/' });
    expect(r.ok).toBe(true);
    if (r.ok) expect(r.data.next).toBe('/');
  });
  it('failure carrega código e mensagem', () => {
    const r = failure('validation', 'Verifique os campos.', { email: 'inválido' });
    expect(r.ok).toBe(false);
    if (!r.ok) {
      expect(r.code).toBe('validation');
      expect(r.fieldErrors?.email).toBe('inválido');
    }
  });
});

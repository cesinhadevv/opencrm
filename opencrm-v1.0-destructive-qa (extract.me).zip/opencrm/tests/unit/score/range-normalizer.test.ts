import { describe, it, expect } from 'vitest';
import {
  normalizeByRanges,
  validateRangeSet,
  RangeValidationError,
  type RangeSet,
} from '@/core/domain/range-normalizer';

const ascending: RangeSet = {
  direction: 'ascending',
  ranges: [
    { min: 0, max: 10, score: 20 },
    { min: 10, max: 20, score: 60 },
    { min: 20, max: Infinity, score: 100 },
  ],
};

describe('normalizeByRanges (ADR-011-A)', () => {
  it('fronteira: min inclusivo, max exclusivo', () => {
    expect(normalizeByRanges(0, ascending)).toBe(20);
    expect(normalizeByRanges(9.99, ascending)).toBe(20);
    expect(normalizeByRanges(10, ascending)).toBe(60); // limite vai à faixa superior
    expect(normalizeByRanges(20, ascending)).toBe(100);
  });
  it('teto satura valores extremos', () => {
    expect(normalizeByRanges(999999, ascending)).toBe(100);
  });
});

describe('validateRangeSet (ADR-011-A — fail fast)', () => {
  it('aceita conjunto válido', () => {
    expect(() => validateRangeSet(ascending)).not.toThrow();
  });
  it('rejeita lacuna entre faixas', () => {
    const gap: RangeSet = {
      direction: 'ascending',
      ranges: [
        { min: 0, max: 10, score: 20 },
        { min: 12, max: Infinity, score: 100 },
      ],
    };
    expect(() => validateRangeSet(gap)).toThrow(RangeValidationError);
  });
  it('rejeita ausência de teto', () => {
    const noCap: RangeSet = {
      direction: 'ascending',
      ranges: [{ min: 0, max: 10, score: 20 }],
    };
    expect(() => validateRangeSet(noCap)).toThrow(RangeValidationError);
  });
  it('rejeita violação de monotonicidade ascending', () => {
    const broken: RangeSet = {
      direction: 'ascending',
      ranges: [
        { min: 0, max: 10, score: 60 },
        { min: 10, max: Infinity, score: 20 },
      ],
    };
    expect(() => validateRangeSet(broken)).toThrow(RangeValidationError);
  });
});

import { describe, it, expect } from 'vitest';
import { ScoreService } from '@/modules/score/domain/score-service';
import { DEFAULT_SCORE_RANGES, SCORE_WEIGHTS } from '@/modules/score/domain/score-config';

const service = new ScoreService(DEFAULT_SCORE_RANGES);

describe('ScoreService — componente proposta a vencer (ADR-011-A)', () => {
  it('proposalDueSoon adiciona exatamente o peso da proposta (5%)', () => {
    const base = service.calculate({
      probability: 0,
      value: 0,
      daysSinceLastInteraction: 0,
      daysToExpectedClose: null,
      proposalDueSoon: false,
    });
    const withProposal = service.calculate({
      probability: 0,
      value: 0,
      daysSinceLastInteraction: 0,
      daysToExpectedClose: null,
      proposalDueSoon: true,
    });
    // proposta contribui 100 * peso(0.05) = 5
    expect(withProposal.total - base.total).toBe(Math.round(100 * SCORE_WEIGHTS.proposal));
  });

  it('pesos somam 1.0 (invariante congelado)', () => {
    const sum =
      SCORE_WEIGHTS.probability +
      SCORE_WEIGHTS.value +
      SCORE_WEIGHTS.urgency +
      SCORE_WEIGHTS.proximity +
      SCORE_WEIGHTS.proposal;
    expect(sum).toBeCloseTo(1.0, 10);
  });
});

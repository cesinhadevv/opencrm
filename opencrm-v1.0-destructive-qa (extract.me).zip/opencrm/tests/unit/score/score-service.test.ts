import { describe, it, expect } from 'vitest';
import { ScoreService } from '@/modules/score/domain/score-service';
import { DEFAULT_SCORE_RANGES } from '@/modules/score/domain/score-config';

const service = new ScoreService(DEFAULT_SCORE_RANGES);

describe('ScoreService (ADR-011 / 011-A)', () => {
  it('exemplo do ADR: R$8k, 85%, 7 dias parado, fecha em 10 dias, sem proposta -> ~60', () => {
    const r = service.calculate({
      probability: 85,
      value: 800_000, // R$8k em centavos
      daysSinceLastInteraction: 7,
      daysToExpectedClose: 10,
      proposalDueSoon: false,
    });
    // 85*.35 + 40*.30 + 60*.20 + 60*.10 + 0 = 29.75+12+12+6 = 59.75 -> 60
    expect(r.total).toBe(60);
    expect(r.components.probability).toBe(85);
    expect(r.components.value).toBe(40);
  });

  it('sem interação => urgência máxima (caso especial)', () => {
    const r = service.calculate({
      probability: 0,
      value: 0,
      daysSinceLastInteraction: null,
      daysToExpectedClose: null,
      proposalDueSoon: false,
    });
    expect(r.components.urgency).toBe(100);
    expect(r.components.proximity).toBe(0); // sem data => neutro
  });

  it('data de fechamento vencida => proximidade 100', () => {
    const r = service.calculate({
      probability: 0,
      value: 0,
      daysSinceLastInteraction: 0,
      daysToExpectedClose: -5,
      proposalDueSoon: false,
    });
    expect(r.components.proximity).toBe(100);
  });

  it('resultado sempre em 0-100', () => {
    const r = service.calculate({
      probability: 100,
      value: 99_999_999,
      daysSinceLastInteraction: 999,
      daysToExpectedClose: -1,
      proposalDueSoon: true,
    });
    expect(r.total).toBeLessThanOrEqual(100);
    expect(r.total).toBeGreaterThanOrEqual(0);
    expect(r.total).toBe(100);
  });
});

import { describe, it, expect } from 'vitest';
import { buildScoreTimes } from '@/modules/score/domain/score-service';
import { SystemClock } from '@/core/infrastructure/clock';

const clock = new SystemClock();
const TZ = 'America/Sao_Paulo';

describe('buildScoreTimes (A1 — entradas reais do Score)', () => {
  it('sem interação e sem data => ambos null', () => {
    const r = buildScoreTimes(clock, TZ, null, null);
    expect(r.daysSinceLastInteraction).toBeNull();
    expect(r.daysToExpectedClose).toBeNull();
  });

  it('última interação há 5 dias => daysSinceLastInteraction ~5', () => {
    const last = new Date(Date.now() - 5 * 86400_000);
    const r = buildScoreTimes(clock, TZ, last, null);
    expect(r.daysSinceLastInteraction).toBeGreaterThanOrEqual(4);
    expect(r.daysSinceLastInteraction).toBeLessThanOrEqual(6);
  });

  it('fechamento no passado => daysToExpectedClose negativo', () => {
    const past = new Date(Date.now() - 3 * 86400_000);
    const r = buildScoreTimes(clock, TZ, null, past);
    expect(r.daysToExpectedClose).toBeLessThan(0);
  });

  it('fechamento futuro => daysToExpectedClose positivo', () => {
    const future = new Date(Date.now() + 10 * 86400_000);
    const r = buildScoreTimes(clock, TZ, null, future);
    expect(r.daysToExpectedClose).toBeGreaterThan(0);
  });
});

import { defineConfig } from 'vitest/config';
import { fileURLToPath } from 'node:url';

export default defineConfig({
  test: {
    environment: 'node',
    include: ['tests/**/*.test.ts'],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'json-summary'],
      // Cobertura mede a LÓGICA DE NEGÓCIO (domínio + regras de aplicação puras).
      // Exclui: contratos/tipos (repository.ts, entities-só-tipo), I/O de banco
      // (infrastructure, server actions com Supabase) e UI — testáveis só com
      // banco real/E2E, fora do escopo de teste determinístico unitário.
      include: [
        'src/**/domain/**/*.ts',
        'src/core/domain/**/*.ts',
        'src/core/application/action-helpers.ts',
        'src/lib/supabase/guard.ts',
        'src/modules/reports/application/period.ts',
      ],
      exclude: ['**/repository.ts', '**/entities.ts'],
      thresholds: {
        statements: 90,
        branches: 80,
        functions: 90,
        lines: 90,
      },
    },
  },
  resolve: { alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) } },
});
